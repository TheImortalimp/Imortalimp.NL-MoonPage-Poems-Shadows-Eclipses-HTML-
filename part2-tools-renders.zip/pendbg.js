const puppeteer = require('puppeteer');
(async () => {
    const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
    const page = await browser.newPage();
    await page.setViewport({ width: 900, height: 1400 });
    await page.goto('file://' + process.cwd() + '/moon-new-poems-true-dark-side.html', { waitUntil: 'load' });
    await new Promise(r => setTimeout(r, 2000));
    await page.evaluate(() => {
        const sel = document.getElementById('eclipseSelect');
        sel.value = '1803165120000'; sel.dispatchEvent(new Event('change', { bubbles: true }));
    });
    await new Promise(r => setTimeout(r, 400));
    await page.evaluate(() => {
        previewState.t = previewState.lastT0; refreshMoon();
        document.getElementById('moonSVG').style.transform = 'rotate(0deg)';
    });
    await new Promise(r => setTimeout(r, 200));
    const dump = await page.evaluate(() => {
        const paths = [...document.querySelectorAll('#termDusk path')].filter(p => (p.getAttribute('d')||'').length > 4);
        const last = paths.slice(-4).map(p => ({
            d0: p.getAttribute('d').slice(0, 60),
            fill: p.getAttribute('fill'), op: p.getAttribute('fill-opacity') }));
        const g = document.getElementById('terminatorBands');
        const duskG = document.getElementById('termDusk');
        return { count: paths.length, last,
                 gOp: g.getAttribute('opacity'),
                 gDisplay: getComputedStyle(g).display,
                 duskDisplay: getComputedStyle(duskG).display,
                 parent: g.parentElement.id || g.parentElement.tagName,
                 svgOp: getComputedStyle(document.getElementById('moonSVG')).opacity,
                 bandsRect: g.getBoundingClientRect().width };
    });
    console.log(JSON.stringify(dump, null, 1));
    const el = await page.$('#moonContainer');
    await el.screenshot({ path: 'pendbg-on.png' });
    await page.evaluate(() => { document.getElementById('termDusk').setAttribute('opacity', '0'); });
    await new Promise(r => setTimeout(r, 150));
    await el.screenshot({ path: 'pendbg-off.png' });
    await browser.close();
})();

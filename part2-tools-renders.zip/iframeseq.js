const puppeteer = require('puppeteer');
const fs = require('fs');
const html = fs.readFileSync(process.argv[2], 'utf8');
const t0 = process.argv[3]; // 'next' or ms
const wrapper = `<!DOCTYPE html><html><body style="margin:0">
<iframe sandbox="allow-scripts" style="width:900px;height:1400px;border:0" srcdoc="${html.replace(/&/g,'&amp;').replace(/"/g,'&quot;')}"></iframe>
</body></html>`;
(async () => {
    const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
    const page = await browser.newPage();
    await page.setViewport({ width: 920, height: 1420 });
    await page.setContent(wrapper, { waitUntil: 'load' });
    await new Promise(r => setTimeout(r, 2500));
    const frame = page.frames().find(f => f !== page.mainFrame());
    await frame.evaluate((t0) => {
        const sel = document.getElementById('eclipseSelect');
        const v = t0 === 'next' ? eclipseEvents.filter(e => e.t0 > Date.now())[0].t0 : Number(t0);
        sel.value = String(v); sel.dispatchEvent(new Event('change', { bubbles: true }));
    }, t0);
    let n = 0;
    for (const wait of [1500, 8000, 8000, 8000, 8000]) {
        await new Promise(r => setTimeout(r, wait));
        const s = await frame.evaluate(() => ({
            t: new Date(previewState.t).toTimeString().slice(0,5),
            pen: eclipseState ? +eclipseState.penMag.toFixed(2) : null
        }));
        console.log(n, JSON.stringify(s));
        const el = await frame.$('#moonContainer');
        await el.screenshot({ path: `ifr-${t0 === 'next' ? 'next' : 'tot'}-${n}.png` });
        n++;
    }
    await browser.close();
})();

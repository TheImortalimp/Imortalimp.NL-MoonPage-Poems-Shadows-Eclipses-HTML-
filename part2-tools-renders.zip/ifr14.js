const puppeteer = require('puppeteer');
const fs = require('fs');
const html = fs.readFileSync('moon-new-poems-true-dark-side.html', 'utf8');
const wrapper = `<!DOCTYPE html><html><body style="margin:0"><iframe sandbox="allow-scripts" style="width:900px;height:1400px;border:0" srcdoc="${html.replace(/&/g,'&amp;').replace(/"/g,'&quot;')}"></iframe></body></html>`;
(async () => {
    const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
    const page = await browser.newPage();
    await page.setViewport({ width: 920, height: 1420 });
    const errs = []; page.on('pageerror', e => errs.push(e.message));
    await page.setContent(wrapper, { waitUntil: 'load' });
    await new Promise(r => setTimeout(r, 2500));
    const fr = page.frames().find(f => f !== page.mainFrame());

    const st = () => fr.evaluate(() => ({
        bandsOp: document.getElementById('terminatorBands').getAttribute('opacity'),
        duskLive: [...document.querySelectorAll('#termDusk path')]
            .filter(p => (p.getAttribute('d') || '').length > 4).length,
        glowLive: [...document.querySelectorAll('#termGlow path')]
            .filter(p => (p.getAttribute('d') || '').length > 4).length,
        layer: document.getElementById('eclipseShadows').getAttribute('opacity')
    }));

    console.log('iframe live state:', JSON.stringify(await st()));
    const el = await fr.$('#moonContainer'); await el.screenshot({ path: 'ifr-14-live.png' });

    await fr.evaluate((t0) => {
        const sel = document.getElementById('eclipseSelect');
        sel.value = String(t0); sel.dispatchEvent(new Event('change', { bubbles: true }));
    }, 1803165120000);
    await new Promise(r => setTimeout(r, 500));
    await fr.evaluate(() => { previewState.t = previewState.lastT0; refreshMoon(); });
    console.log('iframe pen state: ', JSON.stringify(await st()));
    await el.screenshot({ path: 'ifr-14-pen.png' });

    console.log('errors:', errs.length ? errs.join('|') : '(none)');
    await browser.close();
})();

const puppeteer = require('puppeteer');
(async () => {
    const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
    const page = await browser.newPage();
    await page.setViewport({ width: 900, height: 1400 });
    const errs = []; page.on('pageerror', e => errs.push(e.message));
    await page.goto('file://' + process.cwd() + '/moon-new-poems-true-dark-side.html', { waitUntil: 'load' });
    await new Promise(r => setTimeout(r, 2000));
    const shot = async (n) => { const el = await page.$('#moonContainer'); await el.screenshot({ path: n }); };
    const set = (t0) => page.evaluate((t0) => {
        const sel = document.getElementById('eclipseSelect');
        sel.value = String(t0); sel.dispatchEvent(new Event('change', { bubbles: true }));
    }, t0);
    await set(1803165120000); await new Promise(r => setTimeout(r, 400));
    await page.evaluate(() => { previewState.t = previewState.start + (previewState.end - previewState.start) * 0.3; refreshMoon(); });
    await shot('q-pen-early.png');
    await page.evaluate(() => { previewState.t = previewState.lastT0; refreshMoon(); });
    await shot('q-pen-max.png');
    await set(1787890320000); await new Promise(r => setTimeout(r, 400));
    await page.evaluate(() => { previewState.t = previewState.lastT0; refreshMoon(); });
    await shot('q-greatest.png');
    console.log('errors:', errs.length ? errs.join('|') : '(none)');
    await browser.close();
})();

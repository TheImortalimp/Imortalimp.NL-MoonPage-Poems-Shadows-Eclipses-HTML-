const puppeteer = require('puppeteer');
(async () => {
    const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
    const page = await browser.newPage();
    await page.setViewport({ width: 900, height: 1400 });
    const errs = []; page.on('pageerror', e => errs.push(e.message));
    await page.goto('file://' + process.cwd() + '/moon-new-poems-true-dark-side.html', { waitUntil: 'load' });
    await new Promise(r => setTimeout(r, 2000));
    const el0 = await page.$('#moonContainer'); await el0.screenshot({ path: 't-live.png' });
    const st = await page.evaluate(() => ({
        bandsOp: document.getElementById('terminatorBands').getAttribute('opacity'),
        band0d: (document.getElementById('termBand0').getAttribute('d') || '').slice(0, 40)
    }));
    console.log('live bands:', JSON.stringify(st));
    const set = (t0) => page.evaluate((t0) => {
        const sel = document.getElementById('eclipseSelect');
        sel.value = String(t0); sel.dispatchEvent(new Event('change', { bubbles: true }));
    }, t0);
    await set(1772537580000); await new Promise(r => setTimeout(r, 400));
    await page.evaluate(() => { previewState.t = previewState.lastT0; refreshMoon(); });
    const st2 = await page.evaluate(() => document.getElementById('terminatorBands').getAttribute('opacity'));
    console.log('bands opacity at full (eclipse):', st2);
    const el1 = await page.$('#moonContainer'); await el1.screenshot({ path: 't-tot.png' });
    await set(1787890320000); await new Promise(r => setTimeout(r, 400));
    await page.evaluate(() => { previewState.t = previewState.lastT0 - 50 * 60000; refreshMoon(); });
    const el2 = await page.$('#moonContainer'); await el2.screenshot({ path: 't-part.png' });
    console.log('errors:', errs.length ? errs.join('|') : '(none)');
    await browser.close();
})();

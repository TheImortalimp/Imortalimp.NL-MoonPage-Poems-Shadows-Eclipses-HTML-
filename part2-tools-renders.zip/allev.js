const puppeteer = require('puppeteer');
const path = require('path');
const fs = require('fs');
const file = process.argv[2] || 'moon-new-poems-true-dark-side.html';

(async () => {
    fs.rmSync('/tmp/allev', { recursive: true, force: true });
    fs.mkdirSync('/tmp/allev', { recursive: true });
    const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
    const page = await browser.newPage();
    await page.setViewport({ width: 900, height: 1200 });
    const errs = [];
    page.on('pageerror', e => errs.push(e.message));
    await page.goto('file://' + path.resolve(file), { waitUntil: 'load' });
    await new Promise(r => setTimeout(r, 1500));

    const meta = await page.evaluate(() => {
        const out = [];
        let i = 0;
        for (const ev of eclipseEvents) {
            const pen0 = penumbralMagnitudeAtGreatest(ev);
            if (pen0 <= 0.02) continue;
            const mag = magnitudeAtGreatest(ev);
            previewEvent(ev);
            previewState.t = ev.t0; refreshMoon();
            const st = eclipseState;
            const umb = document.getElementById('umbraShadow');
            out.push({
                i: i++,
                t0: ev.t0,
                kind: mag >= 1 ? 'TOTAL' : mag > 0 ? 'PART' : 'PEN',
                mag: +mag.toFixed(2), pen: +pen0.toFixed(2),
                umbOp: st && st.umbMag > 0 ? +umb.getAttribute('opacity') : 0,
                umbMag: st ? +st.umbMag.toFixed(2) : null,
                obs: st ? +st.obscuration.toFixed(2) : null,
                layerOp: +document.getElementById('eclipseShadows').getAttribute('opacity')
            });
        }
        return out;
    });

    // one screenshot per event at greatest, re-driving state each time
    for (const r of meta) {
        await page.evaluate((t0) => {
            const ev = eclipseEvents.find(e => e.t0 === t0);
            previewEvent(ev); previewState.t = ev.t0; refreshMoon();
        }, r.t0);
        await new Promise(res => setTimeout(res, 60));
        const el = await page.$('#moonContainer');
        await el.screenshot({ path: `/tmp/allev/${String(r.i).padStart(2, '0')}.png` });
    }

    const byKind = { TOTAL: [], PART: [], PEN: [] };
    meta.forEach(r => byKind[r.kind].push(r));
    console.log('touching:', meta.length, '| TOTAL', byKind.TOTAL.length, 'PART', byKind.PART.length, 'PEN', byKind.PEN.length);
    console.log('TOTAL/PART with umbra layer opacity > 0:', meta.filter(r => r.kind !== 'PEN' && r.umbOp > 0).length, 'of', meta.filter(r => r.kind !== 'PEN').length);
    const bad = meta.filter(r => (r.kind === 'TOTAL' && r.obs < 0.99) || (r.kind === 'PART' && r.umbOp <= 0));
    console.log('problem umbral events:', bad.length); bad.forEach(r => console.log('  ', new Date(r.t0).toISOString().slice(0, 10), JSON.stringify(r)));
    meta.forEach(r => console.log(String(r.i).padStart(2, '0'), new Date(r.t0).toISOString().slice(0, 10), r.kind.padEnd(5), 'mag', r.mag, 'pen', r.pen, 'umbOp', r.umbOp, 'obs', r.obs));
    console.log('pageerrors:', errs.length ? errs.join('|') : '(none)');

    // labeled montages per class
    const label = r => `${new Date(r.t0).toISOString().slice(0, 10)} ${r.kind}`;
    for (const k of ['TOTAL', 'PART', 'PEN']) {
        const args = byKind[k].map(r => `/tmp/allev/${String(r.i).padStart(2, '0')}.png`);
        if (!args.length) continue;
        const { execSync } = require('child_process');
        execSync(`montage ${args.map((a, j) => `-label '${label(byKind[k][j])}' ${a}`).join(' ')} -tile 6x -geometry 130x130+4+14 -background '#10131c' /home/user/all-${k.toLowerCase()}.png`);
    }
    await browser.close();
})();

import sys
from PIL import Image

path = sys.argv[1]
row = sys.argv[2] if len(sys.argv) > 2 else 'mid'

im = Image.open(path).convert('RGB')
W, H = im.size
px = im.load()
lum = lambda p: 0.299 * p[0] + 0.587 * p[1] + 0.114 * p[2]

# Find the disc: brightest column-extent on the mid row.
y = H // 2 if row == 'mid' else int(row)
xs = [x for x in range(W) if lum(px[x, y]) > 30]
if not xs:
    print('no disc found on row', y)
    sys.exit(0)
x0, x1 = min(xs), max(xs)
cx = (x0 + x1) / 2
print(f'{path}: {W}x{H}  disc row {y} spans x={x0}..{x1}  (width {x1-x0}, centre {cx:.1f})')

prof = [(x, lum(px[x, y])) for x in range(x0, x1 + 1)]
# Brightest point = deep inside the sunlit face; walk from there to the terminator.
bright_x = max(prof, key=lambda t: t[1])[0]
print(f'brightest pixel x={bright_x} lum={lum(px[bright_x,y]):.0f}')

# Max adjacent jump anywhere along the row.
jumps = [(abs(prof[i+1][1] - prof[i][1]), prof[i][0]) for i in range(len(prof) - 1)]
jumps.sort(reverse=True)
print('largest adjacent jumps (lum, x):', [(round(j, 1), x) for j, x in jumps[:6]])

# Print the profile from the bright limb across to the far side, every 4 px.
print('x   lum  rgb')
for x in range(x0, x1 + 1, 4):
    p = px[x, y]
    print(f'{x:4d} {lum(p):5.1f}  {p}')

/* jsdom harness: load the page, let it boot, then drive the eclipse preview. */
const fs = require('fs');
const { JSDOM, VirtualConsole } = require('jsdom');

const html = fs.readFileSync(process.argv[2] || 'uploads/moon-new-poems-true-dark-side.html', 'utf8');

const vc = new VirtualConsole();
const errors = [];
vc.on('jsdomError', e => errors.push('jsdomError: ' + (e.stack || e.message)));
vc.on('error', (...a) => errors.push('console.error: ' + a.join(' ')));
vc.on('warn', (...a) => { /* noise */ });

const dom = new JSDOM(html, {
    runScripts: 'dangerously',
    pretendToBeVisual: true,
    virtualConsole: vc,
    url: 'https://example.test/moon.html',
    beforeParse(win) {
        win.fetch = () => Promise.reject(new Error('no network in harness'));
        delete win.navigator.geolocation;
        win.matchMedia = win.matchMedia || (() => ({ matches: false, addListener() {}, removeListener() {}, addEventListener() {}, removeEventListener() {} }));
    }
});

const win = dom.window;
win.addEventListener('error', e => errors.push('window error: ' + (e.error && e.error.stack || e.message)));

setTimeout(() => {
    const doc = win.document;
    const $ = id => doc.getElementById(id);
    const sel = $('eclipseSelect');
    const status = $('eclipseStatus');

    console.log('--- boot errors ---');
    console.log(errors.length ? errors.join('\n') : '(none)');

    console.log('\n--- select: option count =', sel.options.length);
    const opts = [...sel.options].map(o => o.value + ' | ' + o.textContent);
    console.log(opts.slice(0, 6).join('\n'));

    console.log('\n--- live status line ---');
    console.log(JSON.stringify(status.textContent));

    // find the next upcoming eclipse option (first option whose t0 is in the future)
    const now = Date.now();
    const next = [...sel.options].map(o => ({ v: Number(o.value), txt: o.textContent }))
        .filter(o => o.v && o.v > now);
    console.log('\n--- next upcoming option ---');
    console.log(next[0] && next[0].txt);

    if (next[0]) {
        sel.value = String(next[0].v);
        sel.dispatchEvent(new win.Event('change', { bubbles: true }));
    }

    setTimeout(() => {
        console.log('\n--- after selecting next eclipse ---');
        console.log('status:', JSON.stringify(status.textContent));
        const layer = $('eclipseShadows');
        console.log('eclipseShadows opacity =', layer.getAttribute('opacity'));
        const u = $('umbraShadow'), p = $('penumbraShadow');
        console.log('umbra    r =', u.getAttribute('r'), 'cx/cy =', u.getAttribute('cx'), u.getAttribute('cy'),
                    'fill-opacity-ish stop0 =', $('umbraStop0').getAttribute('stop-opacity'),
                    $('umbraStop0').getAttribute('stop-color'));
        console.log('penumbra r =', p.getAttribute('r'), 'cx/cy =', p.getAttribute('cx'), p.getAttribute('cy'));
        console.log('pen stops:', [0,1,2].map(i => {
            const s = $('penumbraStop' + i);
            return i + ':' + s.getAttribute('offset') + '/' + s.getAttribute('stop-opacity');
        }).join(' '));
        console.log('stop button hidden =', $('eclipseStopBtn').hidden);
        console.log('moonIlluminatedPath d length =', ($('moonIlluminatedPath').getAttribute('d') || '').length);
        console.log('\n--- errors during preview ---');
        console.log(errors.length ? errors.join('\n') : '(none)');
        dom.window.close();
    }, 1500);
}, 1500);

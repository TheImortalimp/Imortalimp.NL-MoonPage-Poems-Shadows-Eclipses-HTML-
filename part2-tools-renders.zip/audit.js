const puppeteer = require('puppeteer');
const path = require('path');
const file = process.argv[2];

(async () => {
    const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
    const page = await browser.newPage();
    await page.setViewport({ width: 900, height: 1200 });
    page.on('pageerror', e => console.log('PAGEERROR', e.message));
    await page.goto('file://' + path.resolve(file), { waitUntil: 'load' });
    await new Promise(r => setTimeout(r, 1500));

    const events = await page.evaluate(() => eclipseEvents.map(e => ({
        t0: e.t0, gamma: e.gamma, dur: e.dur,
        mag: +magnitudeAtGreatest(e).toFixed(2), pen: +penumbralMagnitudeAtGreatest(e).toFixed(2)
    })));

    const fails = [];
    for (const ev of events) {
        if (ev.pen <= 0.02) continue; // misses the shadow entirely by catalogue
        const r = await page.evaluate((t0) => {
            const ev = eclipseEvents.find(e => e.t0 === t0);
            previewEvent(ev);
            previewState.t = ev.t0; refreshMoon();
            const withShadow = document.getElementById('moonContainer').querySelector('svg');
            const lum = () => {
                // sample via canvas-free metric: read pixel data is heavy; use quick opacity/geometry proxy instead
                return null;
            };
            const st = eclipseState;
            const layer = document.getElementById('eclipseShadows');
            return { st: st ? { umb: +st.umbMag.toFixed(2), pen: +st.penMag.toFixed(2), obs: +st.obscuration.toFixed(2) } : null,
                     layerOp: layer.getAttribute('opacity') };
        }, ev.t0);
        const kind = ev.mag >= 1 ? 'TOTAL' : ev.mag > 0 ? 'PART' : 'PEN';
        const ok = r.st && r.layerOp > 0.5 &&
            (kind === 'PEN' ? r.st.pen > 0.15 : (kind === 'PART' ? r.st.obs > 0 || r.st.pen > 0.15 : r.st.obs > 0.9));
        if (!ok) fails.push([new Date(ev.t0).toISOString().slice(0, 10), kind, JSON.stringify(r.st), 'op=' + r.layerOp]);
    }
    console.log('events checked:', events.length);
    console.log(fails.length ? 'FAILS:\n' + fails.map(f => f.join(' ')).join('\n') : 'no geometry-level fails');
    await browser.close();
})();

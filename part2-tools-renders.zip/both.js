const puppeteer = require('puppeteer');
const fs = require('fs');
const html = fs.readFileSync('moon-new-poems-true-dark-side.html', 'utf8');
const wrapper = `<!DOCTYPE html><html><body style="margin:0"><iframe sandbox="allow-scripts" style="width:900px;height:1400px;border:0" srcdoc="${html.replace(/&/g,'&amp;').replace(/"/g,'&quot;')}"></iframe></body></html>`;
async function shoot(page, frameGetter, tag) {
    await page.evaluate(() => {});
    const fr = frameGetter();
    await fr.evaluate((t0) => {
        const sel = document.getElementById('eclipseSelect');
        sel.value = String(t0); sel.dispatchEvent(new Event('change', { bubbles: true }));
    }, 1772537580000);
    await new Promise(r => setTimeout(r, 500));
    await fr.evaluate(() => { previewState.t = previewState.start + (previewState.end - previewState.start) * 0.32; refreshMoon(); });
    let el = await fr.$('#moonContainer'); await el.screenshot({ path: `u-${tag}-bite.png` });
    await fr.evaluate(() => { previewState.t = eclipseEvents.find(e => e.t0 === previewState.lastT0).t0; refreshMoon(); });
    el = await fr.$('#moonContainer'); await el.screenshot({ path: `u-${tag}-tot.png` });
}
(async () => {
    const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
    // direct
    let page = await browser.newPage();
    await page.setViewport({ width: 900, height: 1400 });
    const errs = []; page.on('pageerror', e => errs.push(e.message));
    await page.goto('file://' + process.cwd() + '/moon-new-poems-true-dark-side.html', { waitUntil: 'load' });
    await new Promise(r => setTimeout(r, 1500));
    await shoot(page, () => page, 'dir');
    await page.close();
    // iframe replica
    page = await browser.newPage();
    await page.setViewport({ width: 920, height: 1420 });
    await page.setContent(wrapper, { waitUntil: 'load' });
    await new Promise(r => setTimeout(r, 2500));
    await shoot(page, () => page.frames().find(f => f !== page.mainFrame()), 'ifr');
    console.log('errors:', errs.length ? errs.join('|') : '(none)');
    await browser.close();
})();

const puppeteer = require('puppeteer');
(async () => {
    const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
    const page = await browser.newPage();
    await page.setViewport({ width: 900, height: 1400 });
    await page.goto('file://' + process.cwd() + '/moon-new-poems-true-dark-side.html', { waitUntil: 'load' });
    await new Promise(r => setTimeout(r, 2000));
    await page.evaluate(() => { document.getElementById('moonSVG').style.transform = 'rotate(0deg)'; });
    const el = await page.$('#moonContainer');
    await el.screenshot({ path: 'ab-both.png' });
    await page.evaluate(() => { for (const p of document.querySelectorAll('#termGlow path')) p.setAttribute('d',''); });
    await new Promise(r => setTimeout(r, 150));
    await el.screenshot({ path: 'ab-noglow.png' });
    await page.evaluate(() => {
        const dusk = [...document.querySelectorAll('#termDusk path')];
        // keep only the 52 light-side rings
        dusk.slice(52).forEach(p => p.setAttribute('d',''));
    });
    await new Promise(r => setTimeout(r, 150));
    await el.screenshot({ path: 'ab-lightonly.png' });
    await browser.close();
})();

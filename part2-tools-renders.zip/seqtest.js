const puppeteer = require('puppeteer');
const path = require('path');
const file = process.argv[2];

(async () => {
    const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
    const page = await browser.newPage();
    await page.setViewport({ width: 900, height: 1200 });
    const errs = [];
    page.on('pageerror', e => errs.push('pageerror: ' + e.message));
    page.on('console', m => { if (m.type() === 'error') errs.push('console: ' + m.text()); });

    await page.goto('file://' + path.resolve(file), { waitUntil: 'load' });
    await new Promise(r => setTimeout(r, 1500));

    await page.evaluate(() => {
        const sel = document.getElementById('eclipseSelect');
        const ev = eclipseEvents.filter(e => e.t0 > Date.now())[0];
        sel.value = String(ev.t0);
        sel.dispatchEvent(new Event('change', { bubbles: true }));
    });

    for (let i = 0; i < 8; i++) {
        await new Promise(r => setTimeout(r, 1000));
        const s = await page.evaluate(() => ({
            active: previewState.active,
            t: new Date(previewState.t).toISOString().slice(11, 16),
            start: new Date(previewState.start).toISOString().slice(11, 16),
            end: new Date(previewState.end).toISOString().slice(11, 16),
            opacity: document.getElementById('eclipseShadows').getAttribute('opacity'),
            status: document.getElementById('eclipseStatus').textContent.slice(0, 95),
            raf: typeof requestAnimationFrame
        }));
        console.log(i + 's', JSON.stringify(s));
    }
    console.log('errors:', errs.length ? errs.join(' | ') : '(none)');
    await browser.close();
})();

const puppeteer = require('puppeteer');
(async () => {
    const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
    const page = await browser.newPage();
    await page.setViewport({ width: 900, height: 1400 });
    const errs = []; page.on('pageerror', e => errs.push(e.message));
    await page.goto('file://' + process.cwd() + '/moon-new-poems-true-dark-side.html', { waitUntil: 'load' });
    await new Promise(r => setTimeout(r, 1500));
    const set = (t0) => page.evaluate((t0) => {
        const sel = document.getElementById('eclipseSelect');
        sel.value = String(t0); sel.dispatchEvent(new Event('change', { bubbles: true }));
    }, t0);
    const shot = async (n) => { const el = await page.$('#moonContainer'); await el.screenshot({ path: n }); };
    // deep penumbral Feb 2027 at greatest (t0 = greatest)
    await set(1803165120000); await new Promise(r => setTimeout(r, 400));
    await page.evaluate(() => { previewState.t = previewState.lastT0; refreshMoon(); });
    await shot('p-deep.png');
    // mid-walk (earlier, shallower)
    await page.evaluate(() => { previewState.t = previewState.start + (previewState.end - previewState.start) * 0.25; refreshMoon(); });
    await shot('p-mid.png');
    // shallow grazer 2031-06-05
    await set(1938787200000); await new Promise(r => setTimeout(r, 300));
    const has31 = await page.evaluate(() => !!document.querySelector('#eclipseSelect option[value="1938787200000"]'));
    if (has31) { await page.evaluate(() => { previewState.t = previewState.lastT0; refreshMoon(); }); await shot('p-shal.png'); }
    console.log('has31:', has31);
    // umbral regression: partial + total
    await set(1787890320000); await new Promise(r => setTimeout(r, 300));
    await page.evaluate(() => { previewState.t = previewState.lastT0 - 50 * 60000; refreshMoon(); });
    await shot('p-part.png');
    await set(1772537580000); await new Promise(r => setTimeout(r, 300));
    await page.evaluate(() => { previewState.t = previewState.lastT0; refreshMoon(); });
    await shot('p-tot.png');
    console.log('errors:', errs.length ? errs.join('|') : '(none)');
    await browser.close();
})();

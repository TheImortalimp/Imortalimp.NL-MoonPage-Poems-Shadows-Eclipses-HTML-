const puppeteer = require('puppeteer');
const path = require('path');
const file = process.argv[2];
(async () => {
    const browser = await puppeteer.launch({ args: ['--no-sandbox'], env: { ...process.env, TZ: 'Europe/Amsterdam' } });
    const page = await browser.newPage();
    await page.setViewport({ width: 900, height: 1200 });
    const errs = [];
    page.on('pageerror', e => errs.push('pageerror: ' + e.message));
    await page.goto('file://' + path.resolve(file), { waitUntil: 'load' });
    await new Promise(r => setTimeout(r, 1500));
    console.log('TZ check:', await page.evaluate(() => new Date().toString()));
    await page.evaluate(() => {
        const sel = document.getElementById('eclipseSelect');
        const ev = eclipseEvents.filter(e => e.t0 > Date.now())[0];
        sel.value = String(ev.t0);
        sel.dispatchEvent(new Event('change', { bubbles: true }));
    });
    const opt = await page.evaluate(() => document.getElementById('eclipseSelect').selectedOptions[0].textContent);
    console.log('selected option text:', opt);
    for (const wait of [2000, 12000, 12000, 10000]) {
        await new Promise(r => setTimeout(r, wait));
        const s = await page.evaluate(() => ({
            t: new Date(previewState.t).toTimeString().slice(0,5),
            opacity: document.getElementById('eclipseShadows').getAttribute('opacity'),
            penR: document.getElementById('penumbraShadow').getAttribute('r'),
            penX: document.getElementById('penumbraShadow').getAttribute('cx'),
            penY: document.getElementById('penumbraShadow').getAttribute('cy'),
            status: document.getElementById('eclipseStatus').textContent.slice(12, 70)
        }));
        console.log(JSON.stringify(s));
        const el = await page.$('#moonContainer');
        await el.screenshot({ path: `seq-${file.includes('uploads') ? 'orig' : 'fixed'}-${wait}.png` });
    }
    console.log('errors:', errs.length ? errs.join(' | ') : '(none)');
    await browser.close();
})();

/* Walk an eclipse deterministically through previewEvent/refreshMoon and dump geometry. */
const fs = require('fs');
const { JSDOM, VirtualConsole } = require('jsdom');
const html = fs.readFileSync('uploads/moon-new-poems-true-dark-side.html', 'utf8');

const vc = new VirtualConsole();
const errors = [];
vc.on('jsdomError', e => errors.push('jsdomError: ' + (e.stack || e.message)));
vc.on('error', (...a) => errors.push('console.error: ' + a.join(' ')));

const dom = new JSDOM(html, {
    runScripts: 'dangerously', pretendToBeVisual: true, virtualConsole: vc,
    url: 'https://example.test/moon.html',
    beforeParse(win) {
        win.fetch = () => Promise.reject(new Error('offline'));
        delete win.navigator.geolocation;
    }
});
const win = dom.window;
win.addEventListener('error', e => errors.push('window error: ' + (e.error && e.error.stack || e.message)));

setTimeout(() => {
    const probe = `(() => {
        const d = document, num = (id,a) => { const v = d.getElementById(id).getAttribute(a); return v === null ? null : Number(v); };
        const st = eclipseState;
        const mc = 250, mr = 120;                     // moon centre / radius in user units
        const penR = num('penumbraShadow','r'), penX = num('penumbraShadow','cx'), penY = num('penumbraShadow','cy');
        const dist = Math.hypot(penX-mc, penY-mc);
        return {
            layerOpacity: Number(d.getElementById('eclipseShadows').getAttribute('opacity')),
            stNull: st === null,
            umbMag: st ? +st.umbMag.toFixed(4) : null,
            penMag: st ? +st.penMag.toFixed(4) : null,
            obsc: st ? +st.obscuration.toFixed(4) : null,
            sigma: st ? +st.sigma.toFixed(4) : null,
            reachP: st ? +(st.rhoP + st.rMoon).toFixed(4) : null,
            rate: st ? +st.rate.toFixed(4) : null,
            dt_h: st ? +st.dt.toFixed(3) : null,
            shadowCentreDistPx: +dist.toFixed(1),
            penumbraRpx: penR ? +penR.toFixed(1) : null,
            umbraRpx: num('umbraShadow','r'),
            moonSvgTransform: d.getElementById('moonSVG').style.transform,
            status: d.getElementById('eclipseStatus').textContent,
            maskLen: (d.getElementById('moonIlluminationMaskPath').getAttribute('d')||'').length
        };
    })()`;

    const run = (label, t0) => {
        console.log('\n================ ' + label + '  (t0=' + new Date(t0).toISOString() + ')');
        const info = win.eval(`(() => {
            const ev = eclipseEvents.find(e => e.t0 === ${t0});
            previewEvent(ev);
            const p1 = previewState.start, p4 = previewState.end, g = ev.t0;
            return {p1, p4, g, mag:+magnitudeAtGreatest(ev).toFixed(3), penmag:+penumbralMagnitudeAtGreatest(ev).toFixed(3),
                    kind: eclipseKind(magnitudeAtGreatest(ev)), dur: ev.dur, gamma: ev.gamma,
                    };
        })()`);
        console.log('  kind=' + info.kind + ' mag=' + info.mag + ' penMag=' + info.penmag +
                    ' gamma=' + info.gamma + ' dur=' + info.dur + 'min');
        console.log('  preview span: ' + new Date(info.p1).toISOString() + '  ->  ' + new Date(info.p4).toISOString() +
                    '  (' + ((info.p4 - info.p1) / 60000).toFixed(0) + ' min, playback ' +
                    ((info.p4 - info.p1) / 420 / 1000).toFixed(1) + ' s)');
        const fracs = [0, 0.15, 0.35, 0.5, 0.65, 0.85, 1];
        for (const f of fracs) {
            const t = info.p1 + (info.p4 - info.p1) * f;
            win.eval(`previewState.t = ${t}; refreshMoon();`);
            const r = win.eval(probe);
            console.log('   f=' + f.toFixed(2) + ' ' + new Date(t).toISOString().slice(11, 16) +
                ' | layer=' + r.layerOpacity.toFixed(2) +
                ' umbMag=' + r.umbMag + ' penMag=' + r.penMag + ' obsc=' + r.obsc +
                ' sigma=' + r.sigma + '/' + r.reachP +
                ' | penCentre=' + r.shadowCentreDistPx + 'px penR=' + r.penumbraRpx + 'px' +
                ' | ' + r.status.replace('⏯ Preview · ', ''));
        }
    };

    const future = win.eval(`eclipseEvents.filter(e => e.t0 > Date.now()).slice(0,4).map(e => e.t0 + ':' + new Date(e.t0).toISOString().slice(0,10))`);
    console.log('next upcoming events:', JSON.stringify(future));
    run('NEXT UPCOMING', Number(future[0].split(':')[0]));
    run('Aug 28 2026 (partial 93%)', 1787890320000);
    run('Mar 3 2026 (total 1.15)', 1772537580000);
    run('Sep 7 2025 (total 1.36)', 1757268660000);

    console.log('\n--- errors ---');
    console.log(errors.length ? errors.join('\n') : '(none)');
    win.close();
}, 1500);

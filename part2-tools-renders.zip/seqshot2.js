const puppeteer = require('puppeteer');
const path = require('path');
const file = process.argv[2], tag = process.argv[3];
(async () => {
    const browser = await puppeteer.launch({ args: ['--no-sandbox'], env: { ...process.env, TZ: 'Europe/Amsterdam' } });
    const page = await browser.newPage();
    await page.setViewport({ width: 900, height: 1200 });
    const errs = [];
    page.on('pageerror', e => errs.push(e.message));
    await page.goto('file://' + path.resolve(file), { waitUntil: 'load' });
    await new Promise(r => setTimeout(r, 1500));
    await page.evaluate((t0) => {
        const sel = document.getElementById('eclipseSelect');
        sel.value = String(t0); sel.dispatchEvent(new Event('change', { bubbles: true }));
    }, Number(process.argv[4] || 0) || undefined);
    if (!process.argv[4]) {
        await page.evaluate(() => {
            const sel = document.getElementById('eclipseSelect');
            const ev = eclipseEvents.filter(e => e.t0 > Date.now())[0];
            sel.value = String(ev.t0); sel.dispatchEvent(new Event('change', { bubbles: true }));
        });
    }
    let n = 0;
    for (const wait of [1500, 8000, 8000, 8000, 8000]) {
        await new Promise(r => setTimeout(r, wait));
        const s = await page.evaluate(() => ({
            t: new Date(previewState.t).toTimeString().slice(0,5),
            st: eclipseState ? { pen: +eclipseState.penMag.toFixed(2), umb: +eclipseState.umbMag.toFixed(2) } : null
        }));
        console.log(tag, n, JSON.stringify(s));
        const el = await page.$('#moonContainer');
        await el.screenshot({ path: `seq2-${tag}-${n}.png` });
        n++;
    }
    console.log('errors:', errs.length ? errs.join('|') : '(none)');
    await browser.close();
})();

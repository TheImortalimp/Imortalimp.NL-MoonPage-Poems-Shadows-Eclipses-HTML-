const puppeteer = require('puppeteer');
(async () => {
    const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
    const page = await browser.newPage();
    await page.setViewport({ width: 900, height: 1400 });
    await page.goto('file://' + process.cwd() + '/moon-new-poems-true-dark-side.html', { waitUntil: 'load' });
    await new Promise(r => setTimeout(r, 2000));
    const out = await page.evaluate(() => {
        const il = SunCalc.getMoonIllumination(new Date());
        const box = document.getElementById('moonSVG').getBoundingClientRect();
        const dusk = [...document.querySelectorAll('#termDusk path')].filter(p => (p.getAttribute('d')||'').length>4);
        return { fraction: il.fraction, phase: il.phase, waxing: il.phase <= 0.5,
                 termScale: Math.cos(il.phase*2*Math.PI), svgBox: [box.width, box.height],
                 bandsOp: document.getElementById('terminatorBands').getAttribute('opacity'),
                 transform: document.getElementById('moonSVG').style.transform,
                 duskCount: dusk.length,
                 firstD: (dusk[0].getAttribute('d')||'').slice(0,90),
                 lastD: (dusk[dusk.length-1].getAttribute('d')||'').slice(0,90) };
    });
    console.log(JSON.stringify(out, null, 1));
    await browser.close();
})();

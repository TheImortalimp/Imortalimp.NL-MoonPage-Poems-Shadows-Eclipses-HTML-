const puppeteer = require('puppeteer');
(async () => {
    const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
    const page = await browser.newPage();
    await page.setViewport({ width: 900, height: 1400 });
    const errs = []; page.on('pageerror', e => errs.push(e.message));
    await page.goto('file://' + process.cwd() + '/moon-new-poems-true-dark-side.html', { waitUntil: 'load' });
    await new Promise(r => setTimeout(r, 1500));
    const set = (t0) => page.evaluate((t0) => {
        const sel = document.getElementById('eclipseSelect');
        sel.value = String(t0); sel.dispatchEvent(new Event('change', { bubbles: true }));
    }, t0);
    const shot = async (name) => { const el = await page.$('#moonContainer'); await el.screenshot({ path: name }); };
    // PARTIAL Aug 2026: mid-bite (t0 - 50 min)
    await set(1787890320000); await new Promise(r => setTimeout(r, 400));
    await page.evaluate(() => { previewState.t = previewState.lastT0 - 50 * 60000; refreshMoon(); });
    await shot('s-part-mid.png');
    // PARTIAL deep (t0 - 10 min)
    await page.evaluate(() => { previewState.t = previewState.lastT0 - 10 * 60000; refreshMoon(); });
    await shot('s-part-deep.png');
    // TOTAL at greatest
    await set(1772537580000); await new Promise(r => setTimeout(r, 400));
    await page.evaluate(() => { previewState.t = previewState.lastT0; refreshMoon(); });
    await shot('s-tot.png');
    // PENUMBRAL Feb 2027 at greatest (light must stay ON)
    await set(1803165120000); await new Promise(r => setTimeout(r, 400));
    await page.evaluate(() => { previewState.t = previewState.lastT0; refreshMoon(); });
    await shot('s-pen.png');
    const states = await page.evaluate(() => ({
        lit: document.getElementById('moonIlluminatedPath').getAttribute('opacity'),
        surf: document.getElementById('eclipseSurface').getAttribute('opacity'),
        sliv: document.getElementById('eclipseSliver').getAttribute('opacity')
    }));
    console.log('pen-state', JSON.stringify(states));
    console.log('errors:', errs.length ? errs.join('|') : '(none)');
    await browser.close();
})();

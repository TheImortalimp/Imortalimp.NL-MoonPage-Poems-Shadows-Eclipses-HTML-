const puppeteer = require('puppeteer');
(async () => {
    const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
    const page = await browser.newPage();
    await page.setViewport({ width: 900, height: 1400 });
    await page.goto('file://' + process.cwd() + '/moon-new-poems-true-dark-side.html', { waitUntil: 'load' });
    await new Promise(r => setTimeout(r, 2000));
    await page.evaluate(() => {
        const b = document.getElementById('termBand1');
        b.setAttribute('fill', '#ffffff'); b.setAttribute('fill-opacity', '1');
        for (const id of ['termBand0','termBandL','termBand2','termBand3','termBand4','termBand5'])
            document.getElementById(id).setAttribute('fill-opacity', '0');
    });
    await new Promise(r => setTimeout(r, 300));
    const el = await page.$('#moonContainer'); await el.screenshot({ path: 'cal.png' });
    await browser.close();
})();

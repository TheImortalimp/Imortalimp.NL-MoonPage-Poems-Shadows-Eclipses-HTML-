const puppeteer = require('puppeteer');
(async () => {
    const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
    const page = await browser.newPage();
    await page.setViewport({ width: 900, height: 1400 });
    await page.goto('file://' + process.cwd() + '/moon-new-poems-true-dark-side.html', { waitUntil: 'load' });
    await new Promise(r => setTimeout(r, 2000));
    const st = await page.evaluate(() => {
        const g = document.getElementById('terminatorBands');
        const b0 = document.getElementById('termBand0');
        const b1 = document.getElementById('termBand1');
        const cs = getComputedStyle(b1);
        return {
            groupOp: g.getAttribute('opacity'),
            b1fill: b1.getAttribute('fill'), b1op: b1.getAttribute('fill-opacity'),
            computedFillOp: cs.fillOpacity, computedOpacity: cs.opacity,
            d1len: (b1.getAttribute('d') || '').length,
            order: [...document.getElementById('moonSVG').children].map(e => e.id || e.tagName).join(',')
        };
    });
    console.log(JSON.stringify(st, null, 1));
    await browser.close();
})();

const puppeteer = require('puppeteer');
const fs = require('fs');
const path = require('path');
const file = process.argv[2];
const html = fs.readFileSync(file, 'utf8');
const wrapper = `<!DOCTYPE html><html><body>
<iframe sandbox="allow-scripts" style="width:900px;height:1400px;border:0" srcdoc="${html.replace(/&/g,'&amp;').replace(/"/g,'&quot;')}"></iframe>
</body></html>`;
(async () => {
    const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
    const page = await browser.newPage();
    await page.setViewport({ width: 920, height: 1420 });
    await page.setContent(wrapper, { waitUntil: 'load' });
    await new Promise(r => setTimeout(r, 3000));
    const frame = page.frames().find(f => f !== page.mainFrame());
    console.log('frame found:', !!frame);
    if (frame) {
        const info = await frame.evaluate(() => ({
            opts: document.getElementById('eclipseSelect').options.length,
            heading: document.getElementById('phaseName').textContent,
            fill: document.getElementById('moonIlluminatedPath').style.fill || '(none)',
            layerOpacity: document.getElementById('eclipseShadows').getAttribute('opacity')
        })).catch(e => console.log('frame eval fail:', e.message));
        console.log(JSON.stringify(info));
        await frame.evaluate(() => {
            const sel = document.getElementById('eclipseSelect');
            const ev = eclipseEvents.filter(e => e.t0 > Date.now())[0];
            sel.value = String(ev.t0); sel.dispatchEvent(new Event('change', { bubbles: true }));
        }).catch(e => console.log('select fail:', e.message));
        await new Promise(r => setTimeout(r, 12000));
        const after = await frame.evaluate(() => ({
            t: new Date(previewState.t).toTimeString().slice(0,5),
            layerOpacity: document.getElementById('eclipseShadows').getAttribute('opacity'),
            penOpacityAttr: document.getElementById('penumbraStop0').getAttribute('stop-opacity'),
            umbCx: document.getElementById('umbraShadow').getAttribute('cx')
        })).catch(e => console.log('after eval fail:', e.message));
        console.log('after preview:', JSON.stringify(after));
    }
    await page.screenshot({ path: 'iframe-test.png' });
    await browser.close();
})();

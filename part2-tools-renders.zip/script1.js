
        const phases = [
            "New Moon", "Waxing Crescent", "First Quarter", "Waxing Gibbous",
            "Full Moon", "Waning Gibbous", "Last Quarter", "Waning Crescent"
        ];

        /* ================================================================
           184 ORIGINAL CULTURAL MOON POEMS – 23 locales × 8 phases
           Each phase poem names a well-attested cultural, literary, artistic,
           historical, scientific, or mythic thread. Non-English originals include
           close English renderings. These are new poems, not traditional quotations.
           ================================================================ */
        const poems = {
            "en": {
                "0": {
                    "n": "At moonless Newgrange, Brigid cups one coal.\nNo bard names the road before it opens;\ndarkness is the page that keeps the first word.",
                    "e": "",
                    "c": "Irish threads · Brigid and Newgrange"
                },
                "1": {
                    "n": "Hopkins finds a silver grammar over Wales:\none curved syllable sprung from the dark.\nThe young moon writes before it speaks.",
                    "e": "",
                    "c": "British–Irish poetry · Gerard Manley Hopkins"
                },
                "2": {
                    "n": "Shakespeare sends Moonshine on with lantern, bush, and dog.\nHalf the light is wonder, half is theatre;\nPuck grins where certainty forgot its lines.",
                    "e": "",
                    "c": "English theatre · Shakespeare’s Moonshine and Puck"
                },
                "3": {
                    "n": "Over Coole, Yeats counts the swans again.\nThe moon grows round; the water keeps moving.\nWhat ripens in us need not remain.",
                    "e": "",
                    "c": "Irish poetry · W. B. Yeats and Coole Park"
                },
                "4": {
                    "n": "Keats wakes Endymion beneath a moon made whole.\nAcross the moor, every heather-bell holds silver;\nbeauty stays one night, and that is enough.",
                    "e": "",
                    "c": "English poetry · John Keats and Endymion"
                },
                "5": {
                    "n": "Dylan Thomas lets Llareggub dream past midnight.\nThe moon withdraws from every slate roof slowly,\nleaving each sleeper one bright, private word.",
                    "e": "",
                    "c": "Welsh poetry · Dylan Thomas and Llareggub"
                },
                "6": {
                    "n": "The Cailleach lifts her staff above the Highland pass.\nHalf a moon hardens the loch to pewter.\nOld wisdom knows what winter must release.",
                    "e": "",
                    "c": "Scottish and Irish folklore · the Cailleach"
                },
                "7": {
                    "n": "Heaney turns one last pale sod with his pen.\nA sickle moon hangs over the listening bog;\nwhat goes underground is not always gone.",
                    "e": "",
                    "c": "Irish poetry · Seamus Heaney and the bog landscape"
                }
            },
            "de": {
                "0": {
                    "n": "Kepler rechnet in Prag, doch der Mond bleibt unsichtbar.\nSeine Kreide zieht eine Bahn durch die Schwärze;\nauch das Verborgene gehorcht einem stillen Maß.",
                    "e": "Kepler calculates in Prague, though the moon stays unseen.\nHis chalk draws an orbit through the blackness;\neven the hidden obeys a quiet measure.",
                    "c": "German astronomy · Johannes Kepler"
                },
                "1": {
                    "n": "Caspar David Friedrich stellt zwei Wanderer ins Blau.\nÜber ihnen hält die Sichel den Atem an;\nStaunen braucht keinen breiten Weg.",
                    "e": "Caspar David Friedrich sets two wanderers in the blue.\nAbove them the crescent holds its breath;\nwonder needs no broad road.",
                    "c": "German Romantic art · Caspar David Friedrich"
                },
                "2": {
                    "n": "Goethe spricht an der Ilm zum halben Mond.\nLicht und Schatten teilen dasselbe Wasser;\ndas Herz muss nicht nur eine Seite wählen.",
                    "e": "Goethe speaks to the half moon beside the Ilm.\nLight and shadow share the same water;\nthe heart need not choose only one side.",
                    "c": "German poetry · Goethe’s moon lyric and the River Ilm"
                },
                "3": {
                    "n": "Hildegard sieht grünes Leben unter wachsendem Licht.\nKräuter heben ihre Namen aus der Klostererde;\nder fast volle Mond segnet nichts — er macht es sichtbar.",
                    "e": "Hildegard sees living greenness beneath the growing light.\nHerbs lift their names from the abbey earth;\nthe nearly full moon blesses nothing—it makes it visible.",
                    "c": "Rhineland vision and healing · Hildegard of Bingen"
                },
                "4": {
                    "n": "Novalis öffnet seine Hymnen in die Nacht.\nDer volle Mond liegt wie ein Siegel auf Thüringen;\nwas wir lieben, leuchtet auch in der Ferne.",
                    "e": "Novalis opens his hymns into the night.\nThe full moon lies like a seal on Thuringia;\nwhat we love gives light even from afar.",
                    "c": "German Romantic poetry · Novalis"
                },
                "5": {
                    "n": "Rilke hört den Mond aus dem Rosengarten gehen.\nEin Blatt nach dem andern verliert sein Silber;\nAbschied ist eine Form der Verwandlung.",
                    "e": "Rilke hears the moon leaving the rose garden.\nLeaf after leaf loses its silver;\nfarewell is a form of transformation.",
                    "c": "German-language poetry · Rainer Maria Rilke"
                },
                "6": {
                    "n": "Caroline Herschel kehrt den Himmel mit dem Fernrohr.\nDer Halbmond sinkt, ein Komet tritt aus dem Dunkel;\nwer lange schaut, findet Bewegung im Verlust.",
                    "e": "Caroline Herschel sweeps the sky with her telescope.\nThe half moon sinks; a comet steps from the dark.\nWhoever watches long finds motion inside loss.",
                    "c": "German-born astronomy · Caroline Herschel"
                },
                "7": {
                    "n": "Frau Holle schüttelt Federn über ein schmales Licht.\nDie alte Mondfrau näht die Nacht wieder zu;\nunter dem Schnee bewahrt die Erde ihr Morgen.",
                    "e": "Frau Holle shakes feathers over a narrow light.\nThe old moon-woman sews the night closed again;\nbeneath the snow, earth keeps its morning.",
                    "c": "German folklore · Frau Holle"
                }
            },
            "it": {
                "0": {
                    "n": "Nel bosco di Nemi, Diana spegne la torcia.\nIl lago trattiene un cielo senza luna;\nla cacciatrice insegna al silenzio a non temere.",
                    "e": "In the grove at Nemi, Diana lowers her torch.\nThe lake holds a moonless sky;\nthe huntress teaches silence not to fear.",
                    "c": "Roman tradition · Diana at Lake Nemi"
                },
                "1": {
                    "n": "Galileo alza il cannocchiale verso una falce sottile.\nSulla luce trova monti, nell’ombra altre domande;\nun piccolo arco rovescia un cielo perfetto.",
                    "e": "Galileo raises his telescope toward a slender crescent.\nIn the light he finds mountains, in shadow more questions;\none small arc overturns a perfect heaven.",
                    "c": "Italian astronomy · Galileo Galilei"
                },
                "2": {
                    "n": "Dante sosta a metà del cammino e guarda in alto.\nMezza luna divide la selva dalla strada;\nVirgilio dice: anche il dubbio può guidare.",
                    "e": "Dante pauses midway on the journey and looks up.\nA half moon divides the wood from the road;\nVirgil says: even doubt can guide.",
                    "c": "Italian epic · Dante and Virgil"
                },
                "3": {
                    "n": "Ariosto manda Astolfo verso la luna crescente.\nLassù ritrova il senno perduto sulla terra;\nquasi piena, la notte raccoglie ciò che scordiamo.",
                    "e": "Ariosto sends Astolfo toward the growing moon.\nThere he finds the reason lost on earth;\nnearly full, the night gathers what we forget.",
                    "c": "Italian epic · Ariosto’s Astolfo on the Moon"
                },
                "4": {
                    "n": "Il pastore di Leopardi interroga la luna piena.\nLei passa sopra l’Appennino senza rispondere;\nla domanda, illuminata, diventa compagnia.",
                    "e": "Leopardi’s shepherd questions the full moon.\nShe crosses the Apennines without answering;\nthe question, illuminated, becomes company.",
                    "c": "Italian poetry · Giacomo Leopardi"
                },
                "5": {
                    "n": "Qfwfq ricorda quando la luna sfiorava il mare.\nCalvino gli lascia una scala e un secchio di latte;\nora la luce si allontana, ma il racconto resta vicino.",
                    "e": "Qfwfq remembers when the moon brushed the sea.\nCalvino leaves him a ladder and a pail of milk;\nnow the light recedes, but the story stays near.",
                    "c": "Italian fiction · Italo Calvino’s Qfwfq"
                },
                "6": {
                    "n": "Margherita Hack traccia crateri sotto mezza luce.\nLa carta non promette destino, soltanto distanza;\ne proprio la distanza rende preciso lo sguardo.",
                    "e": "Margherita Hack maps craters beneath a half light.\nThe chart promises no destiny, only distance;\nand distance itself makes the gaze exact.",
                    "c": "Italian astronomy · Margherita Hack"
                },
                "7": {
                    "n": "Ungaretti riduce la notte a un respiro d’argento.\nLa falce cala dietro le case di pietra;\nresta una parola nuda, abbastanza per l’alba.",
                    "e": "Ungaretti pares the night to one silver breath.\nThe crescent lowers behind the stone houses;\none bare word remains, enough for dawn.",
                    "c": "Italian poetry · Giuseppe Ungaretti"
                }
            },
            "hu": {
                "0": {
                    "n": "Holdtalan éjben a táltos felmászik az égig érő fára.\nÁgai közt a sötétség őrzi a kimondatlan dalt;\nami még nem látszik, attól még úton van.",
                    "e": "On a moonless night the táltos climbs the sky-high tree.\nAmong its branches darkness guards the unsung song;\nwhat cannot yet be seen may still be on its way.",
                    "c": "Hungarian folk belief · the táltos and sky-high tree"
                },
                "1": {
                    "n": "Petőfi lelkéből holdsugárnyi vers szökik a pusztára.\nA vékony sarló még nem arat, csak ígér;\negyetlen sor is hazatalál a csillagok között.",
                    "e": "A moonbeam of verse escapes Petőfi’s soul onto the plain.\nThe thin sickle does not reap yet; it only promises.\nEven one line can find home among the stars.",
                    "c": "Hungarian poetry · Sándor Petőfi"
                },
                "2": {
                    "n": "Arany János Ágnese félholdnál mossa a lepedőt.\nA víz egyik fele fény, a másik emlékezet;\na patak nem ítél, csak továbbviszi az éjszakát.",
                    "e": "János Arany’s Ágnes washes the sheet by a half moon.\nOne half of the water is light, the other memory;\nthe stream does not judge—it carries the night onward.",
                    "c": "Hungarian ballad · János Arany’s Ágnes asszony"
                },
                "3": {
                    "n": "A csodaszarvas homlokán csillag, szügyén növő hold.\nHunor és Magor követi a nádason át;\na majdnem teljes fény nem cél, hanem hívás.",
                    "e": "The Wondrous Stag bears a star on its brow, a growing moon on its breast.\nHunor and Magor follow through the reeds;\nthe nearly whole light is not a destination but a call.",
                    "c": "Hungarian origin legend · the Wondrous Stag, Hunor and Magor"
                },
                "4": {
                    "n": "Radnóti Miklós noteszére telihold hull.\nA legszűkebb úton is megőrzi a pontos sort;\naz emberi hang nem kisebb a rettenetnél.",
                    "e": "Full moon falls across Miklós Radnóti’s notebook.\nEven on the narrowest road he keeps the line exact;\nthe human voice is no smaller than terror.",
                    "c": "Hungarian poetry and remembrance · Miklós Radnóti"
                },
                "5": {
                    "n": "József Attila udvarában rózsa nyílik a fogyó hold körül.\nA Duna minden fénydarabot magával visz;\nami csökken, attól még mélyülhet.",
                    "e": "In Attila József’s courtyard a rose opens around the waning moon.\nThe Danube carries every shard of light;\nwhat diminishes may still grow deeper.",
                    "c": "Hungarian poetry · Attila József and the Danube"
                },
                "6": {
                    "n": "Konkoly-Thege Miklós Ógyallán az okulár fölé hajol.\nFélhold áll a csillagvizsgáló rézkupoláján;\na mérés is lehet az áhítat egyik formája.",
                    "e": "Miklós Konkoly-Thege bends over the eyepiece at Ógyalla.\nA half moon rests on the observatory’s copper dome;\nmeasurement, too, can be a form of reverence.",
                    "c": "Hungarian astronomy · Miklós Konkoly-Thege"
                },
                "7": {
                    "n": "A markoláb már csak a holdsarló szélét harapja.\nA falusi dobok közt hátrál az égi falánk;\na fény elfogy, de a történet visszahívja.",
                    "e": "The markoláb bites only the rim of the lunar sickle now.\nAmong village drums the sky-devourer retreats;\nthe light runs out, but the story calls it back.",
                    "c": "Hungarian eclipse folklore · the markoláb"
                }
            },
            "fi": {
                "0": {
                    "n": "Ilmatar kelluu pimeässä, eikä kuuta vielä ole.\nSotkan muna särkyy hänen polveltaan mereen;\nvalkuaisessa odottaa valo, jota kukaan ei näe.",
                    "e": "Ilmatar floats in darkness, and there is no moon yet.\nA scaup’s egg breaks from her knee into the sea;\nwithin its white waits a light no one can see.",
                    "c": "Kalevala creation poetry · Ilmatar and the world egg"
                },
                "1": {
                    "n": "Kuutar kehrää ensimmäisen hopealangan männyn ylle.\nLanka on ohut, mutta se löytää jokaisen neulansilmän;\nyö alkaa ommella itseään valoksi.",
                    "e": "Kuutar spins the first silver thread above the pine.\nThe thread is thin, yet finds every needle’s eye;\nnight begins sewing itself into light.",
                    "c": "Finnish runic tradition · Kuutar, Maiden of the Moon"
                },
                "2": {
                    "n": "Väinämöinen virittää kanteleen puolikuun alla.\nYksi kieli vastaa valolle, toinen varjolle;\nsävel syntyy siitä, etteivät ne ole sama.",
                    "e": "Väinämöinen tunes the kantele beneath a half moon.\nOne string answers light, another shadow;\nthe melody is born because they are not the same.",
                    "c": "Kalevala song tradition · Väinämöinen"
                },
                "3": {
                    "n": "Lönnrot kulkee kylästä kylään kasvavan kuun kanssa.\nSäe liittyy säkeeseen kuin järvi seuraavaan;\nmelkein täysi laulu muistaa monta laulajaa.",
                    "e": "Lönnrot walks village to village with the waxing moon.\nOne verse joins another like lake following lake;\na nearly whole song remembers many singers.",
                    "c": "Finnish oral poetry · Elias Lönnrot and the rune singers"
                },
                "4": {
                    "n": "Eino Leino antaa täyden kuun levätä kesäyössä.\nKoivu ei kysy, onko tämä päivä vai uni;\nvalo on kokonainen, vaikka yö on lyhyt.",
                    "e": "Eino Leino lets the full moon rest in the summer night.\nThe birch does not ask whether this is day or dream;\nthe light is whole, though the night is brief.",
                    "c": "Finnish poetry · Eino Leino and the summer night"
                },
                "5": {
                    "n": "Tove Janssonin Muumilaakso hiljenee vähenevän kuun alle.\nMuumipeikko sulkee kuistin, meri hengittää yhä;\nkoti säilyy, vaikka valo lähtee.",
                    "e": "Tove Jansson’s Moominvalley quiets beneath the waning moon.\nMoomintroll closes the veranda; the sea still breathes.\nHome remains even when the light departs.",
                    "c": "Finnish literature · Tove Jansson and Moominvalley"
                },
                "6": {
                    "n": "Yrjö Väisälä mittaa puolen kuun ja kaukaisen tähden.\nTurun yö piirtää lasiin tarkan kaaren;\nihmettely ei vähene, kun luku tarkentuu.",
                    "e": "Yrjö Väisälä measures the half moon and a distant star.\nThe Turku night draws an exact arc in glass;\nwonder does not shrink when the number grows precise.",
                    "c": "Finnish astronomy · Yrjö Väisälä"
                },
                "7": {
                    "n": "Sápmin yllä Mánnu kapenee poropolun viereen.\nJoiku kantaa valon, kun silmä ei enää kanna;\nviimeinen sirppi ei päätä taivaan rytmiä.",
                    "e": "Above Sápmi, Mánnu narrows beside the reindeer trail.\nA joik carries the light when the eye no longer can;\nthe last crescent does not end the sky’s rhythm.",
                    "c": "Northern Sámi thread · Mánnu and joik, placed here with regional care"
                }
            },
            "ru": {
                "0": {
                    "n": "Месяц скрыт, и Марья Моревна едет без тени.\nЗа чёрным лесом дорога ещё не выбрала имя;\nв русской сказке тьма — не конец, а закрытая дверь.",
                    "e": "The moon is hidden, and Marya Morevna rides without a shadow.\nBeyond the black forest the road has not chosen a name;\nin the Russian tale, darkness is not an end but a closed door.",
                    "c": "Russian wonder tale · Marya Morevna"
                },
                "1": {
                    "n": "Пушкин кладёт серебряный серп над Лукоморьем.\nУчёный кот на миг перестаёт ходить по цепи;\nодной полоски света хватает, чтобы начать рассказ.",
                    "e": "Pushkin sets a silver crescent above Lukomorye.\nThe learned cat pauses on his golden chain;\none strip of light is enough to begin a tale.",
                    "c": "Russian poetry and folklore · Alexander Pushkin’s Lukomorye"
                },
                "2": {
                    "n": "Ахматова стоит у Невы под половиной луны.\nОдин берег хранит голос, другой — молчание;\nмежду ними вода не перестаёт отвечать.",
                    "e": "Akhmatova stands by the Neva beneath a half moon.\nOne bank keeps the voice, the other silence;\nbetween them the water never stops replying.",
                    "c": "Russian poetry · Anna Akhmatova and the Neva"
                },
                "3": {
                    "n": "Цветаева поднимает строку к почти полной луне.\nМосковские крыши тесны, а голосу теснее;\nон перелетает через каждую закрытую башню.",
                    "e": "Tsvetaeva lifts a line toward the nearly full moon.\nMoscow’s roofs are narrow, the voice narrower still;\nit flies across every shuttered tower.",
                    "c": "Russian poetry · Marina Tsvetaeva"
                },
                "4": {
                    "n": "В Калуге Циолковский раскрывает тетрадь под полнолунием.\nЛуна уже не только сказка, но и место пути;\nмечта впервые чертит лестницу из чисел.",
                    "e": "In Kaluga, Tsiolkovsky opens a notebook under the full moon.\nThe Moon is no longer only a tale, but somewhere to travel;\nthe dream first sketches a ladder made of numbers.",
                    "c": "Russian space thought · Konstantin Tsiolkovsky"
                },
                "5": {
                    "n": "Аппарат Бабакина шепчет с Луны в Евпаторию.\nСигнал слабеет, но успевает пересечь пустоту;\nубывающий свет тоже приносит весть домой.",
                    "e": "Babakin’s craft whispers from the Moon to Yevpatoria.\nThe signal weakens, yet crosses the emptiness in time;\nwaning light also carries news home.",
                    "c": "Soviet lunar exploration · Georgy Babakin and Luna 9"
                },
                "6": {
                    "n": "Есенин оставляет пол-луны в ветвях берёзы.\nБелый ствол держит холодный остаток света;\nдеревня слышит, как осень закрывает ворота.",
                    "e": "Yesenin leaves half a moon among the birch branches.\nThe white trunk holds the cold remainder of light;\nthe village hears autumn closing the gate.",
                    "c": "Russian poetry · Sergei Yesenin and the birch landscape"
                },
                "7": {
                    "n": "Баба-яга заметает следы под последним серпом.\nИзбушка поворачивается к тёмному лесу;\nисчезнувшая тропа запомнит смелого путника.",
                    "e": "Baba Yaga sweeps away tracks beneath the final crescent.\nHer hut turns toward the dark forest;\nthe vanished path will remember the brave traveler.",
                    "c": "Russian folklore · Baba Yaga and the hut on chicken legs"
                }
            },
            "ku": {
                "0": {
                    "n": "Heyv tune ye; Ehmedê Xanî rûpela yekem vedike.\nMem û Zîn hîn navê hev di tarîtiyê de nabêjin;\nevîn berî ronahiyê jî rêya xwe dizane.",
                    "e": "There is no moon; Ehmedê Xanî opens the first page.\nMem and Zîn have not yet spoken each other’s names in the dark;\nlove knows its road even before the light.",
                    "c": "Kurdish literature · Ehmedê Xanî’s Mem û Zîn"
                },
                "1": {
                    "n": "Li ser Cizîrê heyveke zirav radibe.\nZîn di cejna Newrozê de Mem dibîne;\nronahiyeke biçûk dikare du çîrok dest pê bike.",
                    "e": "A slender moon rises above Cizre.\nAt the Newroz feast, Zîn sees Mem;\none small light can begin two lives as a story.",
                    "c": "Kurdish epic · Mem and Zîn at Newroz"
                },
                "2": {
                    "n": "Evdalê Zeynikê di bin nîvheyvê de dibêje.\nNîvê stranê çiya digire, nîvê din gelî;\ndeng rêyek e ku sînor nikare wê bibire.",
                    "e": "Evdalê Zeynikê sings beneath the half moon.\nHalf the song belongs to the mountain, half to the valley;\na voice is a road no border can cut.",
                    "c": "Kurdish oral song · dengbêj Evdalê Zeynikê"
                },
                "3": {
                    "n": "Feqiyê Teyran ji teyran dipirse: heyv çima mezin dibe?\nEw bersivê ji çem û berfê tînin;\nher tiştê ku ber bi tijîbûnê ve diçe, divê guhdarî bike.",
                    "e": "Feqiyê Teyran asks the birds why the moon grows.\nThey bring an answer from river and snow;\nwhatever moves toward fullness must learn to listen.",
                    "c": "Kurdish mystical poetry · Feqiyê Teyran"
                },
                "4": {
                    "n": "Heyva tijî li ser welatê Cegerxwîn disekine.\nHelbestvan navê gund, cotkar û zarok dibêje;\nronahî tenê ya ezman nîne, ya dengê mirovan jî ye.",
                    "e": "The full moon stands above Cegerxwîn’s homeland.\nThe poet names village, farmer, and child;\nlight belongs not only to the sky, but also to human voices.",
                    "c": "Modern Kurdish poetry · Cegerxwîn"
                },
                "5": {
                    "n": "Mestûre Erdelan dîrokê di ronahiya kêm de dinivîse.\nHeyv li ser Senendecê hêdî kêm dibe;\nqelem tiştên ku şev ji bîr dike diparêze.",
                    "e": "Mastura Ardalan writes history in the fading light.\nThe moon slowly wanes above Sanandaj;\nthe pen protects what night might forget.",
                    "c": "Kurdish poetry and history · Mastura Ardalan"
                },
                "6": {
                    "n": "Nalî ji Hewlêr û Silêmaniyê re nîv ronahî dihêle.\nGul di bayê payîzê de serê xwe ditewîne;\nhelbest ji kêmbûnê jî awazek çêdike.",
                    "e": "Nalî leaves half a light to Erbil and Sulaymaniyah.\nThe rose bows its head in the autumn wind;\npoetry can make a music even from diminishing.",
                    "c": "Classical Kurdish poetry · Nalî"
                },
                "7": {
                    "n": "Şêrko Bêkes heyva dawî dixe berika helbestê.\nLi pişt çiyayan tenê xêzek ronahiyê dimîne;\nsibê, peyv wê ji tarîtiyê dîsa derkeve.",
                    "e": "Sherko Bekas slips the last moon into poetry’s pocket.\nBehind the mountains only a line of light remains;\ntomorrow, the word will step from darkness again.",
                    "c": "Modern Kurdish poetry · Sherko Bekas"
                }
            },
            "he": {
                "0": {
                    "n": "בראש חודש נסתר דוד בשדה ויהונתן שומר את הסוד.\nאין ירח מעל האבן המסומנת;\nחברות יודעת למצוא דרך גם בלי אור.",
                    "e": "At the new moon David hides in the field, and Jonathan keeps the secret.\nNo moon hangs above the marked stone;\nfriendship knows how to find a road without light.",
                    "c": "Hebrew Bible · David and Jonathan at the new moon"
                },
                "1": {
                    "n": "רבן גמליאל מראה לעדים צורות של לבנה על הלוח.\nקו כסף דק קובע את תחילת החודש;\nלפעמים הזמן כולו תלוי בעדות קטנה.",
                    "e": "Rabban Gamliel shows the witnesses shapes of the moon on a tablet.\nA thin silver line sets the month in motion;\nsometimes all of time depends on a small testimony.",
                    "c": "Mishnah Rosh Hashanah · Rabban Gamliel and lunar witnesses"
                },
                "2": {
                    "n": "יהודה הלוי מביט מזרחה מתחת לחצי ירח.\nחצי לבו בספרד, חציו בדרך לירושלים;\nהגעגוע משלים מה שהשמיים מחלקים.",
                    "e": "Yehuda Halevi looks east beneath a half moon.\nHalf his heart is in Spain, half on the road to Jerusalem;\nlonging completes what the sky divides.",
                    "c": "Medieval Hebrew poetry · Yehuda Halevi"
                },
                "3": {
                    "n": "רחל יושבת על שפת הכנרת והלבנה כמעט מלאה.\nהרי הגולן אוספים אור מעל המים;\nשיר קצר מחזיק מרחק גדול.",
                    "e": "Rachel sits by the Sea of Galilee beneath a nearly full moon.\nThe Golan hills gather light above the water;\na short poem can hold a great distance.",
                    "c": "Modern Hebrew poetry · Rachel Bluwstein and the Kinneret"
                },
                "4": {
                    "n": "לבנה מלאה עומדת מעל עמק איילון.\nיהושע ביקש שתעמוד; הלילה היא עדה, לא פקודה.\nאור שלם מזכיר כמה כבדה כל בקשה.",
                    "e": "A full moon stands above the Valley of Aijalon.\nJoshua once asked it to stop; tonight it is witness, not command.\nWhole light reminds us how heavy every request can be.",
                    "c": "Hebrew Bible · Joshua and the Moon over Aijalon"
                },
                "5": {
                    "n": "לאה גולדברג הולכת ברחוב תל־אביבי והירח פוחת.\nחלון אחר חלון מחזיר לה פיסה אחרת;\nאין נוף אחד לאהבה שעוזבת.",
                    "e": "Leah Goldberg walks a Tel Aviv street as the moon wanes.\nWindow after window returns a different fragment;\nthere is no single landscape for a love that leaves.",
                    "c": "Modern Hebrew poetry · Leah Goldberg"
                },
                "6": {
                    "n": "אילן רמון נושא זיכרון אל מעבר למחצית האור.\nכדור הארץ כחול בחלון, הירח שקט ורחוק;\nמה שלוקחים לשמיים נשאר גם בבית.",
                    "e": "Ilan Ramon carries memory beyond the half light.\nEarth is blue in the window; the Moon is quiet and far.\nWhat we carry into the sky also remains at home.",
                    "c": "Israeli spaceflight and remembrance · Ilan Ramon"
                },
                "7": {
                    "n": "עגנון סוגר תריס בירושלים מול סהר אחרון.\nהאותיות נשארות ערות בחדר החשוך;\nסיפור טוב יודע לחכות למולד הבא.",
                    "e": "Agnon closes a Jerusalem shutter against the final crescent.\nThe letters remain awake in the darkened room;\na good story knows how to wait for the next new moon.",
                    "c": "Hebrew literature · S. Y. Agnon"
                }
            },
            "ar": {
                "0": {
                    "n": "في عتمة المحاق يفتح ابن الهيثم نافذة صغيرة.\nلا قمر في سماء القاهرة، لكن الضوء يرسم طريقه؛\nمن الظلمة تبدأ معرفة البصر.",
                    "e": "In the darkness of the new moon, Ibn al-Haytham opens a tiny aperture.\nNo moon is in Cairo’s sky, yet light draws its path;\nfrom darkness begins the knowledge of sight.",
                    "c": "Arabic optics and astronomy · Ibn al-Haytham"
                },
                "1": {
                    "n": "يرصد البتّاني هلالاً دقيقاً فوق حرّان.\nبين إصبعين من فضة يقيس بداية الشهر؛\nالدقة نوع آخر من الدهشة.",
                    "e": "Al-Battani observes a fine crescent above Harran.\nBetween two fingers of silver he measures the month’s beginning;\nprecision is another kind of wonder.",
                    "c": "Arab astronomy · al-Battani"
                },
                "2": {
                    "n": "يضع ابن يونس نصف القمر في جداول القاهرة.\nنصفه رقم ونصفه ضوء على النيل؛\nوالسماء تتّسع للحساب والقصيدة معاً.",
                    "e": "Ibn Yunus places the half moon in his Cairo tables.\nHalf is number, half is light upon the Nile;\nthe sky has room for calculation and poem together.",
                    "c": "Egyptian Arab astronomy · Ibn Yunus"
                },
                "3": {
                    "n": "الخنساء ترفع رثاءها إلى قمر يكاد يكتمل.\nكلما اتّسع الضوء ظهر الغائب أوضح؛\nالحزن أيضاً يعرف كيف ينمو بلا ضجيج.",
                    "e": "Al-Khansa raises her elegy to a moon nearly full.\nAs the light widens, the absent one appears more clearly;\ngrief, too, knows how to grow without noise.",
                    "c": "Classical Arabic poetry · al-Khansa"
                },
                "4": {
                    "n": "يملأ البدر ساحة المتنبي من دمشق إلى بغداد.\nيشبّه الشاعر الممدوح بالقمر ثم يترك القمر حراً؛\nفالضياء الكامل لا يحتاج إلى مبالغة.",
                    "e": "The full moon fills al-Mutanabbi’s road from Damascus to Baghdad.\nThe poet likens the praised one to the moon, then lets the moon go free;\ncomplete radiance needs no exaggeration.",
                    "c": "Classical Arabic poetry · al-Mutanabbi"
                },
                "5": {
                    "n": "يمشي محمود درويش تحت قمر يتناقص فوق فلسطين.\nيحمل في جيبه مفتاحاً ووزنَ قصيدة؛\nما ينقص من الضوء يزيد في الذاكرة.",
                    "e": "Mahmoud Darwish walks beneath a waning moon over Palestine.\nIn his pocket he carries a key and the weight of a poem;\nwhat leaves the light enters memory.",
                    "c": "Palestinian Arabic poetry · Mahmoud Darwish"
                },
                "6": {
                    "n": "يرتفع صوت فيروز بين سطوح بيروت ونصف القمر.\nتفتح نافذة، ثم نافذة، على اللحن نفسه؛\nحتى الضوء الناقص يستطيع أن يجمع الجيران.",
                    "e": "Fairuz’s voice rises among Beirut roofs and a half moon.\nOne window, then another, opens to the same melody;\neven incomplete light can gather neighbors.",
                    "c": "Lebanese song · Fairuz and Beirut"
                },
                "7": {
                    "n": "أم كلثوم تمدّ الليل حتى آخر خيط من الهلال.\nيسكت العود لحظة، ولا ينتهي الطرب؛\nحين يغيب القمر يبقى الصوت دليلاً.",
                    "e": "Umm Kulthum stretches the night to the crescent’s final thread.\nThe oud falls silent for a moment, but ecstasy does not end;\nwhen the moon disappears, the voice remains a guide.",
                    "c": "Egyptian Arab song · Umm Kulthum"
                }
            },
            "hi": {
                "0": {
                    "n": "अमावस्या में शिव की जटाओं का चंद्र भी छिपा है।\nकैलास पर डमरू से पहले एक गहरा विराम उतरता है;\nसोम अदृश्य है, पर समय की नाड़ी चलती रहती है।",
                    "e": "At new moon even the crescent in Shiva’s hair is hidden.\nOn Kailash, a deep pause falls before the drum;\nSoma is unseen, yet the pulse of time continues.",
                    "c": "Hindu tradition · Shiva and Chandra/Soma"
                },
                "1": {
                    "n": "कालिदास का मेघ पतली चाँद-रेखा के नीचे उत्तर जाता है।\nयक्ष का संदेश अभी छोटा है, उसकी आशा नहीं;\nपहली रोशनी दूर बसे प्रिय का पता लिखती है।",
                    "e": "Kalidasa’s cloud travels north beneath a thin moon-line.\nThe yaksha’s message is still small, but not his hope;\nthe first light writes the address of the distant beloved.",
                    "c": "Sanskrit literature · Kalidasa’s Meghadūta"
                },
                "2": {
                    "n": "आर्यभट आधे चंद्र को छाया नहीं, सूर्य का प्रकाश बताते हैं।\nपटना के ऊपर गणना और विस्मय साथ बैठते हैं;\nज्ञान आकाश से कथा नहीं छीनता।",
                    "e": "Aryabhata explains the half moon through sunlight, not its own shadow.\nAbove Pataliputra, calculation and wonder sit together;\nknowledge does not steal story from the sky.",
                    "c": "Indian astronomy · Aryabhata and reflected lunar light"
                },
                "3": {
                    "n": "मीरा बढ़ते चंद्र के नीचे कृष्ण को पुकारती हैं।\nमंदिर की सीढ़ियों पर घुँघरू और प्रतीक्षा साथ बजते हैं;\nलगभग पूरा प्रकाश भी विरह को पूरा नहीं करता।",
                    "e": "Mirabai calls to Krishna beneath the waxing moon.\nOn the temple steps, ankle bells and waiting sound together;\nnearly whole light cannot make longing whole.",
                    "c": "Bhakti poetry · Mirabai and Krishna"
                },
                "4": {
                    "n": "पूर्णिमा पर सरोजिनी नायडू गीत का द्वार खोलती हैं।\nदक्कन की रात में पालकी, बाज़ार और नदी चमकते हैं;\nचाँद हर आवाज़ को अपनी अलग चाँदी देता है।",
                    "e": "At full moon Sarojini Naidu opens the gate of song.\nIn the Deccan night, palanquin, bazaar, and river shine;\nthe moon gives every voice its own silver.",
                    "c": "Indian poetry · Sarojini Naidu and the Deccan"
                },
                "5": {
                    "n": "कबीर के करघे पर घटता चंद्र धागा बन जाता है।\nएक ताना देह का, एक बाना उस अनदेखे नाम का;\nकम होती रोशनी से भी पूरा कपड़ा बुना जाता है।",
                    "e": "On Kabir’s loom the waning moon becomes thread.\nOne strand is body, one the unseen Name;\na whole cloth can be woven from diminishing light.",
                    "c": "Bhakti poetry · Kabir and the weaver’s loom"
                },
                "6": {
                    "n": "आधे बचे चंद्र को गणेश की पुरानी कथा याद आती है।\nहँसी, अभिमान और क्षमा एक ही आकाश में घूमते हैं;\nबुद्धि जानती है कि टूटा रूप भी लौटता है।",
                    "e": "The half-remaining moon remembers the old tale of Ganesha.\nLaughter, pride, and forgiveness turn in one sky;\nwisdom knows that a broken shape can return.",
                    "c": "Hindu storytelling · Ganesha and the Moon"
                },
                "7": {
                    "n": "रितु करिधल अंतिम चंद्र-रेखा के नीचे आँकड़े पढ़ती हैं।\nपृथ्वी से भेजी आवाज़ अंतरिक्ष की चुप्पी पार करती है;\nअगली उड़ान पहले अँधेरे में जन्म लेती है।",
                    "e": "Ritu Karidhal reads the data beneath the final moon-line.\nA voice sent from Earth crosses the silence of space;\nthe next flight is born first in darkness.",
                    "c": "Indian lunar exploration · space scientist Ritu Karidhal"
                }
            },
            "zn": {
                "0": {
                    "n": "朔夜无月，嫦娥的广寒宫也隐入黑暗。\n后羿把弓放在桂树未见的影子旁；\n团圆的故事，先从看不见开始。",
                    "e": "On the moonless night, even Chang’e’s Cold Palace vanishes into dark.\nHou Yi lays down his bow beside the unseen cassia shadow;\nevery story of reunion begins with what cannot be seen.",
                    "c": "Chinese moon lore · Chang’e and Hou Yi"
                },
                "1": {
                    "n": "一弯新月像后羿未放的箭。\n它越过村瓦，指向嫦娥远去的方向；\n最细的光，也能把思念拉满。",
                    "e": "The young crescent is like an arrow Hou Yi has not released.\nIt crosses the tiled roofs, pointing where Chang’e departed;\nthe thinnest light can draw longing to its full span.",
                    "c": "Chinese moon lore · Hou Yi’s bow and Chang’e"
                },
                "2": {
                    "n": "张衡在浑天仪旁看见半轮月。\n一半可量，一半藏在夜里；\n天地不因被测量就少了神秘。",
                    "e": "Zhang Heng sees a half moon beside his armillary sphere.\nOne half can be measured; one half hides in night.\nHeaven and earth lose no mystery by being measured.",
                    "c": "Chinese astronomy · Zhang Heng"
                },
                "3": {
                    "n": "吴刚在渐满的月下砍桂树。\n斧痕才深，树身又合；\n有些功课不是为了完成，而是为了坚持。",
                    "e": "Wu Gang cuts the cassia beneath the waxing moon.\nAs soon as the axe bites deep, the trunk closes;\nsome tasks are not for finishing, but for enduring.",
                    "c": "Chinese moon lore · Wu Gang and the self-healing cassia"
                },
                "4": {
                    "n": "满月升起，李白举杯，请来月与影。\n三位朋友在花间各守一份孤独；\n今夜，孤独也有圆满的座位。",
                    "e": "The full moon rises; Li Bai raises a cup to moon and shadow.\nThree friends among flowers each keep a share of solitude;\ntonight even loneliness has a seat at the reunion.",
                    "c": "Tang poetry · Li Bai drinking with the Moon"
                },
                "5": {
                    "n": "苏轼望着开始亏缺的月，想起远方的人。\n人的聚散与月的圆缺同桌而坐；\n不完美，也可以把千里照在一起。",
                    "e": "Su Shi watches the moon begin to wane and thinks of someone far away.\nHuman parting and lunar change sit at one table;\nimperfection can still light a thousand miles together.",
                    "c": "Song poetry · Su Shi and Mid-Autumn longing"
                },
                "6": {
                    "n": "杜甫在半轮秋月下忆起弟弟。\n露水先白，故乡在战乱外更明；\n缺去的光，正好装下一个人的名字。",
                    "e": "Du Fu remembers his brother beneath the autumn half moon.\nDew whitens first; home shines beyond the war;\nthe missing light makes room for one person’s name.",
                    "c": "Tang poetry · Du Fu’s moonlit remembrance"
                },
                "7": {
                    "n": "残月将尽，玉兔把药杵轻轻放下。\n嫦娥在桂影里等下一次人间仰望；\n黑暗只是广寒宫合上的门。",
                    "e": "The last crescent fades; the Jade Rabbit gently sets down its pestle.\nChang’e waits in the cassia shadow for Earth to look up again;\ndarkness is only the Cold Palace closing its door.",
                    "c": "Chinese moon lore · Chang’e and the Jade Rabbit"
                }
            },
            "jp": {
                "0": {
                    "n": "月なき夜、月読命は名だけを空に残す。\n伊弉諾の右目から生まれた光も今は休み、\n闇が次の暦を静かに抱く。",
                    "e": "On the moonless night, Tsukuyomi leaves only his name in the sky.\nEven the light born from Izanagi’s right eye rests;\ndarkness quietly cradles the next calendar.",
                    "c": "Shinto mythology · Tsukuyomi and Izanagi"
                },
                "1": {
                    "n": "清少納言の御簾に細い三日月がかかる。\n小さなもの、遠いもの、心に残るもの。\n一筆の銀で夜の趣が決まる。",
                    "e": "A slender crescent catches on Sei Shōnagon’s blind.\nSmall things, distant things, things that linger in the heart—\none brushstroke of silver gives the night its character.",
                    "c": "Heian literature · Sei Shōnagon"
                },
                "2": {
                    "n": "紫式部は半月の廊下に源氏を歩かせる。\n光の側に恋、影の側にためらい。\n物語はその境目で袖を重ねる。",
                    "e": "Murasaki Shikibu sends Genji along a half-moon corridor.\nLove walks on the lit side, hesitation in shadow;\nthe tale layers its sleeves at the border.",
                    "c": "Heian literature · Murasaki Shikibu’s Tale of Genji"
                },
                "3": {
                    "n": "西行は満ちゆく月を追って吉野へ入る。\n桜はまだ蕾、山はすでに明るい。\n待つ心だけが季節を先に咲かせる。",
                    "e": "Saigyō follows the waxing moon into Yoshino.\nThe cherry trees are still in bud, though the mountain is bright;\nonly the waiting heart makes the season flower early.",
                    "c": "Japanese waka · Saigyō, moon and cherry blossoms"
                },
                "4": {
                    "n": "満月の使者がかぐや姫を迎えに来る。\n竹取の翁の庭は昼のように白い。\n完全な光にも、別れの影は消せない。",
                    "e": "Under the full moon, envoys come for Princess Kaguya.\nThe bamboo cutter’s garden is white as day;\neven perfect light cannot erase the shadow of farewell.",
                    "c": "Japanese tale · Princess Kaguya and the bamboo cutter"
                },
                "5": {
                    "n": "芭蕉の旅笠から十六夜の月がこぼれる。\n古池も細道も、少しずつ銀を返す。\n過ぎるものほど、よく耳を澄ませる。",
                    "e": "The lingering moon spills from Bashō’s travel hat.\nOld pond and narrow road return their silver little by little;\nwhat is passing listens most closely.",
                    "c": "Japanese haikai · Matsuo Bashō"
                },
                "6": {
                    "n": "北斎は下弦の月を富士の肩に置く。\n波の爪と雪の峰が一枚の藍に収まり、\n半分の光が世界の形を研ぐ。",
                    "e": "Hokusai sets the last-quarter moon on Fuji’s shoulder.\nWave-claw and snowy peak fit within one field of blue;\nhalf a light sharpens the world’s shape.",
                    "c": "Japanese art · Katsushika Hokusai and Mount Fuji"
                },
                "7": {
                    "n": "蕪村は有明の月を一句の端に残す。\n宿場の戸が閉じ、雁の声だけが渡る。\n消える光は、余白を明るくする。",
                    "e": "Buson leaves the dawn crescent at the edge of a haiku.\nThe post-town doors close; only wild geese cross in sound.\nVanishing light brightens the empty space.",
                    "c": "Japanese haikai and painting · Yosa Buson"
                }
            },
            "jv": {
                "0": {
                    "n": "Wengi tanpa rembulan, Dewi Ratih ndhelik ing petenging langit.\nKala Rau durung weruh dalane kanggo ngoyak;\nsuwung iku dudu sirna, nanging ambegan sadurunge crita.",
                    "e": "On a moonless night, Dewi Ratih hides in the dark sky.\nKala Rau has not yet found the road of pursuit;\nemptiness is not erasure, but the breath before a story.",
                    "c": "Javanese–Balinese lunar lore · Dewi Ratih and Kala Rau"
                },
                "1": {
                    "n": "Sultan Agung nyawang sabit tipis saka Mataram.\nTanggal Jawa lan taun Hijriyah ketemu ing siji garis salaka;\nkalender anyar diwiwiti saka rembulan enom.",
                    "e": "Sultan Agung watches a thin crescent from Mataram.\nJavanese dating and the Hijri year meet in one silver line;\na new calendar begins from a young moon.",
                    "c": "Javanese history · Sultan Agung’s Javanese calendar"
                },
                "2": {
                    "n": "Semar ngadeg ing sangisore blencong lan setengah rembulan.\nPasuryane ngguyu, atine nyimpen kawicaksanan;\npepadhang lan ayang-ayang padha dadi guru.",
                    "e": "Semar stands beneath the blencong lamp and half moon.\nHis face laughs while his heart keeps wisdom;\nlight and shadow are teachers together.",
                    "c": "Javanese wayang · Semar and the blencong lamp"
                },
                "3": {
                    "n": "Dewi Sri mlaku ing galengan nalika rembulan saya kebak.\nPari enom ngangkat gandane saka banyu;\npanen durung teka, nanging pangarep-arep wis sumunar.",
                    "e": "Dewi Sri walks the rice dikes as the moon grows full.\nYoung rice lifts its scent from the water;\nharvest has not come, but hope is already bright.",
                    "c": "Javanese rice tradition · Dewi Sri"
                },
                "4": {
                    "n": "Nalika purnama, Kala Rau nguntal Dewi Ratih.\nWong-wong nabuh lesung nganti peteng ngeculake dheweke;\nswara bebarengan bisa nulungi cahya bali.",
                    "e": "At full moon Kala Rau swallows Dewi Ratih.\nPeople pound the rice mortars until darkness releases her;\nvoices joined together can help light return.",
                    "c": "Javanese–Balinese eclipse lore · Dewi Ratih, Kala Rau and the lesung"
                },
                "5": {
                    "n": "Ranggawarsita nulis jaman kang miring ing cahya kang suda.\nSurakarta meneng, nanging aksara Jawa isih tangi;\nwektu sing peteng uga bisa diwaca.",
                    "e": "Ranggawarsita writes of a tilting age in waning light.\nSurakarta is quiet, but Javanese letters remain awake;\na darkening time can also be read.",
                    "c": "Javanese literature · Ranggawarsita"
                },
                "6": {
                    "n": "Kartini mbukak jendhela Jepara marang setengah rembulan.\nSaka peteng, layang-layange nggoleki pepadhang;\nsiji swara bisa mbukak lawang kanggo akeh wong.",
                    "e": "Kartini opens a Jepara window to the half moon.\nFrom darkness, her letters search for light;\none voice can open a door for many.",
                    "c": "Javanese history and letters · Raden Ajeng Kartini"
                },
                "7": {
                    "n": "Ki Nartosabdho nyimpen wayang nalika sabit pungkasan mudhun.\nGamelan mandheg, nanging Semar durung rampung mesem;\ncritane turu supaya bisa tangi maneh.",
                    "e": "Ki Nartosabdho stores the puppets as the last crescent lowers.\nThe gamelan stops, though Semar has not finished smiling;\nthe story sleeps so it can rise again.",
                    "c": "Javanese performance · dalang Ki Nartosabdho"
                }
            },
            "vi": {
                "0": {
                    "n": "Đêm không trăng, Hồ Xuân Hương để một khoảng trắng trên trang giấy.\nHương sen vẫn đi qua hồ Tây dù không có bóng sáng;\ncái khuyết đôi khi là nơi câu thơ bắt đầu.",
                    "e": "On a moonless night, Hồ Xuân Hương leaves a blank on the page.\nLotus fragrance still crosses West Lake without a reflection;\nsometimes absence is where a poem begins.",
                    "c": "Vietnamese poetry · Hồ Xuân Hương and West Lake"
                },
                "1": {
                    "n": "Trăng non mắc vào ngọn đa của Chú Cuội.\nDưới sân, trẻ nhỏ nâng chiếc đèn đầu tiên;\nmột nét bạc đủ buộc đất với trời.",
                    "e": "The young crescent catches in Chú Cuội’s banyan.\nIn the courtyard, children lift the first lantern;\none silver stroke can tie earth to sky.",
                    "c": "Vietnamese moon lore · Chú Cuội and the banyan tree"
                },
                "2": {
                    "n": "Nguyễn Du cho nàng Kiều đi qua một nửa vầng trăng.\nMột bên là tiếng đàn, một bên là đoạn trường;\nánh sáng chia đôi vẫn soi trọn phận người.",
                    "e": "Nguyễn Du sends Kiều beneath a half moon.\nOn one side the lute, on the other heartbreak;\ndivided light still reveals a whole human fate.",
                    "c": "Vietnamese literature · Nguyễn Du’s Tale of Kiều"
                },
                "3": {
                    "n": "Hàn Mặc Tử bày trăng gần tròn lên bờ cát Quy Nhơn.\nNhà thơ hỏi ai muốn mang ánh sáng về;\nbiển giữ im lặng, còn câu thơ cứ dâng.",
                    "e": "Hàn Mặc Tử lays the nearly full moon on the sands of Quy Nhơn.\nThe poet asks who would carry the light home;\nthe sea keeps silent while the poem keeps rising.",
                    "c": "Vietnamese poetry · Hàn Mặc Tử’s lunar imagination"
                },
                "4": {
                    "n": "Trăng rằm, Chị Hằng ngồi bên Chú Cuội trên cung trăng.\nĐèn ông sao đi qua phố, trống lân gọi trẻ nhỏ;\nđêm đoàn viên có chỗ cho cả người xa nhà.",
                    "e": "At full moon, Chị Hằng sits beside Chú Cuội in the lunar palace.\nStar lanterns cross the street and lion drums call the children;\nthe reunion night makes room even for those far from home.",
                    "c": "Vietnamese Mid-Autumn tradition · Chị Hằng and Chú Cuội"
                },
                "5": {
                    "n": "Trong ngục, Hồ Chí Minh ngắm vầng trăng đang khuyết.\nSong sắt chia phòng, không chia được cuộc gặp;\nánh sáng lùi xa mà tự do bước gần.",
                    "e": "In prison, Hồ Chí Minh watches the waning moon.\nBars divide the room, but cannot divide the meeting;\nthe light recedes while freedom draws near.",
                    "c": "Vietnamese prison poetry · Hồ Chí Minh’s moon-gazing poem"
                },
                "6": {
                    "n": "Nguyễn Trãi nghe nửa trăng rơi trên đá Côn Sơn.\nSuối vẫn đàn qua một triều đại đã mỏi;\nngười lui về, nhưng lòng ngay không tắt.",
                    "e": "Nguyễn Trãi hears half a moon fall on the stones of Côn Sơn.\nThe stream keeps playing through a weary dynasty;\na person may withdraw while an upright heart stays lit.",
                    "c": "Vietnamese poetry and history · Nguyễn Trãi at Côn Sơn"
                },
                "7": {
                    "n": "Xuân Diệu giữ vệt trăng cuối trên mái Hà Nội.\nThời gian vội, chiếc lá vội, lời yêu cũng vội;\nchỉ bóng tối biết cách làm chậm một lời chào.",
                    "e": "Xuân Diệu keeps the last moon-line over a Hanoi roof.\nTime hurries, leaves hurry, even love hurries;\nonly darkness knows how to slow a farewell.",
                    "c": "Vietnamese New Poetry · Xuân Diệu"
                }
            },
            "ko": {
                "0": {
                    "n": "달 없는 밤, 연오랑과 세오녀의 옛 바다는 검다.\n빛을 되찾을 비단은 아직 베틀 위에 있고,\n보이지 않는 달도 돌아올 길을 짠다.",
                    "e": "On a moonless night, the old sea of Yeonorang and Seonyeo is dark.\nThe silk that will restore the light is still on the loom;\neven an unseen moon weaves a road home.",
                    "c": "Korean Silla legend · Yeonorang and Seonyeo"
                },
                "1": {
                    "n": "장영실이 앙부일구 곁에서 초승달을 올려다본다.\n가는 은빛은 새 달의 첫 눈금이 되고,\n하늘을 재는 손은 백성의 시간을 만든다.",
                    "e": "Jang Yeong-sil looks from the sundial toward the young crescent.\nThe thin silver becomes the month’s first mark;\nhands that measure heaven make time for the people.",
                    "c": "Joseon science · Jang Yeong-sil"
                },
                "2": {
                    "n": "세종은 반달 아래 새 글자의 소리를 듣는다.\n한쪽은 입 모양, 한쪽은 백성의 숨;\n나뉜 빛 속에서도 말은 온전해진다.",
                    "e": "King Sejong hears new letters beneath a half moon.\nOne side is the shape of the mouth, the other the people’s breath;\neven in divided light, speech becomes whole.",
                    "c": "Korean history · King Sejong and Hangul"
                },
                "3": {
                    "n": "윤동주는 차오르는 달 옆에 별 하나를 남긴다.\n골목의 바람이 원고지 칸을 지나가고,\n부끄러움 없는 문장이 새벽을 기다린다.",
                    "e": "Yun Dong-ju leaves one star beside the waxing moon.\nAlley wind crosses the squares of his manuscript paper;\na sentence without shame waits for dawn.",
                    "c": "Korean poetry · Yun Dong-ju"
                },
                "4": {
                    "n": "보름달이 빈 산을 채우자 명월 황진이가 웃는다.\n푸른 물에게 바다로 서둘지 말라 손짓하고,\n가득 찬 밤에 잠시 쉬어 가라 한다.",
                    "e": "When full moon fills the empty mountain, Hwang Jini—Myeongwol—smiles.\nShe gestures to the blue stream not to hurry to the sea,\nand asks it to rest awhile in the completed night.",
                    "c": "Korean sijo · Hwang Jini, whose art name Myeongwol means Bright Moon"
                },
                "5": {
                    "n": "김소월의 산길 위로 달빛이 조금씩 진다.\n진달래 꽃잎마다 떠나는 발자국을 덮고,\n줄어든 빛이 이별의 길을 더 오래 비춘다.",
                    "e": "Moonlight slowly wanes above Kim Sowol’s mountain road.\nAzalea petals cover each departing footprint;\nthe diminished light makes the farewell road last longer.",
                    "c": "Korean poetry · Kim Sowol and azaleas"
                },
                "6": {
                    "n": "신사임당은 반 남은 달을 먹빛 가지 사이에 둔다.\n풀벌레와 포도알이 작은 화면에서 숨 쉬고,\n절제된 빛이 사물의 마음을 드러낸다.",
                    "e": "Shin Saimdang places the half-remaining moon among ink-dark branches.\nInsect and grape breathe within the small picture;\nrestrained light reveals the heart of things.",
                    "c": "Korean art · Shin Saimdang’s plants and insects"
                },
                "7": {
                    "n": "달토끼가 마지막 절구질을 멈춘다.\n송편 향은 지붕 아래 남고 가는 달은 산을 넘는다;\n쉼도 다음 보름을 빚는 일이다.",
                    "e": "The moon rabbit stops its final pounding.\nSongpyeon fragrance stays beneath the roofs as the thin moon crosses the hill;\nrest, too, is part of shaping the next full moon.",
                    "c": "Korean moon lore · daltokki, the moon rabbit"
                }
            },
            "peru": {
                "0": {
                    "n": "En la noche sin luna, Mama Killa cierra su manto.\nLos quipus descansan, sin nudo nuevo bajo el cielo;\nlo invisible también ordena el tiempo.",
                    "e": "On the moonless night, Mama Killa closes her mantle.\nThe quipus rest, with no new knot beneath the sky;\nwhat is invisible also orders time.",
                    "c": "Inca lunar tradition · Mama Killa and the quipu"
                },
                "1": {
                    "n": "Guaman Poma dibuja una luna fina sobre el mes andino.\nEn su página, sembrador, estrella y autoridad comparten margen;\nun arco de plata guarda la memoria del calendario.",
                    "e": "Guaman Poma draws a fine crescent above the Andean month.\nOn his page, farmer, star, and ruler share a margin;\nan arc of silver keeps the calendar’s memory.",
                    "c": "Andean chronicle · Felipe Guaman Poma de Ayala"
                },
                "2": {
                    "n": "El Inca Garcilaso contempla media luna entre dos lenguas.\nUna mitad recuerda al Cusco, la otra escribe desde lejos;\nen la página se encuentran sin dejar de ser distintas.",
                    "e": "Inca Garcilaso contemplates a half moon between two languages.\nOne half remembers Cusco, the other writes from afar;\non the page they meet without ceasing to be different.",
                    "c": "Peruvian letters · Inca Garcilaso de la Vega"
                },
                "3": {
                    "n": "José María Arguedas oye crecer la luna sobre el ayllu.\nEl quechua del río entra en el castellano de la escuela;\nla luz casi completa aprende a hablar con más de una voz.",
                    "e": "José María Arguedas hears the moon grow above the ayllu.\nThe river’s Quechua enters the schoolroom’s Spanish;\nthe nearly complete light learns to speak with more than one voice.",
                    "c": "Peruvian literature · José María Arguedas and Quechua song"
                },
                "4": {
                    "n": "Mama Killa llena el cielo del Cusco y Mama Ocllo levanta la mirada.\nLa plaza recibe plata sobre cada piedra;\nla luna entera no borra las manos que sostienen la ciudad.",
                    "e": "Mama Killa fills Cusco’s sky, and Mama Ocllo lifts her gaze.\nThe plaza receives silver on every stone;\nthe whole moon does not erase the hands that hold the city.",
                    "c": "Inca tradition · Mama Killa and culture heroine Mama Ocllo"
                },
                "5": {
                    "n": "César Vallejo camina bajo una luna que empieza a faltar.\nEn Santiago de Chuco, la teja guarda frío y familia;\nlo que se pierde de luz pesa más en la palabra.",
                    "e": "César Vallejo walks beneath a moon beginning to diminish.\nIn Santiago de Chuco, the roof tile keeps cold and family;\nwhat light loses gains weight in the word.",
                    "c": "Peruvian poetry · César Vallejo and Santiago de Chuco"
                },
                "6": {
                    "n": "María Reiche mide una línea mientras queda media luna.\nEl desierto de Nazca no entrega todos sus dibujos;\nmirar con paciencia también es una forma de cuidado.",
                    "e": "María Reiche measures a line beneath the half-remaining moon.\nThe Nazca desert does not surrender every drawing;\nto look patiently is also a form of care.",
                    "c": "Peruvian archaeology and preservation · María Reiche"
                },
                "7": {
                    "n": "Martín Chambi espera el último hilo de luna sobre los Andes.\nAbre el obturador: una familia, una calle, un siglo respiran;\ncuando la luz se va, la imagen aprende a quedarse.",
                    "e": "Martín Chambi waits for the Moon’s final thread above the Andes.\nHe opens the shutter: a family, a street, a century breathe;\nwhen light leaves, the image learns to remain.",
                    "c": "Peruvian photography · Martín Chambi"
                }
            },
            "brazil": {
                "0": {
                    "n": "Na noite sem lua, Jaci recolhe o rosto atrás da mata.\nO rio fica negro, mas não perde o caminho;\nna memória tupi, a ausência também tem nome.",
                    "e": "On the moonless night, Jaci gathers her face behind the forest.\nThe river turns black but does not lose its way;\nin Tupi memory, absence also has a name.",
                    "c": "Tupi lunar tradition · Jaci"
                },
                "1": {
                    "n": "Jasy ergue uma curva fina sobre uma aldeia Guarani.\nA primeira prata toca a erva-mate e o caminho;\num começo pequeno pode iluminar uma roda inteira.",
                    "e": "Jasy lifts a slender curve above a Guarani village.\nThe first silver touches yerba mate and the path;\na small beginning can light a whole circle.",
                    "c": "Guarani lunar thread · Jasy, included with specific attribution"
                },
                "2": {
                    "n": "Cecília Meireles encontra a lua dividida na janela.\nMetade fica com a viagem, metade com a casa;\nseu verso faz da mudança uma morada.",
                    "e": "Cecília Meireles finds the divided moon at the window.\nHalf stays with the journey, half with home;\nher verse makes change into a dwelling.",
                    "c": "Brazilian poetry · Cecília Meireles and her lunar poems"
                },
                "3": {
                    "n": "Cora Coralina deixa a lua crescer sobre os telhados de Goiás.\nNo tacho de cobre, o doce toma tempo e brilho;\no quase pronto pede fogo baixo e mão paciente.",
                    "e": "Cora Coralina lets the moon grow above the roofs of Goiás.\nIn the copper pan, sweetness takes time and shine;\nwhat is nearly ready asks for low flame and a patient hand.",
                    "c": "Brazilian poetry · Cora Coralina and Goiás"
                },
                "4": {
                    "n": "Sob a lua cheia de São Jorge, Caetano ergue a voz.\nO santo, o dragão e a cidade cabem no mesmo clarão;\na canção faz da noite uma varanda comum.",
                    "e": "Beneath São Jorge’s full moon, Caetano raises his voice.\nSaint, dragon, and city fit within the same brightness;\nthe song turns night into a shared veranda.",
                    "c": "Brazilian song · Caetano Veloso’s São Jorge moon imagery"
                },
                "5": {
                    "n": "Drummond vê a lua minguar sobre Itabira.\nA pedra continua no caminho, agora menos iluminada;\nperder brilho não é perder peso.",
                    "e": "Drummond sees the moon wane above Itabira.\nThe stone remains in the road, now less illuminated;\nto lose brightness is not to lose weight.",
                    "c": "Brazilian poetry · Carlos Drummond de Andrade and Itabira"
                },
                "6": {
                    "n": "Marcos Pontes olha a meia-lua além da janela orbital.\nO Brasil é uma curva azul sem fronteira visível;\nde longe, metade de uma luz ainda chama de casa.",
                    "e": "Marcos Pontes looks toward the half moon beyond an orbital window.\nBrazil is a blue curve with no visible border;\nfrom afar, even half a light still calls itself home.",
                    "c": "Brazilian spaceflight · Marcos Pontes"
                },
                "7": {
                    "n": "Guimarães Rosa põe a última unha de lua no sertão.\nRiobaldo escuta o escuro entre uma palavra e outra;\nvereda nenhuma termina só porque a luz se esconde.",
                    "e": "Guimarães Rosa sets the Moon’s last fingernail in the sertão.\nRiobaldo hears the dark between one word and another;\nno path ends merely because the light hides.",
                    "c": "Brazilian literature · Guimarães Rosa’s Riobaldo and the sertão"
                }
            },
            "suriname": {
                "0": {
                    "n": "In maanloze nacht schrijft Johannes King bij het bos.\nDe rivier is zwart, de droom blijft helder;\nwat niet zichtbaar is kan toch getuigen.",
                    "e": "On a moonless night Johannes King writes beside the forest.\nThe river is black; the dream remains clear.\nWhat cannot be seen can still bear witness.",
                    "c": "Surinamese writing · Matawai author Johannes King"
                },
                "1": {
                    "n": "Trefossa vindt een smalle maan boven de Surinamerivier.\nEén zilveren letter zoekt haar plaats in het Sranan;\neen taal groeit wanneer iemand haar zacht maar vast uitspreekt.",
                    "e": "Trefossa finds a slender moon above the Suriname River.\nOne silver letter searches for its place in Sranan;\na language grows when someone speaks it softly but firmly.",
                    "c": "Surinamese poetry · Trefossa and Sranan Tongo"
                },
                "2": {
                    "n": "Shrinivási staat met een halve maan tussen twee oevers.\nDe ene noemt vertrek, de andere thuiskomst;\nde dichter laat de rivier beide namen dragen.",
                    "e": "Shrinivási stands with a half moon between two banks.\nOne names departure, the other homecoming;\nthe poet lets the river carry both names.",
                    "c": "Surinamese poetry · Shrinivási and the river journey"
                },
                "3": {
                    "n": "Dobru ziet de maan groeien boven één boom.\nCreool, Javaan, Hindostaan en Marron vinden schaduw eronder;\nvolheid begint waar takken ruimte voor elkaar maken.",
                    "e": "Dobru sees the moon grow above one tree.\nCreole, Javanese, Hindustani, and Maroon find shade beneath it;\nfullness begins where branches make room for one another.",
                    "c": "Surinamese poetry · Dobru’s one-tree vision"
                },
                "4": {
                    "n": "Bij volle maan opent Cynthia McLeod een oud Paramaribo-huis.\nVerzwegen vrouwen stappen uit archief en kamer;\nhelder licht vraagt ook wie uit het verhaal werd gehouden.",
                    "e": "At full moon Cynthia McLeod opens an old Paramaribo house.\nSilenced women step from archive and room;\nbright light also asks who was kept outside the story.",
                    "c": "Surinamese historical fiction · Cynthia McLeod"
                },
                "5": {
                    "n": "Johanna Schouten-Elsenhout hoort de maan afnemen boven de erven.\nSranan-woorden houden vast wat het daglicht vergat;\nde stem van een vrouw wordt niet kleiner met de nacht.",
                    "e": "Johanna Schouten-Elsenhout hears the moon wane above the yards.\nSranan words hold what daylight forgot;\na woman’s voice does not grow smaller with the night.",
                    "c": "Surinamese poetry · Johanna Schouten-Elsenhout"
                },
                "6": {
                    "n": "Anton de Kom loopt onder een halve maan door de geschiedenis.\nDe plantageboeken tellen bezit, zijn pen telt mensen;\nwaar licht ontbreekt, moet waarheid nauwkeuriger kijken.",
                    "e": "Anton de Kom walks through history beneath a half moon.\nPlantation ledgers count property; his pen counts people.\nWhere light is missing, truth must look more closely.",
                    "c": "Surinamese history and resistance · Anton de Kom"
                },
                "7": {
                    "n": "Astrid Roemer laat de laatste maansikkel boven Paramaribo staan.\nFamilies spreken, zwijgen en keren in kringen terug;\nhet donker sluit geen verhaal dat nog van binnen brandt.",
                    "e": "Astrid Roemer leaves the final crescent above Paramaribo.\nFamilies speak, fall silent, and return in circles;\ndarkness cannot close a story still burning within.",
                    "c": "Surinamese literature · Astrid Roemer"
                }
            },
            "mexico": {
                "0": {
                    "n": "Sin luna, Coyolxauhqui duerme bajo la piedra del Templo Mayor.\nSus cascabeles no suenan, sus fragmentos guardan memoria;\nla oscuridad no deshace lo que la tierra recuerda.",
                    "e": "Moonless, Coyolxauhqui sleeps beneath the stone of the Templo Mayor.\nHer bells are silent; her fragments keep memory.\nDarkness does not undo what the earth remembers.",
                    "c": "Mexica tradition · Coyolxauhqui, She of the Bells"
                },
                "1": {
                    "n": "Nezahualcóyotl mira una luna joven sobre Texcoco.\nEl agua escribe un arco que el rey poeta no posee;\nlo más frágil del cielo enseña a soltar el reino.",
                    "e": "Nezahualcóyotl watches a young moon above Texcoco.\nWater writes an arc the poet-king cannot possess;\nthe frailest thing in heaven teaches how to release a kingdom.",
                    "c": "Acolhua poetry and history · Nezahualcóyotl"
                },
                "2": {
                    "n": "Sor Juana estudia con media luna en la celda.\nMedia noche es silencio, la otra mitad pregunta;\nsu biblioteca enciende lo que el cielo deja oscuro.",
                    "e": "Sor Juana studies with a half moon in her cell.\nHalf the night is silence; the other half asks questions.\nHer library lights what the sky leaves dark.",
                    "c": "New Spanish Mexican letters · Sor Juana Inés de la Cruz"
                },
                "3": {
                    "n": "Frida pinta una luna creciente junto a dos corazones.\nCoyoacán se llena de raíces, venas y hojas;\nlo casi entero no necesita fingir que no está herido.",
                    "e": "Frida paints a waxing moon beside two hearts.\nCoyoacán fills with roots, veins, and leaves;\nwhat is nearly whole need not pretend it is unhurt.",
                    "c": "Mexican art · Frida Kahlo and Coyoacán"
                },
                "4": {
                    "n": "Tecuciztécatl sale del fuego convertido en luna.\nLos dioses moderan su brillo con la figura de un conejo;\nNanahuatzin avanza como sol y ambos hacen andar el tiempo.",
                    "e": "Tecuciztécatl rises from the fire transformed into the Moon.\nThe gods temper his brilliance with the shape of a rabbit;\nNanahuatzin moves as the Sun, and together they set time walking.",
                    "c": "Nahua creation story · Tecuciztécatl and Nanahuatzin"
                },
                "5": {
                    "n": "Rosario Castellanos ve menguar la luna sobre Chiapas.\nLas voces que el centro llamó pequeñas ocupan la página;\nmenos luz obliga a mirar quién quedó al margen.",
                    "e": "Rosario Castellanos sees the moon wane above Chiapas.\nVoices the center called small take their place on the page;\nless light forces us to see who was left at the margin.",
                    "c": "Mexican literature · Rosario Castellanos and Chiapas"
                },
                "6": {
                    "n": "Octavio Paz cruza un patio bajo media luna tardía.\nLa piedra guarda sol, la noche abre otra puerta;\nel instante se parte y, al partirse, gira.",
                    "e": "Octavio Paz crosses a courtyard beneath the late half moon.\nStone keeps the sun; night opens another door.\nThe instant divides and, in dividing, turns.",
                    "c": "Mexican poetry · Octavio Paz"
                },
                "7": {
                    "n": "Rufino Tamayo deja un perro aullar a la última luna.\nRojo, violeta y arena sostienen el cielo de Oaxaca;\ncuando el disco desaparece, el color sigue llamándolo.",
                    "e": "Rufino Tamayo leaves a dog howling at the final moon.\nRed, violet, and sand hold up the Oaxacan sky;\nwhen the disk disappears, color keeps calling it.",
                    "c": "Mexican art · Rufino Tamayo’s lunar imagery"
                }
            },
            "haiti": {
                "0": {
                    "n": "Nan yon nwit san lalin, Papa Legba chita bò kafou a.\nLi kenbe baton li, men li poko louvri okenn baryè;\nfènwa a mande respè anvan premye pa a.",
                    "e": "On the moonless night, Papa Legba sits by the crossroads.\nHe holds his staff but has not opened any gate;\ndarkness asks for respect before the first step.",
                    "c": "Haitian Vodou · Papa Legba at the crossroads"
                },
                "1": {
                    "n": "Ida Faubert wè yon ti koub lalin sou Pòtoprens.\nYon powèm leve dousman ant franse ak souvni zile a;\nlimyè mens lan pote plis pase yon sèl kay.",
                    "e": "Ida Faubert sees a small moon-curve over Port-au-Prince.\nA verse rises softly between French and island memory;\nthe thin light carries more than one home.",
                    "c": "Haitian poetry · Ida Faubert"
                },
                "2": {
                    "n": "Jacques Roumain mache ak mwatye lalin sou tè peyizan yo.\nYon bò se sechrès, lòt bò se dlo yo dwe chèche ansanm;\nlimyè divize a montre travay ki ini moun.",
                    "e": "Jacques Roumain walks beneath a half moon on the farmers’ land.\nOne side is drought, the other water they must seek together;\ndivided light reveals the work that unites people.",
                    "c": "Haitian literature · Jacques Roumain’s peasant world"
                },
                "3": {
                    "n": "Frankétienne trase yon espiral anba lalin k ap plen.\nKoulè, mo ak tanbou vire san yo pa pèdi sant yo;\nAyiti antre nan penti a pa tout pòt an menm tan.",
                    "e": "Frankétienne draws a spiral beneath the waxing moon.\nColor, word, and drum turn without losing their center;\nHaiti enters the painting through every door at once.",
                    "c": "Haitian Spiralism · Frankétienne"
                },
                "4": {
                    "n": "Lalin plen mete yon glas sou dlo Ezili Freda.\nLasirèn chante pi lwen, pafen ak tanbou ranpli lakou a;\nbèlte klere, men li toujou pote yon dlo nan je.",
                    "e": "The full moon lays a mirror on Ezili Freda’s water.\nLasirèn sings farther out; perfume and drums fill the yard.\nBeauty shines, yet still carries one tear.",
                    "c": "Haitian Vodou · Ezili Freda and Lasirèn, approached as living sacred figures"
                },
                "5": {
                    "n": "René Depestre pote lalin k ap bese nan valiz ekzil li.\nJacmel rete nan sèl lanmè, po, ak ritm;\nsa limyè a pèdi, imajinasyon rann li vivan.",
                    "e": "René Depestre carries the waning moon in exile’s suitcase.\nJacmel remains in sea-salt, skin, and rhythm;\nwhat light loses, imagination makes alive.",
                    "c": "Haitian poetry · René Depestre and Jacmel"
                },
                "6": {
                    "n": "Edwidge Danticat ekri anba mwatye lalin ki rete a.\nManman, pitit fi ak zansèt travèse menm paj la;\nistwa fanmi klere kote achiv la te fè nwa.",
                    "e": "Edwidge Danticat writes beneath the half that remains.\nMothers, daughters, and ancestors cross the same page;\nfamily story gives light where the archive went dark.",
                    "c": "Haitian literature · Edwidge Danticat"
                },
                "7": {
                    "n": "Oswald Durand kite dènye fil lalin sou chemen Choucoune.\nChante a pase bouch an bouch lè syèl la vin nwa;\nnon yon moun ou renmen ka siviv plis pase limyè.",
                    "e": "Oswald Durand leaves the Moon’s last thread on Choucoune’s road.\nThe song passes mouth to mouth as the sky turns dark;\na beloved name can outlive the light.",
                    "c": "Haitian poetry and song · Oswald Durand’s Choucoune"
                }
            },
            "argentina": {
                "0": {
                    "n": "En noche sin luna, Küyen descansa detrás de la cordillera.\nEl fogón mapuche guarda su brasa y su relato;\nla oscuridad también pertenece al ciclo.",
                    "e": "On the moonless night, Küyen rests behind the Andes.\nThe Mapuche fire keeps its ember and its story;\ndarkness, too, belongs to the cycle.",
                    "c": "Mapuche lunar tradition · Küyen, included with specific attribution"
                },
                "1": {
                    "n": "Borges encuentra una luna joven en un patio de Palermo.\nSabe que es antigua y, sin embargo, la nombra de nuevo;\ncada palabra afila el mismo arco de plata.",
                    "e": "Borges finds a young moon in a Palermo courtyard.\nHe knows it is ancient, yet names it again;\neach word sharpens the same silver arc.",
                    "c": "Argentine poetry · Jorge Luis Borges and the Moon"
                },
                "2": {
                    "n": "Alfonsina Storni mira media luna sobre el Plata.\nUna mitad queda en la ciudad, otra respira hacia el mar;\nsu voz no pide permiso a ninguna orilla.",
                    "e": "Alfonsina Storni watches a half moon above the Río de la Plata.\nOne half stays in the city, another breathes toward the sea;\nher voice asks permission from neither shore.",
                    "c": "Argentine poetry · Alfonsina Storni"
                },
                "3": {
                    "n": "Atahualpa Yupanqui cruza el cerro con la luna creciendo.\nLa guitarra recoge polvo, silencio y casco de caballo;\nla copla casi llena todavía deja lugar al camino.",
                    "e": "Atahualpa Yupanqui crosses the hills as the moon grows.\nHis guitar gathers dust, silence, and hoofbeat;\nthe nearly full song still leaves room for the road.",
                    "c": "Argentine folk music · Atahualpa Yupanqui"
                },
                "4": {
                    "n": "Mercedes Sosa canta y la luna llena cabe en su poncho.\nDesde Tucumán, la voz reúne plazas y ausencias;\nnadie escucha solo cuando ella abre la noche.",
                    "e": "Mercedes Sosa sings, and the full moon fits within her poncho.\nFrom Tucumán, the voice gathers plazas and absences;\nno one listens alone when she opens the night.",
                    "c": "Argentine song · Mercedes Sosa"
                },
                "5": {
                    "n": "Cortázar dibuja una rayuela bajo la luna menguante.\nOliveira salta de París a Buenos Aires sin tocar el cielo;\nlo que falta entre casillas también forma el juego.",
                    "e": "Cortázar draws a hopscotch grid beneath the waning moon.\nOliveira jumps from Paris to Buenos Aires without touching heaven;\nwhat is missing between squares is also part of the game.",
                    "c": "Argentine fiction · Julio Cortázar’s Hopscotch"
                },
                "6": {
                    "n": "Quino deja media luna sobre la ventana de Mafalda.\nElla mira el globo terráqueo y prepara otra pregunta;\nel humor alumbra justo donde el mundo queda oscuro.",
                    "e": "Quino leaves a half moon above Mafalda’s window.\nShe studies the globe and prepares another question;\nhumor lights precisely where the world stays dark.",
                    "c": "Argentine comics · Quino and Mafalda"
                },
                "7": {
                    "n": "Buenaventura Suárez calcula la última luna menguante desde las misiones.\nCon instrumentos hechos a mano sigue el hilo que se apaga;\nla ciencia americana también nació mirando desde el margen.",
                    "e": "Buenaventura Suárez calculates the final crescent from the missions.\nWith handmade instruments he follows the fading thread;\nAmerican science was also born by looking from the margins.",
                    "c": "Early astronomy in the Río de la Plata region · Buenaventura Suárez"
                }
            },
            "us": {
                "0": {
                    "n": "On a moonless road, Harriet Tubman listens north.\nNo silver marks the marsh, only courage and the stars;\nfreedom sometimes begins where the lantern must stay dark.",
                    "e": "",
                    "c": "United States history · Harriet Tubman and night journeys to freedom"
                },
                "1": {
                    "n": "Emily Dickinson pins a crescent to Amherst dusk.\nA narrow letter from the sky slips under the door;\nsmall light can hold an immeasurable address.",
                    "e": "",
                    "c": "United States poetry · Emily Dickinson"
                },
                "2": {
                    "n": "Joy Harjo lifts her saxophone beneath a half moon.\nBreath travels from Muscogee memory into the city night;\nlight and shadow learn the same song without becoming one.",
                    "e": "",
                    "c": "Muscogee American poetry and music · Joy Harjo"
                },
                "3": {
                    "n": "Langston Hughes watches the moon grow over Harlem.\nA blues line climbs the fire escape, carrying the river with it;\nalmost full, the night makes room for another dream.",
                    "e": "",
                    "c": "African American poetry · Langston Hughes and Harlem"
                },
                "4": {
                    "n": "Armstrong and Aldrin stand where the full Moon has no moonlight of its own.\nBack on Earth, Margaret Hamilton’s code keeps watch;\none human step rests on thousands of unseen hands.",
                    "e": "",
                    "c": "Apollo history · Neil Armstrong, Buzz Aldrin and Margaret Hamilton"
                },
                "5": {
                    "n": "Gil Scott-Heron hears the Moon’s triumph fade into a rent-due room.\nThe bright broadcast wanes against an unpaid bill;\nprogress must answer to the people left in shadow.",
                    "e": "",
                    "c": "African American spoken word · Gil Scott-Heron’s lunar critique"
                },
                "6": {
                    "n": "Mary Oliver walks the salt marsh under half a moon.\nAn owl asks no permission to enter the poem;\nattention gathers what the retreating light leaves behind.",
                    "e": "",
                    "c": "United States poetry · Mary Oliver and the natural world"
                },
                "7": {
                    "n": "Poe leaves one pale crescent above a Baltimore chamber.\nThe raven keeps the final glint inside its eye;\nwhen the moon is gone, the question remains awake.",
                    "e": "",
                    "c": "United States literature · Edgar Allan Poe and the raven"
                }
            },
            "canada": {
                "0": {
                    "n": "In a Cree telling, Wîsahkêcâhk names the night’s new keeper.\nThe moon is absent while the Sky World waits;\na duty can begin before its fire is seen.",
                    "e": "",
                    "c": "Cree story · Wîsahkêcâhk and the origin of tipiskâwi-pîsim, specifically attributed"
                },
                "1": {
                    "n": "E. Pauline Johnson launches a cedar canoe beneath the young crescent.\nGrand River silver travels with her Mohawk and English lines;\ntwo inheritances need not dim one another.",
                    "e": "",
                    "c": "Kanien’kehá:ka–English Canadian poetry · E. Pauline Johnson / Tekahionwake"
                },
                "2": {
                    "n": "Tom Thomson sets a half moon above a northern lake.\nOne shore burns with color, the other keeps its dark;\nthe paddle crosses both without dividing the water.",
                    "e": "",
                    "c": "Canadian art · Tom Thomson and the northern lake"
                },
                "3": {
                    "n": "Margaret Atwood lets the moon swell above a winter city.\nThe old myths enter wearing new, sharp shoes;\nalmost full, the tale asks who was allowed to speak.",
                    "e": "",
                    "c": "Canadian literature · Margaret Atwood and retold myth"
                },
                "4": {
                    "n": "In one Inuit tradition, Taqqiq walks as the full Moon across Arctic night.\nSnow returns his light farther than any road;\nthe story belongs to its tellers, not to a single northern map.",
                    "e": "",
                    "c": "Inuit lunar tradition · Taqqiq, named with care for regional variation"
                },
                "5": {
                    "n": "Leonard Cohen leaves a chord beneath the waning Montreal moon.\nThe tower, the harbor, and a quiet room lose silver slowly;\na broken note may still carry the chorus.",
                    "e": "",
                    "c": "Canadian song and poetry · Leonard Cohen and Montreal"
                },
                "6": {
                    "n": "Chris Hadfield watches half a moon beyond the station window.\nBelow, Canada turns without borders through aurora;\ndistance teaches the eye how much a home can hold.",
                    "e": "",
                    "c": "Canadian spaceflight · Chris Hadfield"
                },
                "7": {
                    "n": "Rita Joe keeps the last crescent above Eskasoni.\nA Mi’kmaw word, once pushed from the classroom, returns in song;\nno darkness can make a living language disappear.",
                    "e": "",
                    "c": "Mi’kmaw Canadian poetry · Rita Joe and language reclamation"
                }
            }
        };

        /* ===================================================================
           EARTH'S SHADOW · LUNAR ECLIPSES
           -------------------------------------------------------------------
           Contact data for every lunar eclipse from 2025 to 2060, condensed
           from NASA's Five Millennium Catalog of Lunar Eclipses
           (Espenak & Meeus) https://eclipse.gsfc.nasa.gov/LEcat5/LE2001-2100.html
           Columns: instant of greatest eclipse (UTC) · gamma, the Moon's least
           distance from the axis of Earth's shadow in Earth radii (positive
           when the Moon passes north of the axis) · duration in minutes of the
           partial phase, or of the penumbral phase when the umbra is missed.

           Gamma and that duration place the Moon's centre relative to the
           shadow axis at any moment; the radii of the umbra and penumbra then
           follow from the true Earth-Moon and Earth-Sun distances. This
           reproduces the catalogue's magnitudes to about 0.003 and its
           published contact times to roughly a minute.
           =================================================================== */
        const ECLIPSE_TABLE = `
2025-03-14T06:58Z 0.3484 218.3
2025-09-07T18:11Z -0.2752 209.4
2026-03-03T11:33Z -0.3765 207.2
2026-08-28T04:12Z 0.4964 198.1
2027-02-20T23:12Z -1.0480 241.0
2027-07-18T16:02Z -1.5758 11.8
2027-08-17T07:13Z 1.2797 218.6
2028-01-12T04:12Z 0.9817 56.0
2028-07-06T18:19Z -0.7903 141.5
2028-12-31T16:51Z 0.3258 208.8
2029-06-26T03:22Z 0.0124 219.5
2029-12-20T22:41Z -0.3811 213.3
2030-06-15T18:33Z 0.7534 144.4
2030-12-09T22:27Z -1.0731 279.2
2031-05-07T03:50Z -1.0694 237.3
2031-06-05T11:43Z 1.4731 95.6
2031-10-30T07:45Z 1.1773 231.8
2032-04-25T15:13Z -0.3558 211.2
2032-10-18T19:02Z 0.4169 195.9
2033-04-14T19:12Z 0.3954 215.0
2033-10-08T10:55Z -0.2889 202.4
2034-04-03T19:05Z 1.1144 265.4
2034-09-28T02:46Z -1.0110 26.7
2035-02-22T09:04Z -1.0367 255.7
2035-08-19T01:10Z 0.9433 76.5
2036-02-11T22:11Z -0.3110 201.9
2036-08-07T02:51Z 0.2004 231.3
2037-01-31T14:00Z 0.3619 197.5
2037-07-27T04:08Z -0.5582 192.4
2038-01-21T03:48Z 1.0710 245.8
2038-06-17T02:43Z 1.3082 176.3
2038-07-16T11:34Z -1.2837 192.4
2038-12-11T17:43Z -1.1448 258.5
2039-06-06T18:53Z 0.5460 179.3
2039-11-30T16:55Z -0.4721 206.0
2040-05-26T11:44Z -0.1872 210.7
2040-11-18T19:03Z 0.2361 220.4
2041-05-16T00:41Z -0.9746 58.5
2041-11-08T04:33Z 0.9212 90.3
2042-04-05T14:28Z 1.1080 268.4
2042-09-29T10:44Z -1.0261 238.5
2043-03-25T14:30Z 0.3849 214.6
2043-09-19T01:50Z -0.3316 206.0
2044-03-13T19:37Z -0.3496 209.1
2044-09-07T11:19Z 0.4318 206.2
2045-03-03T07:41Z -1.0274 243.9
2045-08-27T13:53Z 1.2060 241.7
2046-01-22T13:01Z 0.9885 50.4
2046-07-18T01:04Z -0.8691 114.6
2047-01-12T01:24Z 0.3317 208.9
2047-07-07T10:34Z -0.0636 218.5
2048-01-01T06:52Z -0.3745 214.3
2048-06-26T02:00Z 0.6796 159.2
2048-12-20T06:26Z -1.0624 281.6
2049-05-17T11:25Z -1.1337 224.3
2049-06-15T19:12Z 1.4068 132.0
2049-11-09T15:50Z 1.1964 226.1
2050-05-06T22:30Z -0.4181 206.0
2050-10-30T03:20Z 0.4435 192.9
2051-04-26T02:14Z 0.3371 220.8
2051-10-19T19:10Z -0.2542 204.3
2052-04-14T02:16Z 1.0628 276.0
2052-10-08T10:44Z -0.9726 63.3
2053-03-04T17:20Z -1.0530 251.1
2053-08-29T08:04Z 1.0164 277.8
2054-02-22T06:49Z -0.3242 200.9
2054-08-18T09:24Z 0.2806 226.5
2055-02-11T22:44Z 0.3526 198.4
2055-08-07T10:51Z -0.4769 203.4
2056-02-01T12:24Z 1.0682 247.2
2056-06-27T10:01Z 1.3769 149.9
2056-07-26T18:41Z -1.2048 214.4
2056-12-22T01:47Z -1.1559 256.4
2057-06-17T02:24Z 0.6167 169.3
2057-12-11T00:51Z -0.4853 204.0
2058-06-06T19:13Z -0.1181 213.4
2058-11-30T03:14Z 0.2208 220.7
2059-05-27T07:53Z -0.9097 97.2
2059-11-19T12:59Z 0.9004 99.2
2060-04-15T21:35Z 1.1621 255.0
2060-10-09T18:51Z -1.0670 231.3
2060-11-08T04:02Z 1.5332 43.6
        `;

        const R_EARTH_KM = 6378.137, R_MOON_KM = 1737.4, R_SUN_KM = 696000, AU_KM = 149597870.7;
        // Classical enlargements of Earth's shadow (Chauvenet/Danjon), fitted so
        // the magnitudes computed here match the NASA catalogue.
        const UMBRA_ENLARGE = 1.017, PENUMBRA_ENLARGE = 1.006;
        const DEG = 180 / Math.PI;
        const J1970 = 2440588, J2000 = 2451545, DAY_MS = 86400000;

        const eclipseEvents = ECLIPSE_TABLE.trim().split('\n').map(function (line) {
            const p = line.trim().split(/\s+/);
            return { t0: Date.parse(p[0]), gamma: parseFloat(p[1]), dur: parseFloat(p[2]) };
        });

        function daysSinceJ2000(date) { return date.valueOf() / DAY_MS - 0.5 + J1970 - J2000; }

        /*
           How fast the Moon drifts east against the Sun's place - and therefore
           against the shadow axis - in degrees per hour. The Moon's own motion
           varies with its anomaly; the Sun's is near enough constant here.
        */
        function shadowDriftRate(date) {
            const d = daysSinceJ2000(date);
            const M = (134.963 + 13.064993 * d) / DEG;          // Moon's mean anomaly
            return (13.176396 + 1.434 * Math.cos(M) - 0.98560028) / 24;
        }

        // Geocentric ecliptic longitude of the Sun (deg) and the Earth-Sun distance.
        function solarElements(date) {
            const d = daysSinceJ2000(date);
            const M = (357.5291 + 0.98560028 * d) / DEG;
            const C = (1.9148 * Math.sin(M) + 0.02 * Math.sin(2 * M) + 0.0003 * Math.sin(3 * M)) / DEG;
            const e = 0.016708634 - 0.000042037 * (d / 36525);
            const dist = 1.000001018 * (1 - e * e) / (1 + e * Math.cos(M + C)) * AU_KM;
            return { lon: ((M + C + 282.9372) % 360 + 360) % 360, dist: dist };
        }

        /* ---------- small vector helpers in the local horizontal frame ----------
           A direction is kept as [east, north, up]; east x north = up.          */
        function vDot(a, b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
        function vCross(a, b) {
            return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
        }
        function vAdd(a, b) { return [a[0] + b[0], a[1] + b[1], a[2] + b[2]]; }
        function vSub(a, b) { return [a[0] - b[0], a[1] - b[1], a[2] - b[2]]; }
        function vScale(a, k) { return [a[0] * k, a[1] * k, a[2] * k]; }
        function vNorm(a) {
            const n = Math.sqrt(vDot(a, a)) || 1;
            return [a[0] / n, a[1] / n, a[2] / n];
        }

        // Basis vectors of the local horizon, expressed in equatorial coordinates.
        function horizonBasis(latDeg, lngDeg, date) {
            const d = daysSinceJ2000(date);
            const phi = latDeg / DEG, th = (280.16 + 360.9856235 * d) / DEG + lngDeg / DEG;
            return {
                E: [-Math.sin(th), Math.cos(th), 0],
                N: [-Math.sin(phi) * Math.cos(th), -Math.sin(phi) * Math.sin(th), Math.cos(phi)],
                U: [Math.cos(phi) * Math.cos(th), Math.cos(phi) * Math.sin(th), Math.sin(phi)]
            };
        }

        // Ecliptic direction -> local horizontal [east, north, up].
        function eclipticToHorizon(v, date, latDeg, lngDeg) {
            const eps = (23.439291 - 0.0000004 * daysSinceJ2000(date)) / DEG;
            const eq = [v[0],
                        v[1] * Math.cos(eps) - v[2] * Math.sin(eps),
                        v[1] * Math.sin(eps) + v[2] * Math.cos(eps)];
            const b = horizonBasis(latDeg, lngDeg, date);
            return [vDot(eq, b.E), vDot(eq, b.N), vDot(eq, b.U)];
        }

        // Area shared by two circles of radii r1 and r2 whose centres are d apart.
        function circleOverlap(r1, r2, d) {
            if (d >= r1 + r2) return 0;
            if (d <= Math.abs(r1 - r2)) { const s = Math.min(r1, r2); return Math.PI * s * s; }
            const a1 = Math.acos((d * d + r1 * r1 - r2 * r2) / (2 * d * r1));
            const a2 = Math.acos((d * d + r2 * r2 - r1 * r1) / (2 * d * r2));
            const tri = 0.5 * Math.sqrt((-d + r1 + r2) * (d + r1 - r2) * (d - r1 + r2) * (d + r1 + r2));
            return r1 * r1 * a1 + r2 * r2 * a2 - tri;
        }

        /* Work out the geometry of the eclipse that is in progress at `when`,
           or null when the Moon is clear of Earth's shadow. Angles in degrees,
           rates in degrees per hour. */
        function eclipseAt(when, latDeg, lngDeg) {
            const nowMs = when.valueOf();
            let ev = null, gap = Infinity;
            for (const e of eclipseEvents) {
                const g = Math.abs(e.t0 - nowMs);
                if (g < gap) { gap = g; ev = e; }
            }
            if (!ev || gap > 5 * 3600e3) return null;      // no eclipse anywhere near

            const date = when;
            const dMoon = SunCalc.getMoonPosition(date, latDeg, lngDeg).distance;
            const dSun = solarElements(date).dist;
            const pMoon = Math.asin(R_EARTH_KM / dMoon) * DEG;      // Moon's parallax
            const pSun = Math.asin(R_EARTH_KM / dSun) * DEG;        // Sun's parallax
            const sunSemi = Math.asin(R_SUN_KM / dSun) * DEG;       // Sun's semidiameter
            const rMoon = Math.asin(R_MOON_KM / dMoon) * DEG;        // Moon's semidiameter
            const rhoU = UMBRA_ENLARGE * (pMoon + pSun - sunSemi);   // umbral radius
            const rhoP = PENUMBRA_ENLARGE * (pMoon + pSun + sunSemi);// penumbral radius

            const sigmaMin = Math.abs(ev.gamma) * pMoon;   // closest approach to the axis
            const reachU = rhoU + rMoon, reachP = rhoP + rMoon;
            if (sigmaMin >= reachP) return null;           // the penumbra is missed entirely

            // Rate the Moon drifts across the shadow, recovered from the catalogued
            // duration of whichever phase actually takes place.
            const umbral = sigmaMin < reachU;
            const reach = umbral ? reachU : reachP;
            let rate = 2 * Math.sqrt(Math.max(1e-9, reach * reach - sigmaMin * sigmaMin)) / (ev.dur / 60);
            /*
               For a grazing eclipse the duration is set by the difference of two
               nearly equal lengths, so the rate it implies can come out badly
               wrong. Anything outside a sane band falls back to the Moon's true
               motion instead.
            */
            if (!(rate > 0.40 && rate < 0.62)) rate = shadowDriftRate(date);
            if (!(rate > 0)) return null;

            const dt = (nowMs - ev.t0) / 3600e3;                  // hours from greatest eclipse
            const sigma = Math.sqrt(sigmaMin * sigmaMin + (rate * dt) * (rate * dt));
            if (sigma >= reachP) return null;                     // outside the penumbra now

            return {
                event: ev, dt: dt, rate: rate, pMoon: pMoon, rMoon: rMoon,
                rhoU: rhoU, rhoP: rhoP, sigma: sigma, sigmaMin: sigmaMin,
                umbMag: (reachU - sigma) / (2 * rMoon),
                penMag: (reachP - sigma) / (2 * rMoon),
                obscuration: circleOverlap(rMoon, rhoU, sigma) / (Math.PI * rMoon * rMoon)
            };
        }

        /* Bearing of the shadow's axis as seen from the Moon's centre, expressed
           as an angle inside the SVG's own drawing frame: measured from the
           drawing's +x axis (which is the direction of the Sun, i.e. the bright
           limb) turning toward +y. */
        function eclipseShadowAngle(when, latDeg, lngDeg, st, moonPos, illum, frameDate) {
            const date = when;
            // The sky frame the answer is expressed in: now when live, held at
            // greatest eclipse during a preview (see refreshMoon).
            const frame = frameDate || date;
            // SunCalc's azimuth runs from south toward west; make it a compass bearing.
            const alt = moonPos.altitude, az = moonPos.azimuth + Math.PI;
            const m = [Math.cos(alt) * Math.sin(az), Math.cos(alt) * Math.cos(az), Math.sin(alt)];

            // Screen frame: facing the Moon, zenith up, a true (unmirrored) sky view.
            const flat = Math.sqrt(m[0] * m[0] + m[1] * m[1]) || 1;
            const facing = [m[0] / flat, m[1] / flat, 0];
            const right = vCross(facing, [0, 0, 1]);                 // screen right
            const up = vNorm(vSub([0, 0, 1], vScale(m, m[2])));      // zenith, on the sky

            // Ecliptic frame at the Moon: it sits opposite the Sun, at latitude ~0.
            const ls = solarElements(date).lon / DEG;
            const eastward = eclipticToHorizon([Math.sin(ls), -Math.cos(ls), 0], frame, latDeg, lngDeg);
            const northward = eclipticToHorizon([0, 0, 1], frame, latDeg, lngDeg);

            // Offset of the shadow's axis from the Moon's centre, in degrees.
            const along = -st.rate * st.dt;                  // + when the axis lies east
            const across = -st.event.gamma * st.pMoon;       // + when the axis lies north
            let u = vNorm(vAdd(vScale(eastward, along), vScale(northward, across)));
            u = vNorm(vSub(u, vScale(m, vDot(u, m))));       // flatten onto the plane of the sky

            const betaShadow = Math.atan2(vDot(u, right), vDot(u, up)) * DEG;
            // The drawing's +x is the bright limb, whose position angle from
            // celestial north is SunCalc's illumination angle; subtracting the
            // parallactic angle references it to the zenith, and position angles
            // run counter-clockwise on screen, so:
            const betaSun = -((illum.angle || 0) * DEG - (moonPos.parallacticAngle || 0) * DEG);
            return betaShadow - betaSun;
        }

        /* ---------------------------- drawing ---------------------------- */
        // Two palettes for the umbra. A shallow partial reads as near-black
        // against a dazzling Moon; once totality sets in, light refracted
        // through Earth's atmosphere turns it copper.
        const UMBRA_PARTIAL = [[0, [6, 4, 9], 0.97], [0.5, [9, 6, 13], 0.96],
                               [0.82, [16, 10, 16], 0.95], [1, [26, 16, 20], 0.93]];
        const UMBRA_TOTAL = [[0, [58, 16, 8], 0.98], [0.45, [92, 32, 12], 0.97],
                             [0.78, [134, 52, 20], 0.96], [1, [176, 84, 34], 0.94]];
        const umbraStops = [
            document.getElementById('umbraStop0'), document.getElementById('umbraStop1'),
            document.getElementById('umbraStop2'), document.getElementById('umbraStop3')
        ];
        const penumbraStops = [
            document.getElementById('penumbraStop0'), document.getElementById('penumbraStop1'),
            document.getElementById('penumbraStop2')
        ];
        const umbraCircle = document.getElementById('umbraShadow');
        const penumbraCircle = document.getElementById('penumbraShadow');
        const eclipseLayer = document.getElementById('eclipseShadows');

        function mixRgb(a, b, t) {
            return [Math.round(a[0] + (b[0] - a[0]) * t),
                    Math.round(a[1] + (b[1] - a[1]) * t),
                    Math.round(a[2] + (b[2] - a[2]) * t)];
        }
        function clamp01(x) { return x < 0 ? 0 : x > 1 ? 1 : x; }

        // How far the eye has adapted: 0 for a shallow partial, 1 once the Moon is
        // wholly inside the umbra and only refracted light is left.
        function eclipseDepth(st) { return clamp01((st.umbMag - 0.72) / 0.33); }

        let eclipseState = null;

        function updateEclipseShadows(when, latDeg, lngDeg, moonPos, illum, frameDate) {
            const st = eclipseAt(when, latDeg, lngDeg);
            eclipseState = st;
            if (!st) {
                eclipseLayer.setAttribute('opacity', '0');
                return null;
            }

            const angle = eclipseShadowAngle(when, latDeg, lngDeg, st, moonPos, illum, frameDate);
            const pxPerDeg = 240 / st.rMoon;               // the disc is 240 units across
            const off = st.sigma * pxPerDeg;
            const a = angle / DEG;
            const cx = 250 + off * Math.cos(a);
            const cy = 250 + off * Math.sin(a);

            umbraCircle.setAttribute('cx', cx.toFixed(2));
            umbraCircle.setAttribute('cy', cy.toFixed(2));
            umbraCircle.setAttribute('r', (st.rhoU * pxPerDeg).toFixed(2));
            penumbraCircle.setAttribute('cx', cx.toFixed(2));
            penumbraCircle.setAttribute('cy', cy.toFixed(2));
            penumbraCircle.setAttribute('r', (st.rhoP * pxPerDeg).toFixed(2));

            /*
               Penumbra: the Sun is progressively hidden across the whole span
               between the penumbra's outer edge and the umbra's. Physically the
               light there falls to a few percent right at the umbral edge, but a
               screen cannot hold that alongside a sunlit surface that is some
               ten thousand times brighter, so the falloff is compressed the way
               an adapted eye reports it: a soft, slaty shading.
            */
            const inner = st.rhoU / st.rhoP;
            const mid = (inner + 1) / 2;
            const pen = [[0, inner, 0.35], [1, mid, 0.19], [2, 1, 0]];
            for (const [i, off2, alpha] of pen) {
                penumbraStops[i].setAttribute('offset', off2.toFixed(4));
                penumbraStops[i].setAttribute('stop-opacity', alpha.toFixed(3));
            }

            // Umbra: near-black against a sunlit Moon, copper once totality sets in.
            const deep = eclipseDepth(st);
            const fade = deep * deep * (3 - 2 * deep);      // smoothstep
            for (let i = 0; i < 4; i++) {
                const c = mixRgb(UMBRA_PARTIAL[i][1], UMBRA_TOTAL[i][1], fade);
                umbraStops[i].setAttribute('stop-color', 'rgb(' + c.join(',') + ')');
                umbraStops[i].setAttribute('stop-opacity',
                    (UMBRA_PARTIAL[i][2] + (UMBRA_TOTAL[i][2] - UMBRA_PARTIAL[i][2]) * fade).toFixed(3));
            }

            // Fade in over the first sliver of penumbral contact so nothing pops.
            eclipseLayer.setAttribute('opacity', clamp01(st.penMag / 0.05).toFixed(3));
            return st;
        }

        /* --------------------------- status line --------------------------- */
        const eclipseStatusEl = document.getElementById('eclipseStatus');

        // Earth's shadow radii and the Moon's own, in degrees, for one instant.
        function shadowRadii(date) {
            const dMoon = SunCalc.getMoonPosition(date, 0, 0).distance;
            const dSun = solarElements(date).dist;
            const pMoon = Math.asin(R_EARTH_KM / dMoon) * DEG;
            const pSun = Math.asin(R_EARTH_KM / dSun) * DEG;
            const sunSemi = Math.asin(R_SUN_KM / dSun) * DEG;
            const rMoon = Math.asin(R_MOON_KM / dMoon) * DEG;
            return {
                pMoon: pMoon, rMoon: rMoon,
                rhoU: UMBRA_ENLARGE * (pMoon + pSun - sunSemi),
                rhoP: PENUMBRA_ENLARGE * (pMoon + pSun + sunSemi)
            };
        }

        // Umbral magnitude the eclipse reaches at its greatest, from gamma alone.
        function magnitudeAtGreatest(ev) {
            const r = shadowRadii(new Date(ev.t0));
            return (r.rhoU + r.rMoon - Math.abs(ev.gamma) * r.pMoon) / (2 * r.rMoon);
        }

        /*
           Penumbral magnitude at greatest. At or below zero the Moon never
           reaches the shadow at all, so the entry is not an event anywhere on
           Earth - the catalogue carries a few that miss by a hair.
        */
        function penumbralMagnitudeAtGreatest(ev) {
            const r = shadowRadii(new Date(ev.t0));
            return (r.rhoP + r.rMoon - Math.abs(ev.gamma) * r.pMoon) / (2 * r.rMoon);
        }

        function eclipseKind(mag) {
            return mag >= 1 ? 'total' : mag > 0 ? 'partial' : 'penumbral';
        }

        function formatEclipseDate(ms) {
            return new Date(ms).toLocaleDateString(undefined, {
                day: 'numeric', month: 'short', year: 'numeric'
            });
        }

        /*
           The Moon's own phase on the date being previewed. An eclipse always
           falls at full Moon - that is what an eclipse is - but the page reports
           the real figure instead of assuming it, so a previewed date that is
           not exactly full says so and the drawing matches the words.
        */
        function phaseLabelAt(date) {
            const illum = SunCalc.getMoonIllumination(date);
            const idx = getPhaseIndex(illum.fraction, illum.phase);
            return phases[idx] + ' ' + Math.round(illum.fraction * 100) + '%';
        }

        function formatEclipseClock(ms) {
            return new Date(ms).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
        }

        /*
           How the Moon rides, from where you are, across the whole eclipse: a
           lunar eclipse is visible from an entire hemisphere, but only if the
           Moon is above your horizon while it happens. Cached because the status
           line refreshes every second and this samples the span.
        */
        const visibilityCache = new Map();
        function eclipseVisibility(ev) {
            const key = ev.t0 + '|' + observerPos.lat.toFixed(2) + '|' + observerPos.lng.toFixed(2);
            if (visibilityCache.has(key)) return visibilityCache.get(key);
            const first = eclipseFirstContact(ev);
            const last = 2 * ev.t0 - first;              // the track is symmetric
            const altAt = ms => SunCalc.getMoonPosition(new Date(ms),
                observerPos.lat, observerPos.lng).altitude * DEG;
            let maxAlt = altAt(last);
            for (let t = first; t <= last; t += 10 * 60e3) maxAlt = Math.max(maxAlt, altAt(t));
            const atGreatest = SunCalc.getMoonPosition(new Date(ev.t0), observerPos.lat, observerPos.lng);
            const out = {
                visible: maxAlt > 3,                     // 3° clears rooftops and haze
                maxAlt: maxAlt,
                altAtGreatest: atGreatest.altitude * DEG,
                azAtGreatest: (atGreatest.azimuth * DEG + 180) % 360
            };
            visibilityCache.set(key, out);
            return out;
        }

        function nextEclipseAfter(afterMs, minMagnitude, requireVisible) {
            const floor = minMagnitude === undefined ? -2 : minMagnitude;
            for (const e of eclipseEvents) {
                if (e.t0 <= afterMs) continue;
                if (magnitudeAtGreatest(e) < floor) continue;
                if (penumbralMagnitudeAtGreatest(e) <= 0.02) continue;   // misses entirely
                if (requireVisible && !eclipseVisibility(e).visible) continue;
                return e;
            }
            return null;
        }

        /*
           Cloud for the coming eclipse, when it is near enough to forecast.
           OpenWeather's free call reaches five days ahead; beyond that the page
           says nothing about cloud rather than inventing it. The call is purely
           optional - no key, no network or a refusal leaves the astronomy intact.
        */
        let eclipseForecast = { t0: null, cloud: null, state: 'idle', at: 0 };
        async function requestEclipseForecast(ev) {
            eclipseForecast = { t0: ev.t0, cloud: null, state: 'pending', at: Date.now() };
            const target = eclipseFirstContact(ev);
            if (target - Date.now() > 5 * 86400e3 || target - Date.now() < -6 * 3600e3) {
                eclipseForecast.state = 'too-far';
                return;
            }
            try {
                const url = `https://api.openweathermap.org/data/2.5/forecast?lat=${observerPos.lat}` +
                    `&lon=${observerPos.lng}&appid=${OPENWEATHER_API_KEY}&units=metric`;
                const res = await fetch(url);
                if (!res.ok) { eclipseForecast.state = 'unavailable'; return; }
                const data = await res.json();
                if (!Array.isArray(data.list) || !data.list.length) {
                    eclipseForecast.state = 'unavailable'; return;
                }
                let best = data.list[0], bestGap = Infinity;
                for (const entry of data.list) {
                    const gap = Math.abs(entry.dt * 1000 - target);
                    if (gap < bestGap) { bestGap = gap; best = entry; }
                }
                eclipseForecast = {
                    t0: ev.t0,
                    cloud: best.clouds ? best.clouds.all : null,
                    state: bestGap <= 3 * 3600e3 ? 'ok' : 'too-far',
                    at: Date.now()
                };
            } catch (e) {
                eclipseForecast.state = 'unavailable';
            }
        }

        // What the location and weather calls came back with, kept for the line.
        let observerWeather = { cloud: null, city: null, country: null, state: 'unknown' };

        /*
           First contact (P1): the instant the Moon's limb first reaches the
           penumbra, which is when an eclipse becomes observable at all. Counting
           down to that - rather than to greatest eclipse - is what an observer
           actually wants to know.
        */
        function eclipseFirstContact(ev) {
            const date = new Date(ev.t0);
            const dMoon = SunCalc.getMoonPosition(date, 0, 0).distance, dSun = solarElements(date).dist;
            const pMoon = Math.asin(R_EARTH_KM / dMoon) * DEG;
            const pSun = Math.asin(R_EARTH_KM / dSun) * DEG;
            const sunSemi = Math.asin(R_SUN_KM / dSun) * DEG;
            const rMoon = Math.asin(R_MOON_KM / dMoon) * DEG;
            const sigmaMin = Math.abs(ev.gamma) * pMoon;
            const reachU = UMBRA_ENLARGE * (pMoon + pSun - sunSemi) + rMoon;
            const reachP = PENUMBRA_ENLARGE * (pMoon + pSun + sunSemi) + rMoon;
            const reach = sigmaMin < reachU ? reachU : reachP;
            let rate = 2 * Math.sqrt(Math.max(1e-9, reach * reach - sigmaMin * sigmaMin)) / (ev.dur / 60);
            if (!(rate > 0.40 && rate < 0.62)) rate = shadowDriftRate(date);   // see eclipseAt()
            if (!(rate > 0)) return ev.t0;
            const half = Math.sqrt(Math.max(0, reachP * reachP - sigmaMin * sigmaMin)) / rate;   // hours
            return ev.t0 - half * 3600e3;
        }

        /*
           The next eclipse you could actually watch: one the Moon is above the
           horizon for. If none in the table ever clears your horizon, fall back
           to the next real eclipse anywhere rather than showing nothing - the
           line then says it is not visible from here. Re-looked-up once it has
           begun, and whenever the observer moves.
        */
        let nextEclipseCache = null;
        function nextEclipse() {
            const now = Date.now();
            if (!nextEclipseCache || nextEclipseCache.start <= now) {
                const ev = nextEclipseAfter(now, undefined, true) || nextEclipseAfter(now);
                nextEclipseCache = ev ? { ev: ev, start: eclipseFirstContact(ev) } : null;
                if (ev) requestEclipseForecast(ev);
            }
            return nextEclipseCache;
        }

        /*
           One writer for the status line, so it can be refreshed every second
           without redrawing the Moon. It asks for the live geometry rather than
           trusting the last render, so the countdown turns into "eclipse under way"
           the moment the penumbra is reached.
        */
        function updateEclipseStatus() {
            if (previewState.active) {
                const ev = eclipseEvents.find(e => e.t0 === previewState.lastT0);
                if (ev) {
                    const st = eclipseState;
                    eclipseStatusEl.className = 'preview';
                    eclipseStatusEl.textContent = '⏯ Preview · ' + eclipseKind(magnitudeAtGreatest(ev)) +
                        ' lunar eclipse of ' + formatEclipseDate(ev.t0) + ' · ' +
                        formatEclipseClock(previewState.t) + ' · ' +
                        phaseLabelAt(new Date(ev.t0)) + ' · ' +
                        (st ? (st.umbMag > 0
                            ? Math.round(st.obscuration * 100) + '% of the disc in shadow'
                            : 'penumbral shading only') : 'Moon clear of the shadow');
                    return;
                }
            }
            const st = eclipseAt(new Date(), observerPos.lat, observerPos.lng);
            if (st) {
                const moonAlt = SunCalc.getMoonPosition(new Date(), observerPos.lat, observerPos.lng).altitude * DEG;
                const sky = moonAlt <= 0
                    ? ' · below your horizon'
                    : ' · Moon ' + Math.round(moonAlt) + '° up' +
                      (typeof observerWeather.cloud === 'number'
                          ? ' · cloud ' + observerWeather.cloud + '%' : '');
                eclipseStatusEl.className = 'active';
                if (st.umbMag >= 1) {
                    eclipseStatusEl.textContent = "🌍 Total lunar eclipse · the whole Moon is inside Earth's umbra" + sky;
                } else if (st.umbMag > 0) {
                    eclipseStatusEl.textContent = '🌍 Partial lunar eclipse · ' +
                        (st.obscuration < 0.005
                            ? "the umbra is only just touching the disc"
                            : Math.round(st.obscuration * 100) + "% of the disc is inside Earth's umbra") + sky;
                } else {
                    eclipseStatusEl.textContent = '🌍 Penumbral lunar eclipse · soft shading, no dark bite' + sky;
                }
                return;
            }
            const next = nextEclipse();
            eclipseStatusEl.className = '';
            if (!next) { eclipseStatusEl.textContent = ''; return; }
            const vis = eclipseVisibility(next.ev);
            let note;
            if (!vis.visible) {
                note = ' · not visible from your location (Moon stays below the horizon)';
            } else {
                note = ' · Moon up to ' + Math.round(vis.maxAlt) + '°';
                if (eclipseForecast.t0 === next.ev.t0 && typeof eclipseForecast.cloud === 'number') {
                    note += ' · ' + eclipseForecast.cloud + '% cloud (forecast)';
                }
            }
            eclipseStatusEl.textContent = '🌍 Next ' + eclipseKind(magnitudeAtGreatest(next.ev)) +
                ' lunar eclipse · ' + formatEclipseDate(next.start) + ' ' + formatEclipseClock(next.start) +
                ' · in ' + formatCountdown(next.start) + note;
        }

        /* --------------------------- preview mode --------------------------
           Eclipses are rare, so the page can also walk through the next one
           that actually shows a bite at a few hundred times real speed.       */
        const previewState = { active: false, t: 0, lastT0: 0, start: 0, end: 0, speed: 420 };
        const PREVIEW_SPAN = 3 * 3600e3;           // cap on either side of greatest
        let observerPos = { lat: 52.37, lng: 4.90 };

        /*
           Every eclipse in the table, in a menu. The list is built from the
           catalogue, and each entry is marked if the Moon never clears your
           horizon while it runs - rebuilt when the observer moves, so the menu
           never offers you something you could not watch from where you are.
        */
        function buildEclipseMenu() {
            const sel = document.getElementById('eclipseSelect');
            if (!sel) return;
            const keep = sel.value;
            sel.innerHTML = '';
            const idle = document.createElement('option');
            idle.value = '';
            idle.textContent = '▶ Preview an eclipse…';
            sel.appendChild(idle);

            let group = null, decade = null;
            for (const ev of eclipseEvents) {
                if (penumbralMagnitudeAtGreatest(ev) <= 0.02) continue;   // misses entirely
                const mag = magnitudeAtGreatest(ev);
                const year = new Date(ev.t0).getUTCFullYear();
                const dec = Math.floor(year / 10) * 10;
                if (dec !== decade) {
                    decade = dec;
                    group = document.createElement('optgroup');
                    group.label = dec + 's';
                    sel.appendChild(group);
                }
                const opt = document.createElement('option');
                opt.value = String(ev.t0);
                const size = mag >= 1 ? 'total ' + mag.toFixed(2)
                    : mag > 0 ? 'partial ' + Math.round(mag * 100) + '%'
                    : 'penumbral';
                opt.textContent = formatEclipseDate(ev.t0) + ' · ' + size +
                    (eclipseVisibility(ev).visible ? '' : ' · below your horizon');
                group.appendChild(opt);
            }
            sel.value = keep;
            if (sel.selectedIndex < 0) sel.value = '';
        }

        // Start the walk-through of one eclipse, from its first contact.
        function previewEvent(ev) {
            if (!ev) return;
            previewState.lastT0 = ev.t0;
            const p1 = eclipseFirstContact(ev);
            const p4 = 2 * ev.t0 - p1;                 // the track is symmetric
            previewState.start = Math.max(p1, ev.t0 - PREVIEW_SPAN);
            previewState.end = Math.min(p4, ev.t0 + PREVIEW_SPAN);
            previewState.t = previewState.start;
            previewState.active = true;
            syncPreviewControls();
            refreshMoon();
        }

        function stopPreview() {
            previewState.active = false;
            syncPreviewControls();
            refreshMoon();
        }

        function syncPreviewControls() {
            const sel = document.getElementById('eclipseSelect');
            const btn = document.getElementById('eclipseStopBtn');
            if (sel && !previewState.active) sel.value = '';
            if (btn) btn.hidden = !previewState.active;
        }

        // Still here for the keyboard and for anyone scripting the page: with
        // nothing chosen it opens the nearest eclipse with a real bite.
        function togglePreview() {
            if (previewState.active) { stopPreview(); return; }
            let ev = null, best = Infinity;
            for (const e of eclipseEvents) {
                if (magnitudeAtGreatest(e) < 0.25) continue;
                if (penumbralMagnitudeAtGreatest(e) <= 0.02) continue;
                const g = Math.abs(e.t0 - Date.now());
                if (g < best) { best = g; ev = e; }
            }
            previewEvent(ev);
        }

        /*
           Redraw the phase and the eclipse shadows for the current (or previewed)
           moment. `when` pins one exact instant; otherwise the live clock is used,
           or the preview's own clock while a preview is running.

           A preview runs a few hundred times faster than life, and the Moon's
           parallactic angle really does turn - about a degree a minute, which is
           why the Moon appears to roll across the sky over a night. Played back at
           speed that slow roll becomes a spin, and the craters appear to rotate
           under the shadow. So while previewing, the sky is held still at greatest
           eclipse and only the shadow moves: the face keeps its orientation, the
           shadow crosses it in a straight line, which is what your eye reports
           over the few minutes you would actually stand and watch. Live, nothing
           is frozen - the frame is simply now.
        */
        function refreshMoon(when) {
            const previewing = previewState.active && !when;
            const date = when || (previewing ? new Date(previewState.t) : new Date());
            const frameDate = previewing ? new Date(previewState.lastT0) : date;
            const illum = SunCalc.getMoonIllumination(frameDate);
            const moonPos = SunCalc.getMoonPosition(frameDate, observerPos.lat, observerPos.lng);
            updateMoonVisual(illum.fraction, illum.phase,
                             (moonPos.parallacticAngle || 0) * DEG, illum.angle, frameDate);
            updateEclipseShadows(date, observerPos.lat, observerPos.lng, moonPos, illum, frameDate);
            updateEclipseStatus();
        }

        buildEclipseMenu();
        document.getElementById('eclipseSelect').addEventListener('change', () => {
            const t0 = Number(document.getElementById('eclipseSelect').value);
            if (!t0) { stopPreview(); return; }
            previewEvent(eclipseEvents.find(e => e.t0 === t0));
        });
        document.getElementById('eclipseStopBtn').addEventListener('click', stopPreview);

        /* ===== ORIGINAL MOON LOGIC (preserved) ===== */
        const moonSVG = document.getElementById('moonSVG');
        const moonIlluminatedPath = document.getElementById('moonIlluminatedPath');
        let isSpecialPhase = false;
        let currentPhaseIndex = 0;
        let nextFullMoonDate = null;

        function getPhaseIndex(illuminationFraction, phase) {
            const phaseTolerance = 0.02;
            if (illuminationFraction <= 0.01) return 0;
            if (illuminationFraction >= 0.99) return 4;
            if (Math.abs(phase - 0.25) < phaseTolerance) return 2;
            if (Math.abs(phase - 0.75) < phaseTolerance) return 6;
            if (phase <= 0.5) {
                return (illuminationFraction < 0.5) ? 1 : 3;
            }
            return (illuminationFraction < 0.5) ? 7 : 5;
        }

        /* ------------------- which way is the Moon facing? -------------------

           A drawing of the Moon has two independent orientations: the terminator,
           which follows the Sun, and the maria, which follow the Moon's own pole.
           Rotating the whole disc by the bright limb - the obvious thing, and
           what this page used to do - is right for a crescent but degenerate at
           full Moon, where the bright limb's position angle swings through some
           150 degrees in a day and drags the face around with it. So the maria
           get their own rotation, from the position angle of the Moon's north
           pole, and the two are independent of one another.

           The pole follows from Cassini's laws: the lunar equator is inclined
           1.5424 degrees to the ecliptic and its node sits at the descending node
           of the orbit, which puts the pole 1.5424 degrees from the ecliptic pole
           on the far side of it. The libration (l, b) - the selenographic
           position of the point directly beneath you - then follows from the pole
           and the direction to the observer, and is worked out topocentrically,
           so it carries the diurnal nod of about a degree that depends on where
           on Earth you are standing.

           Checked against JPL Horizons at dates in both hemispheres: l and b to
           0.08 degrees, the pole's position angle to 0.02 degrees.
        */
        function julianDayNumber(date) {
            return date.getTime() / 86400000 - 0.5 + 2440588;
        }

        // The Moon's geocentric ecliptic longitude, latitude and distance (km).
        function moonEclipticPosition(date) {
            const d = julianDayNumber(date) - 2451545.0;      // days since J2000
            const L = 218.3164477 + 13.17639648 * d;          // mean longitude
            const D = 297.8501921 + 12.19074912 * d;          // mean elongation
            const M = 134.9633964 + 13.06499295 * d;          // mean anomaly
            const Mp = 357.5291092 + 0.98560028 * d;          // Sun's mean anomaly
            const F = 93.2720950 + 13.22935024 * d;           // argument of latitude
            const r = x => x / DEG;
            let lon = L + 6.289 * Math.sin(r(M))
                + 1.274 * Math.sin(r(2 * D - M)) + 0.658 * Math.sin(r(2 * D))
                + 0.214 * Math.sin(r(2 * M)) - 0.186 * Math.sin(r(Mp))
                - 0.114 * Math.sin(r(2 * F)) + 0.059 * Math.sin(r(2 * D - 2 * M))
                + 0.057 * Math.sin(r(2 * D - Mp - M)) + 0.053 * Math.sin(r(2 * D + M));
            let lat = 5.128 * Math.sin(r(F)) + 0.281 * Math.sin(r(M + F))
                - 0.278 * Math.sin(r(F - M)) - 0.173 * Math.sin(r(F - 2 * D));
            let dist = 385000.6 - 20905 * Math.cos(r(M)) - 3699 * Math.cos(r(2 * D - M))
                - 2956 * Math.cos(r(2 * D)) - 570 * Math.cos(r(2 * M));
            return { lon: ((lon % 360) + 360) % 360, lat: lat, dist: dist };
        }

        // Geocentric position of the observer, equatorial frame, kilometres (WGS84).
        function observerVector(date, latDeg, lngDeg) {
            const jd = julianDayNumber(date);
            const gmst = (280.46061837 + 360.98564736629 * (jd - 2451545.0)) / DEG;
            const lst = gmst + lngDeg / DEG;
            const phi = latDeg / DEG;
            const f = 1 / 298.257223563, e2 = f * (2 - f);
            const sp = Math.sin(phi), cp = Math.cos(phi);
            const N = R_EARTH_KM / Math.sqrt(1 - e2 * sp * sp);
            return [N * cp * Math.cos(lst), N * cp * Math.sin(lst), N * (1 - e2) * sp];
        }

        const OBLIQUITY = 23.4392911;                          // degrees, J2000
        function equatorialToEcliptic(v) {
            const e = OBLIQUITY / DEG, c = Math.cos(e), s = Math.sin(e);
            return [v[0], v[1] * c + v[2] * s, -v[1] * s + v[2] * c];
        }
        function eclipticVector(lonDeg, latDeg) {
            const l = lonDeg / DEG, b = latDeg / DEG;
            return [Math.cos(b) * Math.cos(l), Math.cos(b) * Math.sin(l), Math.sin(b)];
        }

        /*
           l, b  - selenographic coordinates of the point directly beneath the
                   observer (the libration), east-positive.
           P     - position angle of the Moon's north pole, counter-clockwise
                   from celestial north, as JPL Horizons reports it.
        */
        function moonOrientation(date, latDeg, lngDeg) {
            const d = julianDayNumber(date) - 2451545.0;
            const node = 125.0445479 - 0.0529538083 * d;       // ascending node
            const pole = eclipticVector(node + 90, 90 - 1.54242);
            const prime = eclipticVector(218.3164477 + 13.17639648 * d + 180, 0);
            const east90 = vNorm(vCross(pole, prime));

            const mc = moonEclipticPosition(date);
            const moonVec = vScale(eclipticVector(mc.lon, mc.lat), mc.dist);
            const toObs = vNorm(vSub(equatorialToEcliptic(observerVector(date, latDeg, lngDeg)), moonVec));
            const b = Math.asin(Math.max(-1, Math.min(1, vDot(toObs, pole)))) * DEG;
            let l = Math.atan2(vDot(toObs, east90), vDot(toObs, prime)) * DEG;

            // Position angle of the pole: project the pole and celestial north
            // onto the sky, then measure counter-clockwise from north to east.
            const sight = vScale(toObs, -1);
            const northEcl = equatorialToEcliptic([0, 0, 1]);
            const nHat = vNorm(vSub(northEcl, vScale(sight, vDot(northEcl, sight))));
            const eHat = vNorm(vCross(northEcl, sight));
            const pPerp = vSub(pole, vScale(sight, vDot(pole, sight)));
            let P = Math.atan2(vDot(pPerp, eHat), vDot(pPerp, nHat)) * DEG;
            if (P < 0) P += 360;
            return { l: ((l + 180) % 360 + 360) % 360 - 180, b: b, P: P };
        }

        /*
           Draw the lit lunar surface from the actual synodic phase.
           The old four-arc version selected its sweep flags inconsistently, which
           could place the bright area on the wrong half of the disc. Sampling the
           outer limb and the terminator gives one unambiguous closed shape.
        */
        function updateMoonVisual(illuminationFraction, phase, parallacticAngle, illuminationAngle, when) {
            const r = 240;
            const cx = 250;
            const cy = 250;
            // Dense sampling removes visible polygon steps along the terminator.
            const steps = 180;
            let points = [];

            if (illuminationFraction >= 0.01) {
                const waxing = phase <= 0.5;
                const terminatorScale = Math.cos(phase * 2 * Math.PI);

                // Outer, always-visible lunar rim: right side when waxing, left when waning.
                for (let i = 0; i <= steps; i++) {
                    const t = Math.PI * i / steps;
                    points.push([
                        cx + (waxing ? 1 : -1) * r * Math.sin(t),
                        cy - r * Math.cos(t)
                    ]);
                }

                // Return along the terminator. Its changing width produces crescent,
                // quarter, gibbous and full phases without reversing the lit side.
                for (let i = steps; i >= 0; i--) {
                    const t = Math.PI * i / steps;
                    points.push([
                        cx + (waxing ? 1 : -1) * r * terminatorScale * Math.sin(t),
                        cy - r * Math.cos(t)
                    ]);
                }
            }

            const d = points.length
                ? 'M ' + points.map((pt, i) => `${i ? 'L ' : ''}${pt[0].toFixed(2)},${pt[1].toFixed(2)}`).join(' ') + ' Z'
                : '';
            // The path is used as a white SVG mask over a dark full disc. Its blur
            // creates a continuous light → twilight → total-dark terminator instead
            // of a hard cut between two filled shapes.
            document.getElementById('moonIlluminationMaskPath').setAttribute('d', d);

            /*
               SunCalc's illumination.angle is the bright-limb position angle.
               Convert it from celestial north/east coordinates into the viewer's
               local horizon with the Moon's parallactic angle. This replaces the
               previous rotation that used only the location angle, which could
               rotate a correct phase away from the Sun.
            */
            const brightLimbDegrees = (illuminationAngle || 0) * 180 / Math.PI;
            /*
               Position angles are measured from celestial north towards the east,
               which runs counter-clockwise in a true (unmirrored) view of the sky.
               Subtracting the parallactic angle re-references the bright limb to
               the zenith; the CSS rotation below is clockwise, so it takes the
               negative of that. Without the sign flip the whole disc - phase and
               maria alike - came out mirrored, and an eclipse shadow would bite
               the limb opposite the one the Sun actually lights.
            */
            const visualRotation = -(brightLimbDegrees - parallacticAngle) - 90;
            moonSVG.style.transform = `rotate(${visualRotation}deg)`;

            /*
               The maria answer to the pole, not to the Sun. Rotating them back by
               the bright limb cancels it out of their final orientation - which is
               the point: near full Moon the bright limb turns through a large
               angle in hours, and the face should not follow it. What is left is
               the pole's position angle against the parallactic angle, so the
               Moon is drawn as your horizon shows it: north up when it culminates
               in the north, upside down in the south.

               They are also shifted by the libration, so the face nods and sways
               by up to eight degrees and, by a degree or so, differently for you
               than for someone a thousand kilometres away.
            */
            const maria = document.getElementById('moonMaria');
            if (maria) {
                const orient = moonOrientation(when, observerPos.lat, observerPos.lng);
                const spin = brightLimbDegrees - orient.P + 90;
                const librationX = -240 * Math.sin(orient.l / DEG) * Math.cos(orient.b / DEG);
                const librationY = 240 * Math.sin(orient.b / DEG);
                maria.setAttribute('transform',
                    `translate(${librationX.toFixed(2)} ${librationY.toFixed(2)}) ` +
                    `rotate(${spin.toFixed(2)} 250 250)`);
            }

            // Intentional true-dark-side mode: the unlit hemisphere emits and reflects no visible light.
            // The illumination mask fades directly into black; earthshine is disabled.
            const earthshine = document.getElementById('earthshine');
            earthshine.style.opacity = 0;
        }

        /*
           NOTE: this key ships in the page, so anyone can read it with View Source.
           Restrict it in the OpenWeather dashboard to your own domain(s), or move
           the weather call behind a tiny server-side proxy. It only affects the
           "likely visible / cloud cover" line - the Moon and eclipse maths need no
           network at all.
        */
        const OPENWEATHER_API_KEY = "aa2b8c5b609148ae4e17c2fbb217cd51";

        function getCompassDirection(azimuth) {
            const dirs = ["N","NNE","NE","ENE","E","ESE","SE","SSE","S","SSW","SW","WSW","W","WNW","NW","NNW"];
            return dirs[Math.round(azimuth / 22.5) % 16];
        }

        /*
           Sky conditions for a position, on its own. The page re-asks this when
           you move and every few minutes, so the "will you see it" line is a
           current reading rather than one taken once at load.
        */
        async function fetchCloud(lat, lon) {
            const empty = { cloud: null, city: null, country: null, error: 'Weather data unavailable' };
            try {
                const url = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}` +
                    `&lon=${lon}&appid=${OPENWEATHER_API_KEY}&units=metric`;
                const res = await fetch(url);
                if (!res.ok) return empty;
                const data = await res.json();
                return {
                    cloud: (data.clouds && typeof data.clouds.all === 'number') ? data.clouds.all : null,
                    city: data.name || null,
                    country: (data.sys && data.sys.country) || '',
                    error: null
                };
            } catch (e) {
                return { cloud: null, city: null, country: null, error: 'Weather fetch failed' };
            }
        }

        async function fetchLocAndWeather() {
            return new Promise((resolve) => {
                if (!navigator.geolocation) {
                    resolve({ lat: 52.37, lon: 4.90, city: "Amsterdam", country: "NL", cloud: null,
                              error: "Geolocation not supported", fellBack: true });
                    return;
                }
                navigator.geolocation.getCurrentPosition(async (pos) => {
                    const lat = pos.coords.latitude;
                    const lon = pos.coords.longitude;
                    const w = await fetchCloud(lat, lon);
                    resolve({
                        lat, lon,
                        city: w.city || "Your Location",
                        country: w.country || "",
                        cloud: w.cloud, error: w.error, fellBack: false
                    });
                }, () => {
                    resolve({ lat: 52.37, lon: 4.90, city: "Amsterdam", country: "NL", cloud: null,
                              error: "Location permission not granted", fellBack: true });
                }, { enableHighAccuracy: false, timeout: 6000, maximumAge: 300000 });
            });
        }

        // The 📍 line, rebuilt from wherever the observer is right now.
        function renderLocationLine() {
            const now = new Date();
            const illum = SunCalc.getMoonIllumination(now);
            const pos = SunCalc.getMoonPosition(now, observerPos.lat, observerPos.lng);
            const altitude = pos.altitude * DEG;
            const azimuth = (pos.azimuth * DEG + 180) % 360;
            const cloud = observerWeather.cloud;
            let visibilityMsg;
            if (altitude <= 0) {
                visibilityMsg = "Not visible (below horizon)";
            } else if (cloud === null) {
                visibilityMsg = `Moon above horizon · ${observerWeather.error || "sky conditions unknown"}`;
            } else if (cloud < 30) {
                visibilityMsg = `Likely visible (clear, cloud ${cloud}%)`;
            } else if (cloud < 60) {
                visibilityMsg = `Partly visible (cloud ${cloud}%)`;
            } else {
                visibilityMsg = `Unlikely visible (cloud ${cloud}%)`;
            }
            const place = observerWeather.country
                ? `${observerWeather.city}, ${observerWeather.country}`
                : (observerWeather.city || "Locating…");
            const locStr = place + (observerWeather.state === 'denied'
                ? ' · default location, permission not granted' : '');
            document.getElementById('location').textContent =
                `📍 ${locStr} · Illum ${(illum.fraction * 100).toFixed(0)}% · Az ${azimuth.toFixed(0)}° ` +
                `${getCompassDirection(azimuth)} · Alt ${altitude.toFixed(0)}° · ${visibilityMsg}`;
        }

        function mergeWeather(w) {
            observerWeather = {
                cloud: w.cloud,
                city: w.city || observerWeather.city,
                country: w.country || observerWeather.country,
                error: w.error || null,
                // A refused location stays refused even if a weather call lands.
                state: observerWeather.state === 'denied' ? 'denied' : (w.error ? 'no-weather' : 'granted')
            };
        }

        /*
           Move the observer. The Moon's altitude, which eclipse is next and
           whether you can see it all depend on it, so the caches are dropped
           and the page is redrawn - but only on a real move, since a phone
           reports a new fix every few seconds even when it is sitting still.
        */
        let positionApplied = false;
        function applyPosition(lat, lon, weather) {
            if (weather) mergeWeather(weather);
            const moved = Math.abs(lat - observerPos.lat) + Math.abs(lon - observerPos.lng) > 0.02;
            if (moved || !positionApplied) {
                observerPos = { lat: lat, lng: lon };
                nextEclipseCache = null;
                visibilityCache.clear();
                buildEclipseMenu();
                positionApplied = true;
                refreshMoon();
            }
            renderLocationLine();
        }

        /*
           Keep following the observer: a new fix when the device moves, fresh
           sky conditions every few minutes, and an immediate catch-up when the
           tab comes back rather than waiting for the next scheduled tick.
        */
        const WEATHER_REFRESH_MS = 10 * 60e3;
        function startLiveUpdates() {
            if (navigator.geolocation && navigator.geolocation.watchPosition) {
                let busy = false;
                navigator.geolocation.watchPosition(async pos => {
                    if (busy) return;
                    busy = true;
                    try {
                        const lat = pos.coords.latitude, lon = pos.coords.longitude;
                        applyPosition(lat, lon, await fetchCloud(lat, lon));
                    } finally { busy = false; }
                }, () => {}, { enableHighAccuracy: false, timeout: 20000, maximumAge: 120000 });
            }

            setInterval(async () => {
                if (document.hidden) return;      // a hidden tab catches up on return
                mergeWeather(await fetchCloud(observerPos.lat, observerPos.lng));
                renderLocationLine();
                // A forecast only exists once the eclipse is inside five days.
                const next = nextEclipseCache && nextEclipseCache.ev;
                if (next && Date.now() - (eclipseForecast.at || 0) > 30 * 60e3) {
                    requestEclipseForecast(next);
                }
            }, WEATHER_REFRESH_MS);

            const catchUp = () => { refreshMoon(); renderLocationLine(); };
            document.addEventListener('visibilitychange', () => { if (!document.hidden) catchUp(); });
            window.addEventListener('focus', catchUp);
            window.addEventListener('online', catchUp);
        }

        async function show() {
            const now = new Date();
            const { lat, lon, city, country, cloud, error, fellBack } = await fetchLocAndWeather();

            const moonIllumination = SunCalc.getMoonIllumination(now);
            const moonPos = SunCalc.getMoonPosition(now, lat, lon);

            const illuminationFraction = moonIllumination.fraction;
            const phase = moonIllumination.phase;

            currentPhaseIndex = getPhaseIndex(illuminationFraction, phase);
            isSpecialPhase = (currentPhaseIndex === 0 || currentPhaseIndex === 4);

            observerPos = { lat: lat, lng: lon };
            observerWeather = { cloud: cloud, city: city, country: country, error: error,
                                state: fellBack ? 'denied' : (error ? 'no-weather' : 'granted') };
            nextEclipseCache = null;      // the answer depends on where you are
            visibilityCache.clear();
            buildEclipseMenu();           // and so does which eclipses you can see
            positionApplied = true;
            refreshMoon(now);   // phase + any eclipse shadow, for this exact moment
            renderLocationLine();

            document.getElementById('phaseName').textContent = phases[currentPhaseIndex];
            updatePoem();

            startLiveUpdates();           // from here on, follow the observer
        }

        const localeLanguages = {
            en: 'en', de: 'de', it: 'it', hu: 'hu', fi: 'fi', ru: 'ru', ku: 'ku',
            he: 'he', ar: 'ar', hi: 'hi', zn: 'zh-CN', jp: 'ja', jv: 'jv', vi: 'vi',
            ko: 'ko', peru: 'es-PE', brazil: 'pt-BR', suriname: 'nl-SR',
            mexico: 'es-MX', haiti: 'ht', argentina: 'es-AR', us: 'en-US', canada: 'en-CA'
        };

        function updatePoem() {
            const locale = document.getElementById('regionSelect').value;
            const poemSet = poems[locale] || poems.en;
            const entry = poemSet[currentPhaseIndex] || { n: '…', e: '', c: '' };

            const poemEl = document.getElementById('poem');
            poemEl.textContent = entry.n || '…';
            poemEl.lang = localeLanguages[locale] || 'en';

            const translationWrap = document.getElementById('translationWrap');
            const translationEl = document.getElementById('translation');
            if (entry.e) {
                translationEl.textContent = entry.e;
                translationWrap.hidden = false;
            } else {
                translationEl.textContent = '';
                translationWrap.hidden = true;
            }

            document.getElementById('poemContext').textContent = entry.c || '';
        }

        let lastFrameAt = Date.now();
        let lastEclipseCheck = 0;

        function draw() {
            const now = Date.now();
            // Easter egg: at exact New Moon and Full Moon, only the outer halo
            // slowly cycles through colour. The geographically based lunar surface
            // and the real phase shadows remain untouched. A deep eclipse takes
            // over the halo instead - a rainbow ring around a blood moon is wrong.
            const deep = eclipseState ? eclipseDepth(eclipseState) : 0;
            const specialHue = isSpecialPhase ? (now / 50) % 360 : 45;
            document.documentElement.style.setProperty('--hue',
                deep > 0.05 ? (26 - 6 * deep).toFixed(1) : specialHue);
            document.documentElement.style.setProperty('--halo-a',
                (0.28 * (1 - 0.78 * deep)).toFixed(3));

            if (previewState.active) {
                // Walk the clock through the eclipse, then loop back to first contact.
                previewState.t += Math.min(now - lastFrameAt, 100) * previewState.speed;
                if (previewState.t >= previewState.end) previewState.t = previewState.start;
                if (now - lastEclipseCheck > 40) { lastEclipseCheck = now; refreshMoon(); }
            } else if (now - lastEclipseCheck > 20000) {
                // Between eclipses nothing moves fast; 20 s keeps the status honest.
                lastEclipseCheck = now;
                refreshMoon();
                renderLocationLine();
            }
            lastFrameAt = now;

            moonIlluminatedPath.style.fill = 'url(#moonSurface)';
            requestAnimationFrame(draw);
        }

        function updateLocalClock() {
            const now = new Date();
            const opts = { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric',
                           hour: '2-digit', minute: '2-digit', second: '2-digit' };
            document.getElementById('localClock').textContent =
                `🕒 Local time: ${now.toLocaleDateString(undefined, opts)}`;
        }

        function findNextFullMoon(startDate) {
            let checkDate = new Date(startDate.getTime());
            for (let i = 0; i < 40; i++) {
                const illum = SunCalc.getMoonIllumination(checkDate);
                if (illum.fraction >= 0.995) {
                    nextFullMoonDate = checkDate;
                    return;
                }
                checkDate.setDate(checkDate.getDate() + 1);
            }
            nextFullMoonDate = null;
        }

        // "12d 4h 9m 3s" - shared by the full-Moon and next-eclipse countdowns.
        function formatCountdown(targetMs) {
            let diff = targetMs - Date.now();
            if (diff <= 0) return 'now';
            let txt = '';
            const days = Math.floor(diff / 86400000); diff -= days * 86400000;
            const hours = Math.floor(diff / 3600000); diff -= hours * 3600000;
            const minutes = Math.floor(diff / 60000); diff -= minutes * 60000;
            const seconds = Math.floor(diff / 1000);
            if (days > 0) txt += days + 'd ';
            if (days > 0 || hours > 0) txt += hours + 'h ';
            if (days > 0 || hours > 0 || minutes > 0) txt += minutes + 'm ';
            return txt + seconds + 's';
        }

        function updateFullMoonCountdown() {
            const now = new Date();
            if (!nextFullMoonDate || nextFullMoonDate.getTime() < now.getTime()) {
                findNextFullMoon(now);
            }
            if (!nextFullMoonDate) {
                document.getElementById('fullMoonCountdown').textContent = "🌕 Calculating next Full Moon…";
                return;
            }
            const diff = nextFullMoonDate.getTime() - now.getTime();
            if (diff <= 0) {
                document.getElementById('fullMoonCountdown').textContent = "🌕 Full Moon is now!";
                nextFullMoonDate = null;
                return;
            }
            document.getElementById('fullMoonCountdown').textContent =
                '🌕 Next Full Moon in: ' + formatCountdown(nextFullMoonDate.getTime());
        }

        function createStarfield() {
            const field = document.getElementById('starfield');
            for (let i = 0; i < 220; i++) {
                const s = document.createElement('div');
                s.className = 'star' + (Math.random() > 0.85 ? ' bright' : '');
                const size = Math.random() * 2.2 + 0.6;
                s.style.width = size + 'px';
                s.style.height = size + 'px';
                s.style.top = Math.random() * 100 + '%';
                s.style.left = Math.random() * 100 + '%';
                s.style.setProperty('--dur', (1.8 + Math.random() * 4) + 's');
                s.style.animationDelay = Math.random() * 5 + 's';
                field.appendChild(s);
            }
            setInterval(() => {
                const sh = document.createElement('div');
                sh.className = 'shooter';
                sh.style.top = Math.random() * 40 + '%';
                sh.style.left = (60 + Math.random() * 40) + '%';
                field.appendChild(sh);
                setTimeout(() => sh.remove(), 1200);
            }, 6500);
        }

        document.getElementById('regionSelect').addEventListener('change', updatePoem);

        window.addEventListener('load', () => {
            createStarfield();
            updatePoem(); // render immediately, before location/weather requests finish
            show();
            draw();
            updateLocalClock();
            updateFullMoonCountdown();
            setInterval(show, 1000 * 60 * 60 * 3);
            setInterval(updateLocalClock, 1000);
            setInterval(updateFullMoonCountdown, 1000);
            setInterval(updateEclipseStatus, 1000);   // keeps the countdown ticking
        });
    
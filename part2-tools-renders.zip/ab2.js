const puppeteer = require('puppeteer');
(async () => {
    const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
    const page = await browser.newPage();
    await page.setViewport({ width: 900, height: 1400 });
    await page.goto('file://' + process.cwd() + '/moon-new-poems-true-dark-side.html', { waitUntil: 'load' });
    await new Promise(r => setTimeout(r, 2000));
    await page.evaluate(() => { document.getElementById('moonSVG').style.transform = 'rotate(0deg)'; });
    const scan = () => page.evaluate(() => {
        const svg = document.getElementById('moonSVG');
        const xml = new XMLSerializer().serializeToString(svg);
        const img = new Image();
        return new Promise(res => {
            img.onload = () => {
                const c = document.createElement('canvas');
                c.width = 500; c.height = 500;
                const g = c.getContext('2d');
                g.drawImage(img, 0, 0, 500, 500);
                const row = g.getImageData(0, 250, 500, 1).data;
                const out = [];
                for (let x = 180; x < 260; x += 2) {
                    out.push([x, Math.round(0.299*row[4*x] + 0.587*row[4*x+1] + 0.114*row[4*x+2])]);
                }
                res(out);
            };
            img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(xml);
        });
    });
    console.log('both   ', JSON.stringify(await scan()));
    await page.evaluate(() => { for (const p of document.querySelectorAll('#termGlow path')) p.setAttribute('d',''); });
    await new Promise(r => setTimeout(r, 100));
    console.log('noglow ', JSON.stringify(await scan()));
    await browser.close();
})();

const puppeteer = require('puppeteer');
(async () => {
    const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
    const page = await browser.newPage();
    await page.setViewport({ width: 900, height: 1400 });
    const errs = []; page.on('pageerror', e => errs.push(e.message));
    await page.goto('file://' + process.cwd() + '/moon-page-fixed-v14.html', { waitUntil: 'load' });
    await new Promise(r => setTimeout(r, 2000));
    const st = await page.evaluate(() => ({
        title: document.title.includes('FIXED v14'),
        duskLive: [...document.querySelectorAll('#termDusk path')].filter(p => (p.getAttribute('d')||'').length > 4).length,
        glowLive: [...document.querySelectorAll('#termGlow path')].filter(p => (p.getAttribute('d')||'').length > 4).length,
        bandsOp: document.getElementById('terminatorBands').getAttribute('opacity')
    }));
    console.log(JSON.stringify(st), 'errors:', errs.length ? errs.join('|') : '(none)');
    await browser.close();
})();

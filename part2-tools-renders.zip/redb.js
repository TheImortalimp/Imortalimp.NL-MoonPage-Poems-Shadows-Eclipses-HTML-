const puppeteer = require('puppeteer');
const fs = require('fs');
(async () => {
    const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
    const page = await browser.newPage();
    await page.setViewport({ width: 900, height: 1400 });
    const errs = []; page.on('pageerror', e => errs.push(e.message));
    await page.goto('file://' + process.cwd() + '/moon-new-poems-true-dark-side.html', { waitUntil: 'load' });
    await new Promise(r => setTimeout(r, 1500));
    const set = (t0) => page.evaluate((t0) => {
        const sel = document.getElementById('eclipseSelect');
        sel.value = String(t0); sel.dispatchEvent(new Event('change', { bubbles: true }));
    }, t0);
    // TOTAL at greatest
    await set(1772537580000); await new Promise(r => setTimeout(r, 400));
    await page.evaluate(() => { previewState.t = previewState.lastT0; refreshMoon(); });
    let el = await page.$('#moonContainer'); await el.screenshot({ path: 'r-tot.png' });
    // overlay killed -> mask must still carve the bite
    await page.evaluate(() => { document.getElementById('eclipseShadows').setAttribute('opacity', '0'); });
    el = await page.$('#moonContainer'); await el.screenshot({ path: 'r-tot-nooverlay.png' });
    // PARTIAL Aug 2026 at greatest, overlay killed too
    await set(1787890320000); await new Promise(r => setTimeout(r, 400));
    await page.evaluate(() => { previewState.t = previewState.lastT0; refreshMoon(); document.getElementById('eclipseShadows').setAttribute('opacity', '0'); });
    el = await page.$('#moonContainer'); await el.screenshot({ path: 'r-part-nooverlay.png' });
    // restore overlay; PARTIAL normal
    await page.evaluate(() => { refreshMoon(); });
    el = await page.$('#moonContainer'); await el.screenshot({ path: 'r-part.png' });
    // PENUMBRAL Feb 2027 at greatest, normal overlay
    await set(1803165120000); await new Promise(r => setTimeout(r, 400));
    await page.evaluate(() => { previewState.t = previewState.lastT0; refreshMoon(); });
    el = await page.$('#moonContainer'); await el.screenshot({ path: 'r-pen.png' });
    // penumbral with overlay killed
    await page.evaluate(() => { document.getElementById('eclipseShadows').setAttribute('opacity', '0'); });
    el = await page.$('#moonContainer'); await el.screenshot({ path: 'r-pen-nooverlay.png' });
    console.log('errors:', errs.length ? errs.join('|') : '(none)');
    await browser.close();
})();

const puppeteer = require('puppeteer');
const path = require('path');
const file = process.argv[2];

(async () => {
    const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
    const page = await browser.newPage();
    await page.setViewport({ width: 900, height: 1200 });
    page.on('pageerror', e => console.log('PAGEERROR', e.message));
    await page.goto('file://' + path.resolve(file), { waitUntil: 'load' });
    await new Promise(r => setTimeout(r, 1500));

    const rows = await page.evaluate(() => {
        const out = [];
        for (const ev of eclipseEvents) {
            const pen0 = penumbralMagnitudeAtGreatest(ev);
            if (pen0 <= 0.02) { out.push({ t0: ev.t0, kind: 'MISS' }); continue; }
            const mag = magnitudeAtGreatest(ev);
            previewEvent(ev);
            previewState.t = ev.t0; refreshMoon();
            const st = eclipseState;
            if (!st) { out.push({ t0: ev.t0, kind: 'NOST', mag: +mag.toFixed(2), pen: +pen0.toFixed(2) }); continue; }
            // alpha of the penumbra at the disc point nearest the shadow centre
            const inner = st.rhoU / st.rhoP;
            const s1 = inner + 0.62 * (1 - inner);
            const nearOff = Math.max(0, (st.sigma - st.rMoon)) / st.rhoP;
            let aNear;
            if (nearOff <= inner) aNear = 0.70;
            else if (nearOff <= s1) aNear = 0.70 + (0.45 - 0.70) * (nearOff - inner) / (s1 - inner);
            else aNear = 0.45 * Math.max(0, 1 - (nearOff - s1) / (1 - s1));
            out.push({
                t0: ev.t0,
                kind: mag >= 1 ? 'TOTAL' : mag > 0 ? 'PART' : 'PEN',
                mag: +mag.toFixed(2), pen: +pen0.toFixed(2),
                umbMag: +st.umbMag.toFixed(2), obs: +st.obscuration.toFixed(2),
                aNear: +aNear.toFixed(2), layerOp: +document.getElementById('eclipseShadows').getAttribute('opacity')
            });
        }
        return out;
    });

    const show = rows.filter(r => r.kind !== 'MISS');
    console.log('touching events:', show.length);
    const weak = show.filter(r => r.kind === 'PEN' && r.aNear < 0.25);
    const nost = rows.filter(r => r.kind === 'NOST');
    const partNoBite = show.filter(r => r.kind === 'PART' && r.obs <= 0.01);
    const totNoBite = show.filter(r => r.kind === 'TOTAL' && r.obs < 0.99);
    console.log('penumbral events with weak limb shading (aNear<0.25):');
    weak.forEach(r => console.log('  ', new Date(r.t0).toISOString().slice(0, 10), r.kind, 'mag', r.mag, 'pen', r.pen, 'aNear', r.aNear));
    console.log('no-state / partial-without-bite / total-without-full-bite:');
    [...nost, ...partNoBite, ...totNoBite].forEach(r => console.log('  ', new Date(r.t0).toISOString().slice(0, 10), JSON.stringify(r)));
    console.log('--- penumbral aNear distribution ---');
    show.filter(r => r.kind === 'PEN').forEach(r => console.log('  ', new Date(r.t0).toISOString().slice(0, 10), 'pen', r.pen, 'aNear', r.aNear));
    await browser.close();
})();

import ephem, math, sys
from datetime import datetime, timezone

DEG = 180.0 / math.pi

def obs_vec_km(date, lat, lng):
    jd = date.timestamp() / 86400.0 + 2440587.5
    gmst = (280.46061837 + 360.98564736629 * (jd - 2451545.0)) % 360.0
    lst = math.radians((gmst + lng) % 360.0)
    phi = math.radians(lat)
    f = 1 / 298.257223563
    e2 = f * (2 - f)
    N = 6378.137 / math.sqrt(1 - e2 * math.sin(phi) ** 2)
    return [N * math.cos(phi) * math.cos(lst), N * math.cos(phi) * math.sin(lst), N * (1 - e2) * math.sin(phi)]

def enu_of(vec_eq, date, lat, lng):
    jd = date.timestamp() / 86400.0 + 2440587.5
    th = math.radians((280.46061837 + 360.98564736629 * (jd - 2451545.0) + lng) % 360.0)
    phi = math.radians(lat)
    E = [-math.sin(th), math.cos(th), 0]
    N = [-math.sin(phi) * math.cos(th), -math.sin(phi) * math.sin(th), math.cos(phi)]
    U = [math.cos(phi) * math.cos(th), math.cos(phi) * math.sin(th), math.sin(phi)]
    d = lambda a, b: a[0]*b[0]+a[1]*b[1]+a[2]*b[2]
    return [d(vec_eq, E), d(vec_eq, N), d(vec_eq, U)]

def altaz(v_enu):
    n = math.sqrt(sum(x*x for x in v_enu)) or 1
    v = [x/n for x in v_enu]
    return math.degrees(math.asin(v[2])), math.degrees(math.atan2(v[0], v[1])) % 360

def screen_cw(v_enu, alt, az):
    a, z = math.radians(alt), math.radians(az)
    right = [math.cos(z), -math.sin(z), 0]
    up = [-math.sin(a)*math.sin(z), -math.sin(a)*math.cos(z), math.cos(a)]
    d = lambda p, q: p[0]*q[0]+p[1]*q[1]+p[2]*q[2]
    return math.degrees(math.atan2(d(v_enu, right), d(v_enu, up)))

def wrap(a):
    return (a + 180) % 360 - 180

CASES = [
    ("now?                   AMS", None, 52.37, 4.90),
    ("next-ecl P1+1h         AMS", "2027-02-20 22:12:00", 52.37, 4.90),
    ("next-ecl P4-1h         AMS", "2027-02-21 00:12:00", 52.37, 4.90),
    ("part2026 U-1h          AMS", "2026-08-28 03:12:00", 52.37, 4.90),
    ("part2026 U+1h          AMS", "2026-08-28 05:12:00", 52.37, 4.90),
    ("part2026 U-1h          SYD", "2026-08-28 03:12:00", -33.87, 151.21),
    ("total2026 U1+20m       NYC", "2026-03-03 10:39:00", 40.71, -74.0),
]

for label, ts, lat, lng in CASES:
    if ts is None:
        date = datetime.now(timezone.utc).replace(tzinfo=None)
    else:
        date = datetime.strptime(ts, "%Y-%m-%d %H:%M:%S")
    o = ephem.Observer()
    o.lat, o.lon, o.date = str(lat), str(lng), ephem.date(date)
    m = ephem.Moon(); m.compute(o)          # topocentric
    # geocentric moon & sun vectors (equatorial, AU) from ephem:
    gm = ephem.Moon(); gm.compute(ephem.date(date))     # no observer -> geocentric
    gs = ephem.Sun(); gs.compute(ephem.date(date))
    AU = 149597870.7
    def vec(body):
        r = body.earth_distance * AU
        return [r*math.cos(body.dec)*math.cos(body.ra), r*math.cos(body.dec)*math.sin(body.ra), r*math.sin(body.dec)]
    mkm = vec(gm); skm = vec(gs)
    ov = obs_vec_km(date, lat, lng)
    mtopo = [mkm[i] - ov[i] for i in range(3)]
    dl = math.hypot(*mkm)
    axis = [-skm[i] / math.hypot(*skm) * dl for i in range(3)]
    atopo = [axis[i] - ov[i] for i in range(3)]
    men = enu_of(mtopo, date, lat, lng)
    aen = enu_of(atopo, date, lat, lng)
    alt, az = altaz(men)
    # perpendicular part of axis dir against moon sight line
    d = sum(aen[i]*men[i] for i in range(3)) / (math.hypot(*men)**2)
    perp = [aen[i] - d*men[i] for i in range(3)]
    shadow = screen_cw(perp, alt, az)
    print(f"{label} | moon alt/az {alt:6.1f} {az:6.1f} | GT shadowDir {wrap(shadow):7.1f}")

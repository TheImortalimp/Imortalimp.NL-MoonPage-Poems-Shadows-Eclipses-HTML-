const puppeteer = require('puppeteer');

const PHASES = [
    ['crescent', 0.18], ['quarter', 0.5], ['gibbous', 0.82]
];

(async () => {
    const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
    const page = await browser.newPage();
    await page.setViewport({ width: 900, height: 1400 });
    const errs = [];
    page.on('pageerror', e => errs.push(e.message));
    await page.goto('file://' + process.cwd() + '/moon-new-poems-true-dark-side.html',
                    { waitUntil: 'load' });
    await new Promise(r => setTimeout(r, 2000));

    const shot = async (n) => {
        const el = await page.$('#moonContainer');
        await el.screenshot({ path: n });
    };
    const set = (t0) => page.evaluate((t0) => {
        const sel = document.getElementById('eclipseSelect');
        sel.value = String(t0);
        sel.dispatchEvent(new Event('change', { bubbles: true }));
    }, t0);
    // Zero the sky rotation so a horizontal pixel scan crosses the shading
    // at right angles; the render itself is untouched.
    const flat = () => page.evaluate(() => {
        document.getElementById('moonSVG').style.transform = 'rotate(0deg)';
    });
    const diag = () => page.evaluate(() => {
        const dusk = [...document.querySelectorAll('#termDusk path')];
        const glow = [...document.querySelectorAll('#termGlow path')];
        const live = (a) => a.filter(p => (p.getAttribute('d') || '').length > 4);
        const alphas = live(dusk).map(p => +p.getAttribute('fill-opacity'));
        return {
            duskTotal: dusk.length, duskLive: live(dusk).length,
            glowTotal: glow.length, glowLive: live(glow).length,
            alphaMax: alphas.length ? Math.max(...alphas) : 0,
            alphaMin: alphas.length ? Math.min(...alphas) : 0,
            maxStep: alphas.length > 1
                ? Math.max(...alphas.slice(1).map((a, i) => Math.abs(a - alphas[i])))
                : 0,
            bandsOp: document.getElementById('terminatorBands').getAttribute('opacity'),
            layerOp: document.getElementById('eclipseShadows').getAttribute('opacity'),
            illum: eclipseState ? eclipseState.illum : null,
            penMag: eclipseState ? eclipseState.penMag : null
        };
    });

    // --- live moon, natural orientation -------------------------------
    await shot('v14-live.png');
    console.log('live   ', JSON.stringify(await diag()));

    // --- live moon, rotation zeroed, for the pixel scan ---------------
    await flat(); await new Promise(r => setTimeout(r, 200));
    await shot('v14-scan.png');

    // --- phase strip ---------------------------------------------------
    for (const [name, f] of PHASES) {
        await page.evaluate((f) => {
            updateMoonVisual(f, f, 0, { altitude: 0.5, azimuth: Math.PI, parallacticAngle: 0 }, new Date());
            document.getElementById('moonSVG').style.transform = 'rotate(0deg)';
        }, f);
        await new Promise(r => setTimeout(r, 150));
        await shot('v14-phase-' + name + '.png');
    }

    // --- repaint cost ---------------------------------------------------
    const ms = await page.evaluate(() => {
        const t = [];
        for (let i = 0; i < 20; i++) {
            twilightSignature = null;                 // force a full recut
            const a = performance.now();
            updateMoonVisual(0.62, 0.62, 0, { altitude: 0.5, azimuth: Math.PI, parallacticAngle: 0 }, new Date());
            t.push(performance.now() - a);
        }
        return { mean: t.reduce((x, y) => x + y, 0) / t.length, max: Math.max(...t) };
    });
    console.log('repaint ms  mean', ms.mean.toFixed(2), ' max', ms.max.toFixed(2));

    // --- Feb 2027 penumbral -------------------------------------------
    await set(1803165120000); await new Promise(r => setTimeout(r, 400));
    await page.evaluate(() => {
        previewState.t = previewState.start + (previewState.end - previewState.start) * 0.3;
        refreshMoon();
        document.getElementById('moonSVG').style.transform = 'rotate(0deg)';
    });
    await new Promise(r => setTimeout(r, 150));
    await shot('v14-pen-early.png');
    console.log('pen-early', JSON.stringify(await diag()));

    await page.evaluate(() => {
        previewState.t = previewState.lastT0; refreshMoon();
        document.getElementById('moonSVG').style.transform = 'rotate(0deg)';
    });
    await new Promise(r => setTimeout(r, 150));
    await shot('v14-pen-max.png');
    console.log('pen-max  ', JSON.stringify(await diag()));

    // --- Aug 2026 partial, greatest (copper must survive) --------------
    await set(1787890320000); await new Promise(r => setTimeout(r, 400));
    await page.evaluate(() => {
        previewState.t = previewState.lastT0; refreshMoon();
        document.getElementById('moonSVG').style.transform = 'rotate(0deg)';
    });
    await new Promise(r => setTimeout(r, 150));
    await shot('v14-greatest.png');
    console.log('greatest ', JSON.stringify(await diag()));

    // --- Mar 2026 total, totality --------------------------------------
    await set(1772537580000); await new Promise(r => setTimeout(r, 400));
    await page.evaluate(() => {
        previewState.t = previewState.lastT0; refreshMoon();
        document.getElementById('moonSVG').style.transform = 'rotate(0deg)';
    });
    await new Promise(r => setTimeout(r, 150));
    await shot('v14-total.png');
    console.log('total    ', JSON.stringify(await diag()));

    console.log('errors:', errs.length ? errs.join(' | ') : '(none)');
    await browser.close();
})();

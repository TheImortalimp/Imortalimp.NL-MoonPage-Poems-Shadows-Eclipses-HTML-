const puppeteer = require('puppeteer');
const path = require('path');

(async () => {
    const browser = await puppeteer.launch({ args: ['--no-sandbox', '--allow-file-access-from-files'] });
    const page = await browser.newPage();
    await page.setViewport({ width: 900, height: 1200, deviceScaleFactor: 1 });
    const msgs = [];
    page.on('console', m => { if (m.type() === 'error' || m.type() === 'warning') msgs.push(m.type() + ': ' + m.text()); });
    page.on('pageerror', e => msgs.push('pageerror: ' + e.message));

    await page.goto('file://' + path.resolve(process.argv[2] || 'uploads/moon-new-poems-true-dark-side.html'), { waitUntil: 'load' });
    await new Promise(r => setTimeout(r, 2000));

    const which = process.argv[3] || 'next';
    const info = await page.evaluate((which) => {
        const sel = document.getElementById('eclipseSelect');
        let t0 = null;
        if (which === 'next') {
            const fut = eclipseEvents.filter(e => e.t0 > Date.now());
            t0 = fut[0].t0;
        } else { t0 = Number(which); }
        const ev = eclipseEvents.find(e => e.t0 === t0);
        sel.value = String(t0);
        sel.dispatchEvent(new Event('change', { bubbles: true }));
        return { t0, kind: eclipseKind(magnitudeAtGreatest(ev)), mag: +magnitudeAtGreatest(ev).toFixed(3),
                 penMag: +penumbralMagnitudeAtGreatest(ev).toFixed(3),
                 status: document.getElementById('eclipseStatus').textContent,
                 selText: sel.options[sel.selectedIndex] && sel.options[sel.selectedIndex].textContent };
    }, which);
    console.log('selected:', JSON.stringify(info, null, 1));

    const tag = (which === 'next' ? 'next' : which);
    for (const f of [0.05, 0.25, 0.5, 0.75, 0.95]) {
        const st = await page.evaluate((f) => {
            const t = previewState.start + (previewState.end - previewState.start) * f;
            previewState.t = t; lastEclipseCheck = 0; refreshMoon();
            return { t: new Date(t).toISOString(), status: document.getElementById('eclipseStatus').textContent,
                     opacity: document.getElementById('eclipseShadows').getAttribute('opacity'),
                     st: eclipseState ? { umbMag: +eclipseState.umbMag.toFixed(3), penMag: +eclipseState.penMag.toFixed(3),
                                          obsc: +eclipseState.obscuration.toFixed(3) } : null };
        }, f);
        console.log('f=' + f, JSON.stringify(st));
        const el = await page.$('#moonContainer');
        await el.screenshot({ path: `shot-${tag}-f${String(f).replace('.', '')}.png` });
    }
    // also a full-page shot at greatest eclipse
    await page.evaluate(() => { previewState.t = eclipseEvents.find(e => e.t0 === previewState.lastT0).t0; refreshMoon(); });
    await page.screenshot({ path: `shot-${tag}-full.png`, fullPage: false });

    console.log('--- console messages ---');
    console.log(msgs.length ? msgs.join('\n') : '(none)');
    await browser.close();
})();

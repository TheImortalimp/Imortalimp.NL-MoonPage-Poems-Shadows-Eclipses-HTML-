const puppeteer = require('puppeteer');
const path = require('path');
(async () => {
    const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
    const page = await browser.newPage();
    await page.setViewport({ width: 900, height: 1200 });
    const errs = [];
    page.on('pageerror', e => errs.push(e.message));
    await page.goto('file://' + path.resolve('moon-new-poems-true-dark-side.html'), { waitUntil: 'load' });
    await new Promise(r => setTimeout(r, 1500));
    const grab = async (prefix, t0, fracs) => {
        for (const [name, f] of fracs) {
            await page.evaluate(([t0, f]) => {
                const ev = eclipseEvents.find(e => e.t0 === t0);
                previewEvent(ev);
                previewState.t = previewState.start + (previewState.end - previewState.start) * f;
                refreshMoon();
            }, [t0, f]);
            const el = await page.$('#moonContainer');
            await el.screenshot({ path: `${prefix}-${name}.png` });
        }
    };
    const tTot = await page.evaluate(() => eclipseEvents.find(e => new Date(e.t0).toISOString().startsWith('2026-03-03')).t0);
    const tShal = await page.evaluate(() => eclipseEvents.find(e => new Date(e.t0).toISOString().startsWith('2031-06-05')).t0);
    const tNext = await page.evaluate(() => eclipseEvents.filter(e => e.t0 > Date.now())[0].t0);
    await grab('v-total', tTot, [['bite', 0.3], ['tot', 0.5], ['exit', 0.72]]);
    await grab('v-shal', tShal, [['max', 0.5], ['q1', 0.35]]);
    await grab('v-next', tNext, [['max', 0.5]]);
    console.log('errors:', errs.length ? errs.join('|') : '(none)');
    await browser.close();
})();

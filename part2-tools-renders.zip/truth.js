/* Independent ground truth for sky-view orientation, compared with the page. */
const DEG = 180 / Math.PI;

/* --- minimal ephemeris (Meeus, truncated) --- */
function sunEquatorial(date) {
    const d = (date.getTime() / 86400000) - 10957.5; // days since J2000
    const L = (280.460 + 0.9856474 * d) / DEG;
    const g = (357.528 + 0.9856003 * d) / DEG;
    const lam = L + (1.915 * Math.sin(g) + 0.020 * Math.sin(2 * g)) / DEG;
    const eps = (23.439 - 0.0000004 * d) / DEG;
    const ra = Math.atan2(Math.cos(eps) * Math.sin(lam), Math.cos(lam)) * DEG;
    const dec = Math.asin(Math.sin(eps) * Math.sin(lam)) * DEG;
    return { ra: (ra + 360) % 360, dec };
}
function moonEquatorial(date) {
    const d = (date.getTime() / 86400000) - 10957.5;
    const L = (218.316 + 13.176396 * d) / DEG;              // mean longitude
    const M = (134.963 + 13.064993 * d) / DEG;              // mean anomaly
    const F = (93.272 + 13.229350 * d) / DEG;               // mean argument of latitude
    const Ms = (357.529 + 0.9856003 * d) / DEG;             // solar anomaly
    const D = (297.850 + 12.190749 * d) / DEG;              // mean elongation
    const lon = L + (6.289 * Math.sin(M) + 1.274 * Math.sin(2 * D - M) + 0.658 * Math.sin(2 * D)
        - 0.186 * Math.sin(Ms) - 0.059 * Math.sin(2 * M - 2 * D) - 0.057 * Math.sin(M - 2 * D + Ms)
        + 0.053 * Math.sin(M + 2 * D) + 0.046 * Math.sin(2 * D - Ms) + 0.041 * Math.sin(M - Ms)
        - 0.035 * Math.sin(D) - 0.031 * Math.sin(M + Ms)) / DEG;
    const lat = (5.128 * Math.sin(F) + 0.281 * Math.sin(M + F) + 0.278 * Math.sin(M - F)
        + 0.173 * Math.sin(2 * D - F)) / DEG;
    const dist = 385001 - 20905 * Math.cos(M) - 3699 * Math.cos(2 * D - M) - 2956 * Math.cos(2 * D); // km
    const eps = (23.439 - 0.0000004 * d) / DEG;
    const lb = lat / 1, ll = lon;
    // ecliptic -> equatorial
    const x = Math.cos(lb) * Math.cos(ll), y = Math.cos(lb) * Math.sin(ll), z = Math.sin(lb);
    const ye = y * Math.cos(eps) - z * Math.sin(eps), ze = y * Math.sin(eps) + z * Math.cos(eps);
    return { ra: (Math.atan2(ye, x) * DEG + 360) % 360, dec: Math.asin(ze) * DEG, dist };
}
function gmst(date) {
    const d = (date.getTime() / 86400000) - 10957.5;
    return (280.46061837 + 360.98564736629 * d) % 360;
}
function equatorialToENU(raDeg, decDeg, date, lat, lng) {
    const H = (gmst(date) + lng - raDeg) / DEG;
    const phi = lat / DEG, de = decDeg / DEG;
    // topocentric-ish: geocentric direction is fine for orientation checks
    const x = Math.cos(de) * Math.cos(H), y = Math.cos(de) * Math.sin(H), z = Math.sin(de);
    // hour-angle frame (x toward meridian south? use standard): convert to ENU
    const E = -Math.sin(H) * Math.cos(de) * -1; // placeholder
    // Standard: az/alt
    const alt = Math.asin(Math.sin(phi) * Math.sin(de) + Math.cos(phi) * Math.cos(de) * Math.cos(H));
    const az = Math.atan2(Math.sin(H), Math.cos(H) * Math.sin(phi) - Math.tan(de) * Math.cos(phi)) + Math.PI;
    return {
        alt: alt * DEG, az: az * DEG,
        v: [Math.cos(alt) * Math.sin(az), Math.cos(alt) * Math.cos(az), Math.sin(alt)]
    };
}
function screenBasis(altDeg, azDeg) {
    const alt = altDeg / DEG, az = azDeg / DEG;
    return {
        right: [Math.cos(az), -Math.sin(az), 0],
        up: [-Math.sin(alt) * Math.sin(az), -Math.sin(alt) * Math.cos(az), Math.cos(alt)]
    };
}
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const norm = a => { const n = Math.hypot(...a) || 1; return a.map(x => x / n); };
const sub = (a, b) => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
function screenAngleCW(v, basis) {   // clockwise from screen-up
    return Math.atan2(dot(v, basis.right), dot(v, basis.up)) * DEG;
}

/* Moon north pole (Cassini approx, same model as page) in equatorial coords */
function moonPoleENU(date, lat, lng) {
    const d = (date.getTime() / 86400000) - 10957.5;
    const node = 125.0445479 - 0.0529538083 * d;
    const l = (node + 90) / DEG, b = (90 - 1.54242) / DEG;
    const eps = (23.439 - 0.0000004 * d) / DEG;
    const x = Math.cos(b) * Math.cos(l), y = Math.cos(b) * Math.sin(l), z = Math.sin(b);
    const ye = y * Math.cos(eps) - z * Math.sin(eps), ze = y * Math.sin(eps) + z * Math.cos(eps);
    // treat as direction at infinite distance: convert RA/dec of pole to ENU like a star
    const ra = (Math.atan2(ye, x) * DEG + 360) % 360, dec = Math.asin(ze) * DEG;
    return equatorialToENU(ra, dec, date, lat, lng).v;
}
function eclipticVecToENU(lonDeg, latDeg, date, lat, lng) {
    const d = (date.getTime() / 86400000) - 10957.5;
    const eps = (23.439 - 0.0000004 * d) / DEG;
    const l = lonDeg / DEG, b = latDeg / DEG;
    const x = Math.cos(b) * Math.cos(l), y = Math.cos(b) * Math.sin(l), z = Math.sin(b);
    const ye = y * Math.cos(eps) - z * Math.sin(eps), ze = y * Math.sin(eps) + z * Math.cos(eps);
    const ra = (Math.atan2(ye, x) * DEG + 360) % 360, dec = Math.asin(ze) * DEG;
    return equatorialToENU(ra, dec, date, lat, lng).v;
}

/* --- page under test --- */
const fs = require('fs');
const { JSDOM } = require('jsdom');
const html = fs.readFileSync(process.argv[2] || 'uploads/moon-new-poems-true-dark-side.html', 'utf8');
const vc = { on() {} };
const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true,
    virtualConsole: new (require('jsdom').VirtualConsole)(), url: 'https://x.test/' });
const win = dom.window;
win.fetch = () => Promise.reject(new Error('offline'));

function wrap(a) { a = ((a % 360) + 540) % 360 - 180; return a; }

setTimeout(() => {
    const cases = [
        ['now                    AMS', new Date(), 52.37, 4.90],
        ['next-ecl P1+1h         AMS', new Date(1803165120000 - 1.0 * 3600e3), 52.37, 4.90],
        ['next-ecl P4-1h         AMS', new Date(1803165120000 + 1.0 * 3600e3), 52.37, 4.90],
        ['part2026 U-1h          AMS', new Date(1787890320000 - 1.0 * 3600e3), 52.37, 4.90],
        ['part2026 U+1h          AMS', new Date(1787890320000 + 1.0 * 3600e3), 52.37, 4.90],
        ['part2026 U-1h          SYD', new Date(1787890320000 - 1.0 * 3600e3), -33.87, 151.21],
        ['total2026 U1+20m       NYC', new Date(1772537580000 - 0.9 * 3600e3), 40.71, -74.0],
    ];
    for (const [label, date, lat, lng] of cases) {
        // ground truth
        const m = moonEquatorial(date), s = sunEquatorial(date);
        const mENU = equatorialToENU(m.ra, m.dec, date, lat, lng);
        const sENU = equatorialToENU(s.ra, s.dec, date, lat, lng);
        const basis = screenBasis(mENU.alt, mENU.az);
        const northENU = [0, Math.cos(lat / DEG), Math.sin(lat / DEG)];
        const poleENU = moonPoleENU(date, lat, lng);
        const antiS = sENU.v.map(x => -x);
        const shadowDir = norm(sub(antiS, mENU.v));
        const gt = {
            moonAlt: +mENU.alt.toFixed(1), moonAz: +mENU.az.toFixed(1),
            mariaTiltCW: +wrap(screenAngleCW(poleENU, basis)).toFixed(1),
            brightLimbCW: +wrap(screenAngleCW(sENU.v, basis)).toFixed(1),
            shadowDirCW: +wrap(screenAngleCW(shadowDir, basis)).toFixed(1),
            northTiltCW: +wrap(screenAngleCW(northENU, basis)).toFixed(1),
        };
        // page values (read from the live DOM after a pinned refresh)
        const pg = win.eval(`(() => {
            observerPos = { lat: ${lat}, lng: ${lng} };
            const date = new Date(${date.getTime()});
            refreshMoon(date);
            const t = document.getElementById('moonSVG').style.transform;
            const vr = parseFloat(t.split('rotate(')[1]);
            const mt = document.getElementById('moonMaria').getAttribute('transform') || '';
            const spin = mt.indexOf('rotate(') >= 0 ? parseFloat(mt.split('rotate(')[1]) : 0;
            const u = document.getElementById('umbraShadow');
            const cx = parseFloat(u.getAttribute('cx')), cy = parseFloat(u.getAttribute('cy'));
            const st = eclipseState;
            let shadowScreen = null;
            if (st && !isNaN(cx)) shadowScreen = Math.atan2(cy-250, cx-250)*180/Math.PI + 90 + vr;
            const wrap = a => ((a%360)+540)%360-180;
            const wan = SunCalc.getMoonIllumination(date).phase > 0.5;
            return { mariaTiltCW: +wrap(vr+spin).toFixed(1),
                brightLimbCW: +wrap(90+vr+(wan?-180:0)).toFixed(1),
                shadowDirCW: shadowScreen === null ? null : +wrap(shadowScreen).toFixed(1) };
        })()`);
        console.log(label, '| alt/az gt', gt.moonAlt, gt.moonAz, 'page', pg.altPage, pg.azPage);
        console.log('   GT   mariaTilt', gt.mariaTiltCW, ' brightLimb', gt.brightLimbCW, ' shadowDir', gt.shadowDirCW, ' northTilt', gt.northTiltCW);
        console.log('   PAGE mariaTilt', pg.mariaTiltCW, ' brightLimb', pg.brightLimbCW, ' shadowDir', pg.shadowDirCW, ' (q', pg.q, 'B', pg.B, 'P', pg.P + ')');
        console.log('   DIFF mariaTilt', wrap(gt.mariaTiltCW - pg.mariaTiltCW).toFixed(1),
                    ' brightLimb', wrap(gt.brightLimbCW - pg.brightLimbCW).toFixed(1),
                    ' shadowDir', gt.shadowDirCW === null || pg.shadowDirCW === null ? 'n/a' : wrap(gt.shadowDirCW - pg.shadowDirCW).toFixed(1));
    }
    win.close();
}, 1200);

const puppeteer = require('puppeteer');
(async () => {
    const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
    const page = await browser.newPage();
    await page.setViewport({ width: 900, height: 1400 });
    await page.goto('file://' + process.cwd() + '/moon-new-poems-true-dark-side.html', { waitUntil: 'load' });
    await new Promise(r => setTimeout(r, 2000));
    await page.evaluate(() => {
        const sel = document.getElementById('eclipseSelect');
        sel.value = '1803165120000'; sel.dispatchEvent(new Event('change', { bubbles: true }));
    });
    await new Promise(r => setTimeout(r, 400));
    await page.evaluate(() => { previewState.t = previewState.lastT0; refreshMoon(); });
    const info = await page.evaluate(() => {
        const st = eclipseState;
        const px = 240 / st.rMoon;
        const a = eclipseShadowAngle(previewState.lastT0 ? new Date(previewState.t) : new Date(), observerPos.lat, observerPos.lng, st, SunCalc.getMoonPosition(new Date(previewState.t), observerPos.lat, observerPos.lng), SunCalc.getMoonIllumination(new Date(previewState.t)), new Date(previewState.t));
        const off = st.sigma * px;
        const cx = 250 + off * Math.cos(a / (Math.PI/180) * (Math.PI/180)); // angle already rad? keep as-is
        return { rP: st.rhoP * px, rU: st.rhoU * px, sigma: st.sigma, width: (st.rhoP - st.rhoU) * px,
                 alphas: [...document.querySelectorAll('#termDusk path')]
                     .filter(p => (p.getAttribute('d')||'').length > 4)
                     .map(p => +p.getAttribute('fill-opacity')) };
    });
    const cum = 1 - info.alphas.reduce((acc, a) => acc * (1 - a), 1);
    console.log('rP', info.rP.toFixed(1), 'rU', info.rU.toFixed(1), 'width', info.width.toFixed(1), 'sigma', info.sigma.toFixed(3));
    console.log('bands', info.alphas.length, 'cumulative alpha at deepest', cum.toFixed(3));
    console.log('first alphas', info.alphas.slice(0, 8).map(x => x.toFixed(4)).join(','));
    console.log('last  alphas', info.alphas.slice(-6).map(x => x.toFixed(4)).join(','));
    await browser.close();
})();

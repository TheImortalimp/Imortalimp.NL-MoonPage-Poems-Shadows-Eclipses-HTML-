const puppeteer = require('puppeteer');
const fs = require('fs');
const html = fs.readFileSync('moon-new-poems-true-dark-side.html', 'utf8');
const wrapper = `<!DOCTYPE html><html><body style="margin:0"><iframe sandbox="allow-scripts" style="width:900px;height:1400px;border:0" srcdoc="${html.replace(/&/g,'&amp;').replace(/"/g,'&quot;')}"></iframe></body></html>`;
(async () => {
    const browser = await puppeteer.launch({ args: ['--no-sandbox'] });
    const page = await browser.newPage();
    await page.setViewport({ width: 920, height: 1420 });
    const errs = []; page.on('pageerror', e => errs.push(e.message));
    await page.setContent(wrapper, { waitUntil: 'load' });
    await new Promise(r => setTimeout(r, 2500));
    const fr = page.frames().find(f => f !== page.mainFrame());
    const st = await fr.evaluate(() => ({
        op: document.getElementById('terminatorBands').getAttribute('opacity'),
        d: (document.getElementById('termBand0').getAttribute('d') || '').length
    }));
    console.log('iframe live bands:', JSON.stringify(st));
    const el = await fr.$('#moonContainer'); await el.screenshot({ path: 'ifr-live-bands.png' });
    console.log('errors:', errs.length ? errs.join('|') : '(none)');
    await browser.close();
})();
